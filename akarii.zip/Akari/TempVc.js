const mongoose = require('mongoose');

const tempVCSchema = new mongoose.Schema({
  guildId: {
    type: String,
    required: true
  },
  vcChannelId: {
    type: String,
    required: true
  },
  textChannelId: {
    type: String,
    required: true
  },
  createdTempChannels: [{
    tempChannelId: String,
    ownerId: String
  }]
});

const TempVC = mongoose.model('TempVC', tempVCSchema);

module.exports = TempVC;
