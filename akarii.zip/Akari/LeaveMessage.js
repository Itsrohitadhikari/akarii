const mongoose = require('mongoose');

const leaveMessageSchema = new mongoose.Schema({
  guildId: { type: String, required: true },
  channel: { type: String, required: true },
  headerTitle: String,
  title: String,
  leaveBody: String,
  footerText: String,
  thumbnailUrl: String,
  bodyImageUrl: String,
  color: String, // New property for color
});

module.exports = mongoose.model('LeaveMessage', leaveMessageSchema); 
