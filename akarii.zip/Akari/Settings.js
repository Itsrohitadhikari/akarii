const mongoose = require('mongoose');

const settingsSchema = new mongoose.Schema({
  guildId: String,
  logChannelId: String,
});

const Settings = mongoose.model('Settings', settingsSchema); 
module.exports = Settings;
