const mongoose = require('mongoose');

const waifuSchema = new mongoose.Schema({
  userId: { 
    type: String,
    unique: true,
    required: true
  },
  smashedWaifus: {
    type: [String], // Array of image URLs
    validate: [arrayLimit, '{PATH} exceeds the limit of 5'] // Custom validator for array length
  }
});

function arrayLimit(val) {
  return val.length <= 5;
}

const Waifu = mongoose.model('Waifu', waifuSchema);

module.exports = Waifu; 
