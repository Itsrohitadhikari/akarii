const mongoose = require('mongoose');

// Schema for AFK status
const afkSchema = new mongoose.Schema({
guildId: { type: String, required: true },
userId: { type: String, required: true },
timestamp: { type: Date, default: Date.now },
reason: { type: String, default: "I'm afk sis" },
mentions: [{
userId: String,
timestamp: Date,
content: String,
messageId: String,
}],
});

// Create a model from the schema
const AfkModel = mongoose.model('AfkStatus', afkSchema);

module.exports = AfkModel;
