
const { SlashCommandBuilder, REST, Routes, PermissionFlagsBits } = require('discord.js');
const rest = new REST({ version: '10' }).setToken('MTIyMzgyNDc0MjE1NTI4ODU4Ng.GHTzpi.3-BQXyTeMaVBo_xM3ilYkVsG6GlubxMX-_MB7I'); 

const commands = [
  new SlashCommandBuilder()
    .setName('play')
    .setDescription('Play a song')
    .addStringOption(option =>
      option.setName('song')
        .setDescription('The name of the song or the URL you want to play')
	.setAutocomplete(true)
        .setRequired(true)
    ),
  new SlashCommandBuilder()
    .setName('whois')
    .setDescription('Grab the info of the user')
    .addUserOption(option =>
       option.setName('user')
       .setDescription('Select the User whose whois you want to see')
       ),
  new SlashCommandBuilder()
    .setName('avatar')
    .setDescription('Shows the avatar')
    .addUserOption(option =>
       option.setName('user')
       .setDescription('The User Whose Avatar you want to see.')
       ),
  new SlashCommandBuilder()
    .setName('afk')
    .setDescription('Set AFK Status')
    .addStringOption(option => 
       option.setName('reason')
       .setDescription('Reason for AFK')
       ),
  new SlashCommandBuilder()
    .setName('smp')
    .setDescription('setup music player'),
  new SlashCommandBuilder()
    .setName('rmp')
    .setDescription('delete music player'),
  new SlashCommandBuilder()
    .setName('pause')
    .setDescription('Pause the currently playing song'),
  new SlashCommandBuilder()
    .setName('resume')
    .setDescription('Resume the currently paused song'),
  new SlashCommandBuilder()
    .setName('skip')
    .setDescription('Skip the current song'),
 new SlashCommandBuilder()
    .setName('stop')
    .setDescription('Stop the music player'),
  new SlashCommandBuilder()
    .setName('join')
    .setDescription('Join the VC'),
 new SlashCommandBuilder()
    .setName('leave')
    .setDescription('Leave the VC'),
 new SlashCommandBuilder()
    .setName('rewind')
    .setDescription('Rewind 10 Sec.'),
 new SlashCommandBuilder()
    .setName('forward')
    .setDescription('forward 10 sec.'),
 new SlashCommandBuilder()
    .setName('previous')
    .setDescription('Replay the Previous Song'),
  new SlashCommandBuilder()
    .setName('autoplay')
    .setDescription('toggle autoplay status'),
  new SlashCommandBuilder()
    .setName('related')
    .setDescription('add a related song'),
  new SlashCommandBuilder()
    .setName('queue')
    .setDescription('Get the Queue'),
  new SlashCommandBuilder()
    .setName('skipto')
    .setDescription('Skip to a specific song in the queue')
    .addIntegerOption(option =>
      option.setName('song_number')
        .setDescription('The number of the song to skip to')
        .setRequired(true)
    ),
 new SlashCommandBuilder()
    .setName('lyrics')
   .setDescription('Fetch Lyrics')
  .addStringOption(option =>
      option.setName('query')
        .setDescription('The song name which lyrics you want to fetch')
        .setRequired(true)
),
  new SlashCommandBuilder()
    .setName('filter')
    .setDescription('Set the filter for the music')
    .addStringOption(option =>
      option.setName('filter_name')
        .setDescription('Name of Any Available Filters')
        .setRequired(true)
    ),
  new SlashCommandBuilder()
    .setName('volume')
    .setDescription('Set the volume of the music')
    .addIntegerOption(option =>
      option.setName('volume_level')
        .setDescription('The volume level (0-100)')
        .setRequired(true)
    ),
  new SlashCommandBuilder()
    .setName('remove')
    .setDescription('Remove a song from the queue')
    .addIntegerOption(option =>
      option.setName('song_number')
        .setDescription('The number of the song to remove')
        .setRequired(true)
    ),
new SlashCommandBuilder()
.setName('fun')
.setDescription('Fun Commands to Enjoy')
.addSubcommand(subcommand =>
subcommand
.setName('waifu')
.setDescription('Get Waifu Picture')
)
.addSubcommand(subcommand =>
subcommand
.setName('mywaifu')
.setDescription('Fetch the Waifu You Smashed..')
)
.addSubcommand(subcommand =>
subcommand
.setName('tord')
.setDescription('Start Truth or Dare Gammmeeeee..')
)
.addSubcommand(subcommand =>
subcommand
.setName('nhie')
.setDescription('Start Never Have i Ever Gammmeeeee..')
)
.addSubcommand(subcommand =>
subcommand
.setName('wyr')
.setDescription('Start Would You Rather Gammmeeeee..')
)
.addSubcommand(subcommand =>
subcommand
.setName('paranoia')
.setDescription('Start paranoia Gammmeeeee..')
)
    .addSubcommand(subcommand =>
        subcommand
            .setName('rps')
            .setDescription('Play Rock, Paper, Scissors')
            .addStringOption(option =>
                option.setName('choice')
                    .setDescription('Your choice: rock, paper, or scissors')
                    .setRequired(true)
                    .addChoices(
                        { name: 'Rock', value: 'rock' },
                        { name: 'Paper', value: 'paper' },
                        { name: 'Scissors', value: 'scissors' },
                    ))
)    
.addSubcommand(subcommand =>
subcommand
.setName('meme')
.setDescription('Get A Random Meme..')
),
new SlashCommandBuilder()
.setName('stats')
.setDescription('fetch some stats stuff')
.addSubcommand(subcommand =>
subcommand
.setName('serverinfo')
.setDescription('Get ServerInfo')
)
.addSubcommand(subcommand =>
subcommand
.setName('boost')
.setDescription('Get Boost Data')
),
 new SlashCommandBuilder()
.setName('welcome')
.setDescription('Configure welcome message settings for your server.')
.setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
.addSubcommand(subcommand =>
subcommand
.setName('channel')
.setDescription('Set the channel to send welcome messages to.')
.addChannelOption(option => option.setName('channel').setDescription('Select the welcome channel').setRequired(true))
)

.addSubcommand(subcommand =>
subcommand
.setName('remove')
.setDescription('Set the channel to send welcome messages to.')
)
.addSubcommand(subcommand =>
subcommand
.setName('header')
.setDescription('Set the header for the welcome messages.')
.addStringOption(option => option.setName('header').setDescription('The text for the header').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('title')
.setDescription('Set the title for the welcome messages.')
.addStringOption(option => option.setName('title').setDescription('The text for the title').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('body')
.setDescription('Set the body text for the welcome messages.')
.addStringOption(option => option.setName('body').setDescription('The text for the body').setRequired(true))
)
.addSubcommand(subcommand =>
subcommand
.setName('footer')
.setDescription('Set the footer for the welcome messages.')
.addStringOption(option => option.setName('footer').setDescription('The text for the footer').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('thumbnail')
.setDescription('Set a thumbnail image for the welcome messages.')
.addStringOption(option => option.setName('thumbnail').setDescription('The URL for the thumbnail image').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('image')
.setDescription('Set a body image for the welcome messages.')
.addStringOption(option => option.setName('image').setDescription('The URL for the body image').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('color')
.setDescription('Set the color for the welcome messages embed.')
.addStringOption(option => option.setName('color').setDescription('The hex color code').setRequired(false))
),
new SlashCommandBuilder()
.setName('leaveevent')
.setDescription('Configure leave message settings for your server.')
.addSubcommand(subcommand =>
subcommand
.setName('channel')
.setDescription('Set the channel to send leave messages to.')
.addChannelOption(option => option.setName('channel').setDescription('Select the leave channel').setRequired(true))
)

.addSubcommand(subcommand =>
subcommand
.setName('remove')
.setDescription('Set the channel to send welcome messages to.')
)
.addSubcommand(subcommand =>
subcommand
.setName('header')
.setDescription('Set the leave for the welcome messages.')
.addStringOption(option => option.setName('header').setDescription('The text for the leave header').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('title')
.setDescription('Set the title for the leave messages.')
.addStringOption(option => option.setName('title').setDescription('The text for the leave  title').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('body')
.setDescription('Set the body text for the leave messages.')
.addStringOption(option => option.setName('body').setDescription('The text for the leave body').setRequired(true))
)
.addSubcommand(subcommand =>
subcommand
.setName('footer')
.setDescription('Set the footer for the leave messages.')
.addStringOption(option => option.setName('footer').setDescription('The text for the leave footer').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('thumbnail')
.setDescription('Set a thumbnail image for the leave messages.')
.addStringOption(option => option.setName('thumbnail').setDescription('The URL for the thumbnail leave image').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('image')
.setDescription('Set a body image for the leave messages.')
.addStringOption(option => option.setName('image').setDescription('The URL for the leave body image').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('color')
.setDescription('Set the color for the leave messages embed.')
.addStringOption(option => option.setName('color').setDescription('The hex color code for leave embed').setRequired(false))
),
new SlashCommandBuilder()
.setName('ticket')
.setDescription('Configure ticket message settings for your server.')
.addSubcommand(subcommand =>
subcommand
.setName('channel')
.setDescription('Set the channel to send ticket messages to.')
.addChannelOption(option => option.setName('channel').setDescription('Select the ticket channel').setRequired(true))
)
.addSubcommand(subcommand =>
subcommand
.setName('send')
.setDescription('Set The Ticketing System wholly')
)
.addSubcommand(subcommand =>
subcommand
.setName('remove')
.setDescription('Set the channel to send welcome messages to.')
)
.addSubcommand(subcommand =>
subcommand
.setName('header')
.setDescription('Set the header for the leave messages.')
.addStringOption(option => option.setName('header').setDescription('The text for the leave header').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('title')
.setDescription('Set the title for the ticket messages.')
.addStringOption(option => option.setName('title').setDescription('The text for the ticket  title').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('body')
.setDescription('Set the body text for the ticket messages.')
.addStringOption(option => option.setName('body').setDescription('The text for the ticket body').setRequired(true))
)
.addSubcommand(subcommand =>
subcommand
.setName('footer')
.setDescription('Set the footer for the ticket messages.')
.addStringOption(option => option.setName('footer').setDescription('The text for the ticket footer').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('thumbnail')
.setDescription('Set a thumbnail image for the ticket messages.')
.addStringOption(option => option.setName('thumbnail').setDescription('The URL for the thumbnail ticket image').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('image')
.setDescription('Set a body image for the ticket messages.')
.addStringOption(option => option.setName('image').setDescription('The URL for the ticket body image').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('color')
.setDescription('Set the color for the ticket messages embed.')
.addStringOption(option => option.setName('color').setDescription('The hex color code for leave embed').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('create')
.setDescription('create a ticket channel.')
)
.addSubcommand(subcommand =>
subcommand
.setName('close')
.setDescription('close ticket channel')
),
new SlashCommandBuilder()
.setName('boost')
.setDescription('Configure boost message settings for your server.')
.addSubcommand(subcommand =>
subcommand
.setName('channel')
.setDescription('Set the channel to send boost messages to.')
.addChannelOption(option => option.setName('channel').setDescription('Select the boost channel').setRequired(true))
)

.addSubcommand(subcommand =>
subcommand
.setName('remove')
.setDescription('Set the channel to send boost messages to.')
)
.addSubcommand(subcommand =>
subcommand
.setName('header')
.setDescription('Set the header for the boost messages.')
.addStringOption(option => option.setName('header').setDescription('The text for the header').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('title')
.setDescription('Set the title for the boost messages.')
.addStringOption(option => option.setName('title').setDescription('The text for the title').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('body')
.setDescription('Set the body text for the boost messages.')
.addStringOption(option => option.setName('body').setDescription('The text for the body').setRequired(true))
)
.addSubcommand(subcommand =>
subcommand
.setName('footer')
.setDescription('Set the footer for the boost messages.')
.addStringOption(option => option.setName('footer').setDescription('The text for the footer').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('thumbnail')
.setDescription('Set a thumbnail image for the boost messages.')
.addStringOption(option => option.setName('thumbnail').setDescription('The URL for the thumbnail image').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('image')
.setDescription('Set a body image for the boost messages.')
.addStringOption(option => option.setName('image').setDescription('The URL for the body image').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('log')
.setDescription('Set a body image for the boost messages.')
.addChannelOption(option => option.setName('log').setDescription('The Log Channel For boost Update ').setRequired(false))
)
.addSubcommand(subcommand =>
subcommand
.setName('color') 
.setDescription('Set the color for the boost messages embed.')
.addStringOption(option => option.setName('color').setDescription('The hex color code').setRequired(false))
),
new SlashCommandBuilder()
.setName('log')
.setDescription('Configure Logging')
.addSubcommand(subcommand =>
subcommand
.setName('message')
.setDescription('Set Message Log Channel')
.addStringOption(option => option.setName('channel_name').setDescription('Channel where you want to send message log').setRequired(true))
)
.addSubcommand(subcommand =>
subcommand
.setName('vc')
.setDescription('Set vc Log Channel')
.addStringOption(option => option.setName('channel_name').setDescription('Channel where you want to send vc log').setRequired(true))
)
.addSubcommand(subcommand =>
subcommand
.setName('join-leave')
.setDescription('Set join-leave Log Channel')
.addStringOption(option => option.setName('channel_name').setDescription('Channel where you want to send join-leave log').setRequired(true))
)
.addSubcommand(subcommand =>
subcommand
.setName('member')
.setDescription('Set member Log Channel')
.addStringOption(option => option.setName('channel_name').setDescription('Channel where you want to send member log').setRequired(true))
)
.addSubcommand(subcommand =>
subcommand
.setName('server')
.setDescription('Set server Log Channel')
.addStringOption(option => option.setName('channel_name').setDescription('Channel where you want to send server log').setRequired(true))
),

 new SlashCommandBuilder()
    .setName('playlist')
    .setDescription('Manage your playlists!')
    .addSubcommand(subcommand =>
      subcommand
        .setName('create')
        .setDescription('Create a new playlist.')
        .addStringOption(option =>
          option.setName('name').setDescription('The name of the playlist').setRequired(true)
        )
    )
    .addSubcommand( subcommand => 
      subcommand
      .setName('play')
      .setDescription('Play the Custom Playlist')
     .addStringOption(option =>
     option.setName('name').setDescription('The Name of Custom Playlist You want to Play').setRequired(true)
      )
    )
    .addSubcommand(subcommand =>
      subcommand
       .setName('list')
       .setDescription('Get list of your crafted playlist')
      )
    .addSubcommand(subcommand =>
      subcommand
     .setName('rename')
     .setDescription('Rename the Playlist Name')
     .addStringOption(option =>
        option.setName('old').setDescription('Current Name of Playlis').setRequired(true)
       )
     .addStringOption(option =>
      option.setName('new').setDescription('The New Name you want to give').setRequired(true)
     )
     )
    .addSubcommand(subcommand =>
      subcommand
       .setName('view')
      .setDescription('View The Playlist Song Details')
     .addStringOption(option =>
      option.setName('name').setDescription('The Name of Playlist').setRequired(true)
      )
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName('delete')
        .setDescription('Delete an existing playlist.')
        .addStringOption(option =>
          option.setName('name').setDescription('The name of the playlist you want to delete').setRequired(true)
        )
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName('add')
        .setDescription('Add a song to a playlist.')
        .addStringOption(option =>
          option.setName('playlistname').setDescription('The name of the playlist').setRequired(true)
        )
        .addStringOption(option =>
          option.setName('song').setDescription('The song to add, formatted as Title - Artist').setRequired(true)
        )
    )
    .addSubcommand(subcommand =>
      subcommand
        .setName('remove')
        .setDescription('Remove a song from a playlist.')
        .addStringOption(option =>
          option.setName('playlistname').setDescription('The name of the playlist').setRequired(true)
        )
        .addStringOption(option => 
option.setName('song').setDescription('The song to remove, formatted as Title - Artist').setRequired(true)
        )
    ),
  new SlashCommandBuilder()
    .setName('move')
    .setDescription('Move a song to a specific position in the queue')
    .addIntegerOption(option =>
      option.setName('from')
        .setDescription('The current position of the song')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option.setName('to')
        .setDescription('The desired position of the song')
        .setRequired(true)
    ),
].map(command => command.toJSON());
//arre baba, agar console mein kuch nahi aa raha hai, toh ho sakta hai tumhara function hi call nahi ho raha ho ya phir environment variables sahi se set nahi hain. ek kaam karo, registerSlashCommands() function ko directly call karo with the correct clientId and guildId, aur dekho kya hota hai. yaad rakhna, client_id aur guild_id ko strings ke roop mein pass karna hai, numbers nahi.

// Use the correct 'clientId' and 'guildId' values when calling the function
registerSlashCommands('1223824742155288586'); 


//aur haan, make sure tere client_id, guild_id, aur token sahi hain, aur token missing ya expired toh nahi hai. environmental variables ka bhi dhyan rakhna. kabhi-kabhi toh bas ek choti si galti se bada wala error ho jata hai. triumphmag
async function registerSlashCommands(clientId) {
  try {
    console.log('Started refreshing application (/) commands.');

    await rest.put(
      Routes.applicationGuildCommands('1223824742155288586', '1212699450766659704'),
      { body: commands }
    );

    console.log('Successfully reloaded application (/) commands.');
  } catch (error) {
    console.error("Fail to Register for now", error);
  }
}

module.exports = { registerSlashCommands }; 
