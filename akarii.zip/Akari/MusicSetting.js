const mongoose = require('mongoose');

const musicSettingSchema = new mongoose.Schema({
  guildId: { type: String, required: true },
  channelId: { type: String, required: true },
  queueMessageId: { type: String, required: false }, // Where your queue will be displayed
  nowPlayingMessageId: { type: String, required: false } // Where the currently playing song info will be displayed
});

const MusicSetting = mongoose.model('MusicSetting', musicSettingSchema);

module.exports = MusicSetting; 

