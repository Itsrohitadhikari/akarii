const mongoose = require('mongoose');

const welcomePingSchema = new mongoose.Schema({
guildId: {
type: String,
required: true
},
channelId: {
type: String,
required: true
},
text: {
type: String,
required: true
}
});

const WelcomePing = mongoose.model('WelcomePing', welcomePingSchema);

module.exports = WelcomePing; 
