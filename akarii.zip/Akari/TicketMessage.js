const mongoose = require('mongoose');
const ticketMessageSchema = new mongoose.Schema({
guildId: { type: String, required: true },
channel: { type: String, required: true },
headerTitle: String,
title: String,
ticketBody: String,
footerText: String,
thumbnailUrl: String,
bodyImageUrl: String,
ticketId: {
    type: mongoose.Schema.Types.String, // Assuming ticketId is an Object ID
    ref: 'TicketMessage', // Ensures a reference to the TicketMessage document
    required: true
  },
  channelId: {
    type: String,
    required: true
  },
  messageId: {
    type: String,
    required: true
  },
  authorId: {
    type: String,
    required: true
  },
  content: {
    type: String,
    required: true
  },
  timestamp: {
    type: Date,
    default: Date.now
  },
color: String,
creatorId: { type: String, required: true },
staffRoles: [{ type: String }],
});
const TicketMessage = mongoose.model('TicketMessage', ticketMessageSchema);
module.exports = TicketMessage;
