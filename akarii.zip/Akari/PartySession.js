const mongoose = require('mongoose');
const { Schema } = mongoose;

const partySessionSchema = new Schema({
guildId: String,
channelId: String,
hostId: String,
topic: String,
members: [{ userId: String }] // You could use a Map structure for more complex data handling
}, { timestamps: true });

const PartySession = mongoose.model('PartySession', partySessionSchema);
module.exports = PartySession;
