// Import the necessary modules
const { Client, GatewayIntentBits, EmbedBuilder, ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle, SelectMenuBuilder, Events, PermissionsBitField, PermissionFlagsBits, Util, Partials, ModalBuilder, TextInputBuilder, TextInputStyle, InteractionType, version } = require('discord.js');
const { DisTube } = require('distube');
const { SpotifyPlugin } = require('@distube/spotify');
const { SoundCloudPlugin } = require('@distube/soundcloud');
const { DeezerPlugin } = require("@distube/deezer");
const { joinVoiceChannel, getVoiceConnection } = require('@discordjs/voice');
//const { registerSlashCommands } = require('./rSlash');
const fs = require('node:fs');
const path = require('node:path');
const axios = require('axios');
const topggToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjEyMTkzMzk3OTM2MzMxMjAzNTciLCJib3QiOnRydWUsImlhdCI6MTcxNDcwODAzMH0.gA7KFjpchZc0IGlkEzuegJGt7CioMSnm9nG8n0AsSA4';
const botlistToken = 'fajRqBNgyKLKeMbzfCh5yggPCF-RFT';
const AutoComplete = require('youtube-autocomplete');
//const serverSettingsPath = './serverSettings.json';
const MusicSetting = require('./MusicSetting'); 
const WelcomeMessage = require('./WelcomeMessage'); 
const LeaveMessage = require('./LeaveMessage'); 
const BoostMessage = require('./BoostMessage'); 
const mongoose = require('mongoose');
const mongoDB = 'mongodb+srv://rohitadhikari699:Te9cKlZHQP9N3Iy0@akari.k6x0pou.mongodb.net/';
const serverUrl = "https://discord.gg/su2PDpJkBf";
const AfkModel = require('./AfkModel');
const Settings = require('./Settings');
const Waifu = require('./Waifu');
const Genius = require('genius-lyrics');
const GClient = new Genius.Client("xfhuUDpQBDxzjZajBmFll_D0l9MVANBllk5vLsNjA9pAYP2pkIGTyEyfxLAlQR46");
const Logging = require('./Logging'); // Import our Logging schema
const TempVC = require('./TempVc');
const Starboard = require('./Starboard');
const WelcomePing = require('./WelcomePing');
mongoose.connect(mongoDB, { 
  useNewUrlParser: true, 
  useUnifiedTopology: true 
}).then(() => {
  console.log('Connected to database!');
}).catch(err => {
  console.error('Database connection error:', err);
});
const playlistSchema = new mongoose.Schema({
  userId: String,
  name: String,
  songs: [{ title: String, artist: String, url: String }]
});

const Playlist = mongoose.model('Playlist', playlistSchema); 
// Initialize your Discord client
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildEmojisAndStickers,
	GatewayIntentBits.GuildPresences,
	GatewayIntentBits.GuildMessageReactions,
	GatewayIntentBits.GuildBans,
	GatewayIntentBits.GuildMembers,
    ],
	partials: [Partials.Channel],
});

// Function to fetch autocomplete suggestions for a given query

function getAutocompleteSuggestions(query) {
  return new Promise((resolve, reject) => {
    AutoComplete(query, (err, suggestions) => {
      if (err) {
        reject(err);
      } else {
        // Assuming `suggestions[1]` is the array containing song titles
        if (Array.isArray(suggestions[1])) {
          // Map the song titles to objects with a `title` key
          const formattedSuggestions = suggestions[1].map(title => ({ title }));
          resolve(formattedSuggestions);
        } else {
          // If `suggestions[1]` doesn't exist or isn't an array, resolve with an empty array or some default value
          resolve([]);
        }
      }
    });
  });
} 
function splitMessage(text, length = 2000) {
  const splitText = [];
  while (text.length > 0) {
    const splitIndex = text.lastIndexOf('', length);
    const subText = text.substring(0, splitIndex > 0 ? splitIndex : length);
    splitText.push(subText.trim());
    text = text.slice(splitIndex > 0 ? splitIndex : length);
  }
  return splitText;
}


const createButtonRow = (page, maxPage) => {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('previous_btn')
      .setLabel('Previous')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page <= 0),
    new ButtonBuilder()
      .setCustomId('next_btn')
      .setLabel('Next')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page >= maxPage)
  );
};
// Helper function to create an embed with Truth and Dare buttons
const createTordEmbed = (title, description) => {
  const embed = new EmbedBuilder()
    .setTitle(title)
    .setDescription(description)
    .setColor(0x5865F2);

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('truth_button')
        .setLabel('Truth')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('dare_button')
        .setLabel('Dare')
        .setStyle(ButtonStyle.Danger)
    );

  return { embeds: [embed], components: [row] };
};
const vipUserIds = ["852908200776171520", "1061249806154088468"];
const searchResultsCache = {};
// Configure DisTube
const distube = new DisTube(client, {
    searchSongs: 0,
    plugins: [new SpotifyPlugin(), new DeezerPlugin(), new SoundCloudPlugin()],
    leaveOnFinish: true,
    leaveOnEmpty: true,
    emptyCooldown: 40,
    youtubeCookie: [
     { "domain": ".youtube.com", "expirationDate": 1728734360.469885, "hostOnly": false, "httpOnly": true, "name": "VISITOR_PRIVACY_METADATA", "path": "/", "sameSite": "no_restriction", "secure": true, "session": false, "storeId": "0", "value": "CgJOUBIEGgAgVQ%3D%3D", "id": 20 },
],
    customFilters: {                                        cursed: 'vibrato=f=6.5,tremolo,aresample=48000,asetrate=48000*1.25',
   slowreverb: 'atempo=0.85,aecho=1.0:0.5:10:0.5',
   earrape: 'earwax,equalizer=f=1000:t=q:w=1:g=48,bass=g=40,dynaudnorm=f=400',                                  double: 'aecho=0.8:0.88:60:0.4',                      rickroll: 'bass=g=33,apulsator=hz=0.06,vibrato=f=2.5,tremolo,asetrate=48000*0.8',
   "4D": 'apulsator=hz=0.04',
   "8D": "apulsator=hz=0.08",
  fullaudio: "bass=g=7,dynaudnorm=f=200,apulsator=hz=0.08"                                                  
},
    ytdlOptions: {                                          highWaterMark: 1024 * 1024 * 64,

      quality: "highestaudio",

      format: "audioonly",                                  liveBuffer: 60000,

      dlChunkSize: 1024 * 1024 * 4,                       },
});
// Define filters
const filters = [
  '3d',
  'bassboost',
  'echo',
  'karaoke',
  'nightcore',
  'flanger',
  'gate',
  'reverse',
  'surround',
  'mcompand',
  'phaser',
  'tremolo',
  'earwax',
  'vaporwave',
    'cursed',                                            'slowreverb',                                         'earrape',

   'double',                                             'rickroll',                                           '4D',                                                 '8D',

   'fullaudio'
];
const filterOptions = filters.map(filter => ({
  label: filter,
  value: filter.toLowerCase() // or just use filter if you don't need lowercase
}));
filterOptions.push({
  label: 'Clear',
  value: 'clear' // A value to indicate no filter or clear the existing filter
});
let sessionVolume = 75;
const bannedUsers = ['1738338384839']

function isAuthorized(interaction) {
  return (
    interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild)
  );
}
// Event when the bot is readyclient.on('ready', () => {
client.on('ready', () => {
  console.log(`${client.user.tag} is online and ready to jam!`);

  const activitiesList = [
    { type: 'PLAYING',  message: 'Some Tunes' },
    { type: 'LISTENING', message: 'to store Logging for your server' },
    { type: 'WATCHING', message: 'a! prefix and / slash commands' },
  ];

  let i = 0;
  setInterval(() => {
    const currentActivity = activitiesList[i++ % activitiesList.length];
    client.user.setPresence({
      status: 'idle', // You can change this to 'online', 'dnd', or 'invisible'
      activities: [{ name: currentActivity.message, type: currentActivity.type }]
    });
  }, 60000); // Changes every 10 minutes
}); 




// clean
const clean = text => {
if (typeof(text) === "string")
  return text.replace(/`/g, "`" + String.fromCharCode(8203)).replace(/@/g, "@" + String.fromCharCode(8203));
else
  return text;
}

//Autocomplete Handler
client.on('interactionCreate', async interaction => {
//  if (!interaction.isAutocomplete() || interaction.commandName !== 'play') return;
   if (!interaction.isAutocomplete()) return;
  const focusedOption = interaction.options.getFocused(true);

  if (focusedOption.name === 'song') {
    const userQuery = focusedOption.value;

    try {
      const suggestions = await getAutocompleteSuggestions(userQuery);

     // console.log('Suggestions:', suggestions);

      const choices = suggestions.map(s => ({
        name: s.title ? String(s.title).substring(0, 100) : 'Untitled',
        value: s.title ? String(s.title).substring(0, 100) : 'Untitled',
      })).filter(choice => choice.name.trim() !== '' && choice.value.trim() !== '');

      if (choices.length > 0) {
        await interaction.respond(choices);
      } else {
        await interaction.respond([{ name: 'No suggestions found', value: 'no_suggestions' }]);
      }
    } catch (error) {
      console.error('Error fetching autocomplete suggestions:', error);
    }
  }
}); 

// Function For Votes
async function checkIfUserVoted(userId) {
  try {
    const response = await axios.get(`https://top.gg/api/bots/1219339793633120357/check?userId=${userId}`, {
      headers: { Authorization: topggToken }
    });
      // If the user has voted, response.data.voted will be 1
    return response.data.voted === 1;
  } catch (error) {
    console.error('There was an error checking the vote in topgg :', error);
    return false;
  }
}
      
      async function checkIfUserVotedBotlist(userId) {
  try {
    const response = await axios.get(`https://botlist.me/api/bots/1219339793633120357/votes/check?userId=${userId}`, {
      headers: { 'Authorization': botlistToken }
    });

    // Assuming the API response structure is similar, adjust as needed based on their actual structure
    return response.data.hasVoted;
  } catch (error) {
    console.error('Error checking vote on botlist.me:', error);
    return false;
  }
} 

      async function checkVotesOnAnyList(userId) {
  const votedTopGG = await checkIfUserVoted(userId);
  const votedBotlist = await checkIfUserVotedBotlist(userId);
  return votedTopGG || votedBotlist; // Return true if the user voted on either site
}


// Message Edit
client.on('messageUpdate', async (oldMessage, newMessage) => {
  // Let's ignore partial messages and check if the content actually changed
  if (oldMessage.partial || newMessage.partial) return;
  if (oldMessage.content === newMessage.content) return;

  try {
    // Fetch the logging settings from the database for the guild
    const loggingSettings = await Logging.findOne({ guildId: newMessage.guild.id }).exec();

    // Check if the messageLogs setting is configured
    if (loggingSettings && loggingSettings.messageLogs) {
      // Find the channel to send the log
      const logChannel = newMessage.guild.channels.cache.get(loggingSettings.messageLogs);
      if (!logChannel) return; // If we can't find the channel, stop here

      // Create the rich embed for the log
      const embed = new EmbedBuilder()
        .setTitle('Message Edited')
        .setDescription(`A message by <@${newMessage.author.id}> was edited in <#${newMessage.channel.id}>.`)
        .addFields(
          { name: 'Before', value: oldMessage.content.slice(0, 1024), inline: false },
          { name: 'After', value: newMessage.content.slice(0, 1024), inline: false }
        )
        .setTimestamp(new Date())
        .setColor('#0099ff');

      // Send the embed to the log channel
      logChannel.send({ embeds: [embed] });
    }
  } catch (error) {
    console.error('Error fetching message logs channel:', error);
  }
}); 

// Akari Left

client.on('guildDelete', guild => {
  // This guild object is the one the bot just waved goodbye to
  // Let's fetch that channel where we report the departures
  const infoChannel = client.channels.cache.get('1226470224853860453');
  if (!infoChannel) return; // No channel? No send-o!

  // Whip up an embed with the server's parting info
  const farewellEmbed = new EmbedBuilder()
    .setColor(0xE74C3C) // a hue of sunset, as it's a goodbye
    .setTitle(`I've just left a server... 😢`)
    .setDescription(`Bidding adieu to **${guild.name}**.`)
    .addFields(
      { name: 'Server Name', value: guild.name, inline: true },
      { name: 'Server ID', value: guild.id, inline: true },
      { name: 'Total Members at Departure', value: `${guild.memberCount}`, inline: true }
    )
    .setThumbnail(guild.iconURL() || '') // A little visual memory of the server
    .setTimestamp(new Date());

  // Tossing the farewell embed into the designated channel
  infoChannel.send({ embeds: [farewellEmbed] }).catch(console.error); // Never forget to catch errors
});

// Akari Joined
client.on('guildCreate', guild => {
// this guild object is where your bot just plopped down in
// now let's pick out that special channel to drop our embed
const infoChannel = client.channels.cache.get('1226470223155298325');
if (!infoChannel) return; // if the channel's gone poof... well, we're outta luck

// crafting an embed with server's snazzy stats 
const welcomeEmbed = new EmbedBuilder()
.setColor(0x1ABC9C) // a splash of color, cos why not!
.setTitle('Just touched down in a new server! 🎉')
.setDescription(`I've just joined **${guild.name}**`)
.addFields(
{ name: 'Server Name', value: guild.name, inline: true },
{ name: 'Server ID', value: guild.id, inline: true },
{ name: 'Member Count', value: `${guild.memberCount}`, inline: true },
{ name: 'Region', value: guild.preferredLocale, inline: true }, // locale as a proxy for region
{ name: 'Owner', value: `<@${guild.ownerid}>`, inline: true },
)
.setThumbnail(guild.iconURL() || '') // server's icon, if it has one
.setTimestamp(new Date());

// let's fling that embed into the info channel
infoChannel.send({ embeds: [welcomeEmbed] }).catch(console.error); // not forgetting to catch any sneaky errors
});

//starboard
client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;

  if (interaction.commandName !== 'starboard') return;  
    const subcommand = interaction.options.getSubcommand();

    switch (subcommand) {
      case 'setup':
        const channelId = interaction.options.getChannel('channel').id;
        const limit = interaction.options.getInteger('limit');
        const emoji = interaction.options.getString('emoji');

        if (!interaction.member.permissions.has('MANAGE_GUILD')) {
          return interaction.reply({ content: 'Sorry, you need the Manage Server permission to do this.', ephemeral: true });
        }

        try {
          let config = await Starboard.findOne({ guildId: interaction.guildId });
          if (config) {
            config.channelId = channelId;
            config.limit = limit;
            config.emoji = emoji;
          } else {
            config = new Starboard({
              guildId: interaction.guildId,
              channelId: channelId,
              limit: limit,
              emoji: emoji
            });
          }

          await config.save();
          return interaction.reply({ content: 'Starboard has been set up successfully! Remeber server based emojis are not supported you can rerun if youve used it thanks!', ephemeral: true });
        } catch (error) {
          console.error(error);
          return interaction.reply({ content: 'An error occurred while setting up the starboard.', ephemeral: true });
        }
      break;

       case 'remove':
    if (!interaction.member.permissions.has('MANAGE_GUILD')) {
      return interaction.reply({ content: 'Sorry, you need the Manage Server permission to do this.', ephemeral: true });
    }
    
    try {
      const result = await Starboard.findOneAndDelete({ guildId: interaction.guildId });
      if (result) {
        return interaction.reply({ content: 'Starboard configuration has been successfully removed.', ephemeral: true });
      } else {
        return interaction.reply({ content: 'No starboard configuration found for this guild.', ephemeral: true });
      }
    } catch (error) {
      console.error(error);
      return interaction.reply({ content: 'An error occurred while trying to remove the starboard configuration.', ephemeral: true });
    }
  break;

      // case 'remove': 
      // ... handle the 'remove' subcommand here

      // Add more cases for other subcommands if necessary

      default:
        console.log(`Unrecognized subcommand: ${subcommand}`);
    }
  
});

// Welcome Ping Event
client.on('guildMemberAdd', async member => {
  // let's try to find a welcome setup for this guild
  const welcomeSettings = await WelcomePing.findOne({ guildId: member.guild.id });
  if (!welcomeSettings) return; // no welcome setup, no problem, we're done here

  // let's grab that welcome channel
  const welcomeChannel = member.guild.channels.cache.get(welcomeSettings.channelId);
  if (!welcomeChannel) return; // the channel's gone? weird. alright, moving on...

  // member username mention replacement
  let welcomeText = welcomeSettings.text.replace(/{user}/g, `<@${member.id}>`);

  // now we're shouting out to the world... well, to the server, that we've got a new pal!
  welcomeChannel.send(welcomeText);
}); 



//Welcome Ping

client.on('interactionCreate', async interaction => {
if (!interaction.isCommand()) return;
if(interaction.commandName !== "welcomeping") return;
const { commandName, options } = interaction;

if (commandName === 'welcomeping') {
const subcommand = options.getSubcommand();

if (subcommand === 'create') {
const guildId = interaction.guildId;
const channelId = options.getChannel('channel').id;
const text = options.getString('text');

// Create a new WelcomePing in the database
const newWelcomePing = await WelcomePing.create({ guildId, channelId, text });
await interaction.reply({ content: 'Welcome ping created!', ephemeral: true });
}

if (subcommand === 'delete') {
const guildId = interaction.guildId;
// Delete the WelcomePing from the database
await WelcomePing.findOneAndDelete({ guildId });
await interaction.reply({ content: 'Welcome ping deleted!', ephemeral: true });
}
}
}); 




client.on('messageReactionAdd', async (reaction, user) => {
  // ignore bot reactions and reactions in dms
  if (user.bot || !reaction.message.guild) return;

  try {
    // fetch starboard settings
    const settings = await Starboard.findOne({ guildId: reaction.message.guild.id });
    if (!settings) return; // peace out if there's no configuration

    // is this the chosen emoji?
    const isCorrectEmoji = reaction.emoji.id ? reaction.emoji.id === settings.emoji : reaction.emoji.name === settings.emoji;
    if (!isCorrectEmoji) return; // not the one, skip

    // has the reaction reached celestial limits?
    if (reaction.count >= settings.limit) {
      // let's find that starbound channel
      const starboardChannel = reaction.message.guild.channels.cache.get(settings.channelId);
      if (!starboardChannel) return; // vanished? nope, cancel mission

      // stop double stars
      const fetchedMessages = await starboardChannel.messages.fetch({ limit: 100 });
      const alreadyStarred = fetchedMessages.some(fetchedMsg =>
        fetchedMsg.embeds.length > 0 &&
        fetchedMsg.embeds[0].footer?.text.endsWith(reaction.message.id)
      );
      if (alreadyStarred) return; // it's a star already, abort!

      // showcase worthy embed comin' up
      const embed = new EmbedBuilder()
        .setColor(0xFFD700) // let's stick with the gold standard
        .setDescription(reaction.message.content)
        .setAuthor({
          name: reaction.message.author.tag,
          iconURL: reaction.message.author.displayAvatarURL(),
        })
        .setFooter({ text: `ID: ${reaction.message.id}` })
        .setTimestamp();

      // attachments anyone?
      const attachments = reaction.message.attachments;
      if (attachments.size > 0) {
        const image = attachments.find(attachment => attachment.url);
        if (image) embed.setImage(image.url);
      }

      // tying the message and launch sequence!
      await starboardChannel.send({ 
        content: `woohoo! <@${user.id}>'s message just hit superstar status! 🌟✨`,
        embeds: [embed]
      });
    }
  } catch (error) {
    // oh dear, something's up
    console.error('Error while handling reactions: ', error);
  }
}); 




client.on('interactionCreate', async interaction => {
if (!interaction.isCommand()) return;
if (interaction.commandName !== 'misc') return;

const targetUser = interaction.options.getUser('user');

switch (interaction.options.getSubcommand()) {
    case 'compliment':
        try {
            // Fetch a random compliment from the API using axios
            const response = await axios.get('https://api.rohitadhikari.com.np/api/compliment');
            const complimentEmbed = new EmbedBuilder()
                .setColor('Random') // Or any preferred hex color e.g., 0xff69b4
                .setTitle(`Hey ${targetUser.username}, you got a compliment!`)
                .setDescription(response.data.text)
                .setThumbnail(targetUser.displayAvatarURL())
                .setTimestamp();

            // Send the embed to the Discord channel
            await interaction.reply({ embeds: [complimentEmbed] });
        } catch (error) {
            console.error('Error fetching compliment: ', error);
            await interaction.reply({ content: 'Oops! I couldnot fetch a compliment right now. Try again later?', ephemeral: true });
        }
        break;

   case 'wink':
      try {
        // Fetch a random wink text from the API using axios
        const wresponse = await axios.get('https://api.rohitadhikari.com.np/api/wink');
        const winkEmbed = new EmbedBuilder()
          .setColor('Random') // Or any preferred hex color e.g., 0xff69b4
          .setTitle(`Here's a wink for you!`)
          .setDescription(wresponse.data.text) // Using "text" from API response
          .setTimestamp();

        // Send the embed to the Discord channel
        await interaction.reply({ embeds: [winkEmbed] });
      } catch (error) {
        console.error('Error fetching wink: ', error);
        await interaction.reply({ content: 'Oops! I couldnot fetch a wink right now. Try again later?', ephemeral: true });
      }
      break;

    case 'roast':
      try {
        // Fetch a random roast from the API using axios
        const response = await axios.get('https://api.rohitadhikari.com.np/api/roast');
        const roastEmbed = new EmbedBuilder()
          .setColor('Random') // Or any preferred hex color, e.g., 0x1f1f1f for a dark, roasty vibe
          .setTitle(`Oof, ${targetUser.username}, ${interaction.user.tag} roasted you!!`)
          .setDescription(response.data.text) // Using "text" from your API response
          .setThumbnail(targetUser.displayAvatarURL())
          .setTimestamp();

        // Send the embed to the Discord channel
        await interaction.reply({ embeds: [roastEmbed] });
      } catch (error) {
        console.error('Error fetching roast: ', error);
        await interaction.reply({ content: 'Oops! Looks like I burned the roast. Can not serve it right now, try again later?', ephemeral: true });
      }
      break;

    // ... other cases for misc subcommands
}
});



//Check VC
client.on('voiceStateUpdate', async (oldState, newState) => {
  // Check if someone joined the voice channel (not switching channels or just leaving)
  if (newState.channel && (!oldState.channel || oldState.channelId !== newState.channelId)) {
    const tempVCData = await TempVC.findOne({ guildId: newState.guild.id });

    // If the user joined the "Join to Create" channel and it's set up in the database
    if (tempVCData && newState.channelId === tempVCData.vcChannelId) {
      // Create a temporary voice channel
      const tempChannel = await newState.guild.channels.create({
  name: `${newState.member.user.username}'s VC`,
  type: ChannelType.GuildVoice,
  parent: newState.channel.parentId,
  permissionOverwrites: [
    {
      id: newState.guild.id,
      allow: [PermissionFlagsBits.ViewChannel],
      deny: [PermissionFlagsBits.Connect]
    },
    {
      id: newState.member.id,
      allow: [
        PermissionFlagsBits.ManageChannels,
        PermissionFlagsBits.Connect,
        PermissionFlagsBits.Speak,
        PermissionFlagsBits.MuteMembers,
        PermissionFlagsBits.DeafenMembers,
        PermissionFlagsBits.MoveMembers,
        PermissionFlagsBits.ManageRoles // Corrected from 'ManagePermissions'
      ]
    }
  ],
}).catch(console.error);

      // Move the member to the temporary voice channel
      newState.setChannel(tempChannel);

      // Add the temp channel info to the database
      tempVCData.createdTempChannels.push({
        tempChannelId: tempChannel.id,
        ownerId: newState.member.id
      });
      await tempVCData.save();
    }
  }

  // Check if someone left the voice channel (not just switching channels)
  if (oldState.channel && (!newState.channel || oldState.channelId !== newState.channelId)) { 
    // Fetch the temp voice channel
    const channel = oldState.channel;

    const tempVCData = await TempVC.findOne({ guildId: oldState.guild.id });
    const isManagedTempChannel = tempVCData && tempVCData.createdTempChannels.some(c => c.tempChannelId === channel.id);

    // If it's our temp channel and it's now empty, we delete it
    if (isManagedTempChannel && channel.members.size === 0) {
      await channel.delete().then(async () => {
        // Also filter out the channel from the database
        tempVCData.createdTempChannels = tempVCData.createdTempChannels.filter(c => c.tempChannelId !== channel.id);
        await tempVCData.save();
      }).catch(console.error); // Always good to handle errors gracefully
    }
  }
}); 


//Temp VC System
client.on('interactionCreate', async (interaction) => {
  //await interaction.deferReply();
// if(interaction.isButton || interaction.isSelectMenu) return;
  if (!interaction.isCommand()) return;
  if(interaction.commandName !== 'vc') return;
  // Check if the command is 'vc'
  const voiceChannel = interaction.member.voice.channel;
  if (interaction.commandName === 'vc') {
    const subcommand = interaction.options.getSubcommand();

    // Switch on the subcommand
    switch (subcommand) {
      case 'setup':
          await interaction.deferReply();
        // Admin check (optional)
        if (!interaction.member.permissions.has('ADMINISTRATOR')) {
          return interaction.reply({ content: 'You need to be an admin to run this command!', ephemeral: true });
        }

        // Create the "Join to Create" voice channel
        const vcChannel = await interaction.guild.channels.create({
	name: 'Join to Create', // Make sure the name is a string
	type: ChannelType.GuildVoice, // This should be the correct type enum for a voice channel
	// More options like permissions can be set here
		});

        // Create the text channel for instructions and button
        const textChannel = await interaction.guild.channels.create({
	name: 'vc-handler', // Make sure the name is a string
	type: ChannelType.GuildText, // This should be the correct type enum for a text channel
	// More options like permissions can be set here
		});


        // Send an embed with button in the text channel
        const embed = new EmbedBuilder()
          .setColor('#0099ff')
          .setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
          .setTitle('Voice Channel System')
          .setDescription('Join the "Join to Create" voice channel to create your own temporary voice channel.')
         .setFooter({ text: 'Powered By The Mavericks', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048' });

          
        const row = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('lockthevc')
              // .setLabel('Lock')
              .setEmoji('<:locking:1237688351302221834>')
              .setStyle(ButtonStyle.Primary),
              
            new ButtonBuilder()
              .setCustomId('unlockthevc')
              // .setLabel('Unlock')
              .setEmoji('<:unlocking:1237689538063630346>')
              .setStyle(ButtonStyle.Primary),
         
            new ButtonBuilder()
              .setCustomId('hidethevc')
            //  .setLabel('Hide')
              .setEmoji('<:vchide:1237690439327551510>')
              .setStyle(ButtonStyle.Primary),
         
            new ButtonBuilder()
              .setCustomId('unhidethevc')
             // .setLabel('Unhide')
              .setEmoji('<:vcunhide:1237690967415455766>')
              .setStyle(ButtonStyle.Primary),
          
            new ButtonBuilder()
              .setCustomId('limitthevc')
            //  .setLabel('Limit')
              .setEmoji('<:userthevc:1237691439832629300>')
              .setStyle(ButtonStyle.Primary)
          );
          const row2 = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('renamethevc')
              // .setLabel('Rename')
              .setEmoji('<:renamethevc:1237691982047088682>')
              .setStyle(ButtonStyle.Primary),
              new ButtonBuilder()
              .setCustomId('removelimitthevc')
             // .setLabel('Remove Limit')
              .setEmoji('<:0limitvc:1237692546147422239>')
              .setStyle(ButtonStyle.Primary),
              new ButtonBuilder()
              .setCustomId('bitratethevc')
             // .setLabel('Bitrate')
              .setEmoji('<:bitratevc:1237693246897913867>')
              .setStyle(ButtonStyle.Primary)
              );

        await textChannel.send({ embeds: [embed], components: [row, row2] });

        // Save the configuration to the database
        const tempVCData = new TempVC({
          guildId: interaction.guildId,
          vcChannelId: vcChannel.id, 
          textChannelId: textChannel.id,
          createdTempChannels: []
        });

        await tempVCData.save();

        interaction.followUp({ content: 'Voice system setup complete!', ephemeral: true });
        break;

       case 'remove':
  // Admin check (optional)
  if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
    return interaction.reply({ content: "You need to be an admin to run this command!", ephemeral: true });
  }

  // Find and delete the guild data in your database
  await TempVC.deleteOne({ guildId: interaction.guildId })
    .then(() => {
      interaction.reply({ content: "All data for this guild has been removed.", ephemeral: true });
    })
    .catch((error) => {
      console.error('Error removing the guild data:', error);
      interaction.reply({ content: "There was an error while removing the guild data.", ephemeral: true });
    });
  break;
   case 'unlock':
  try {
    const tempChannel = await vcUnlock(interaction.member);
    interaction.reply({ content: `Your Voice Channel Unlocked`, ephemeral: true });
  } catch (error) {
    interaction.reply({ content: error.message, ephemeral: true });
  }
 break;

 case 'lock':
  try { 
 
    const tempChannel = await vcLock(interaction.member);
    interaction.reply({ content: `Locked the voice channel: ${tempChannel.name}`, ephemeral: true });
  } catch (error) {
    interaction.reply({ content: error.message, ephemeral: true });
  }
break;

  case 'hide':
	try {
  const tempChannel = await vcHide(interaction.member);
  interaction.reply({ content: `The voice channel ${tempChannel.name} is now hidden.`, ephemeral: true });
	} catch (error) {
  interaction.reply({ content: error.message, ephemeral: true });
	}
	break;

   case 'unhide':
     try {
    const tempChannel = await vcUnhide(interaction.member);
    interaction.reply({ content: `The voice channel ${tempChannel.name} is no longer hidden.`, ephemeral: true });
      } catch (error) {
    interaction.reply({ content: error.message, ephemeral: true });
       }
     break;
  
  case 'rename':
   try {
      
        await promptRenameVC(interaction);

      } catch (error) {

	interaction.reply("something went wrong");
         console.log(error);
     }
    break;

   case 'limit':
   try {

        await promptUserLimitVC(interaction);

      } catch (error) {

        interaction.reply("something went wrong");
         console.log(error);
     }
    break;

  case 'removelimit':
     const { removed, reason } = await removeLimit(interaction.member);

     if (!removed) {
      return interaction.reply({ content: reason, ephemeral: true });
        }

     return interaction.reply({ content: 'The user limit has been removed from the voice channel.', ephemeral: true });
     break;

    case 'transfer':
	// Ensure member is in a voice channel
//	const voiceChannel = interaction.member.voice.channel;
	if (!voiceChannel) {
	return interaction.reply({ content: "You're not in a voice channel.", ephemeral: true });
	}

	const userToTransferTo = interaction.options.getUser('user');
	if (!userToTransferTo) {
	return interaction.reply({ content: "You didn't specify a user to transfer ownership to.", ephemeral: true });
	}

	const { transferred, reasonn } = await transferOwnership(interaction.member, userToTransferTo.id, voiceChannel.id, interaction.guild.id);

	if (!transferred) {
	return interaction.reply({ content: reasonn, ephemeral: true });
	} 
	return interaction.reply({ content: `Ownership has been transferred to <@${usertotransferto.id}>.`, ephemeral: true });
	break;

	case 'claim':
	const voiceChannel = interaction.member.voice.channel;
	if (!voiceChannel) {
	return interaction.reply({ content: "You're not in a voice channel.", ephemeral: true });
	}

	const { claimed, reasons } = await claimVC(interaction.member, voiceChannel.id, interaction.guild.id);

	if (!claimed) {
	return interaction.reply({ content: "something went wrong..", ephemeral: true });
	}

	return interaction.reply({ content: `You have claimed the voice channel.`, ephemeral: true });
	break;

	case 'bitrate':
         try {

        await promptChangeBitrateModal(interaction);

         } catch (error) {

        interaction.reply("something went wrong");
         console.log(error);
     	}
        break;

	case 'kick':
      // Ensure the executor is in a voice channel
//      const voiceChannel = interaction.member.voice.channel;
      if (!voiceChannel) {
        return interaction.reply({ content: "You need to be in a voice channel to use this command.", ephemeral: true });
      }

      // Get the user that needs to be kicked from the voice channel
      const userToKick = interaction.options.getMember('user');
      if (!userToKick) {
        return interaction.reply({ content: "Please specify a user to kick from the voice channel.", ephemeral: true });
      }

      // Kick functionality - calling your previously defined function
      const { success, reasoning } = await kickFromVC(voiceChannel.id, interaction.member, userToKick);

      // Handle the outcome of the kick attempt
      if (success) {
        return interaction.reply({ content: `<@${usertokick.id}> has been kicked from the voice channel.`, ephemeral: true });
      } else {
        return interaction.reply({ content: reasoning, ephemeral: true });
      }
      break;

     // ...handle other subcommands here...
    }
  }
});


//Bitrate Change
async function promptChangeBitrateModal(interaction) {
const modal = new ModalBuilder()
.setCustomId('changeBitrateVC')
.setTitle('Change Voice Channel Bitrate')
.addComponents(
new ActionRowBuilder().addComponents(
new TextInputBuilder()
.setCustomId('vcBitrate')
.setLabel('Enter the new bitrate (in kbps):')
.setStyle(TextInputStyle.Short)
.setMinLength(1)
.setMaxLength(4)
.setPlaceholder('8-96 for regular, 8-128 for Level 1, up to 384 for Level 3')
.setRequired(true)
)
);

await interaction.showModal(modal);
}

client.on('interactionCreate', async interaction => {
// if(interaction.isButton) return; 
 if (interaction.type === InteractionType.ModalSubmit && interaction.customId === 'changeBitrateVC') {
    const bitrateString = interaction.fields.getTextInputValue('vcBitrate');
    const bitrate = parseInt(bitrateString, 10) * 1000; // Convert kbps to bps

    if (isNaN(bitrate) || bitrate < 8000 || bitrate > 128000) { // Assuming Level 1 server max 128kbps
      return interaction.reply({ content: 'Please enter a valid bitrate number within your server boost level limits.', ephemeral: true });
    }

    const voiceChannel = interaction.member.voice.channel;
    if (!voiceChannel) {
      return interaction.reply({ content: "You're not in a voice channel.", ephemeral: true });
    }

    const { canSet, reason } = await canSetLimit(interaction.member);
    if (!canSet) {
      return interaction.reply({ content: reason, ephemeral: true });
    }

    try {
      await voiceChannel.setBitrate(bitrate);
      interaction.reply({ content: `Voice channel bitrate set to ${bitrate / 1000} kbps.`, ephemeral: true });
    } catch (error) {
      console.error(error);
      interaction.reply({ content: `Error changing bitrate: ${error.message}`, ephemeral: true });
    }
  }
});


//Kick From VC
async function kickFromVC(voiceChannelId, ownerMember, memberToKick) {
  // Fetch the voice channel data from MongoDB
  const vcData = await TempVC.findOne({
    'createdTempChannels.tempChannelId': voiceChannelId
  });

  // Extract the owner ID from the data
  const ownerId = vcData?.createdTempChannels.find(c => c.tempChannelId === voiceChannelId)?.ownerId;

  // Check if the member is actually the owner of the VC
  if (ownerId && ownerId === ownerMember.id) {
    // Check if the user to kick is in the same voice channel
    if (memberToKick.voice.channelId === voiceChannelId) {
      try {
        await memberToKick.voice.disconnect('Kicked by the voice channel owner.');
        return { success: true };
      } catch (error) {
        console.error(error);
        return { success: false, reason: `Error kicking user: ${error.message}` };
      }
    } else {
      return { success: false, reason: 'The user you are trying to kick is not in your voice channel.' };
    }
  } else {
    return { success: false, reason: 'You are not the owner of this voice channel.' };
  }
}



//Claim VC

async function claimVC(member, voiceChannelId, guildId) {
try {
const tempVCData = await TempVC.findOne({ guildId: guildId });

if (!tempVCData) {
return { claimed: false, reason: 'No temporary voice channels found for this guild.' };
}

const managedChannel = tempVCData.createdTempChannels.find(c => c.tempChannelId === voiceChannelId);

if (!managedChannel) {
return { claimed: false, reason: 'This voice channel is not managed by the bot.' };
}

// Check if the current owner is still in the VC
const currentOwner = member.guild.members.cache.get(managedChannel.ownerId);
if (currentOwner && currentOwner.voice.channelId === voiceChannelId) {
return { claimed: false, reason: 'The current owner is still in the voice channel.' };
}

// Set the new owner
managedChannel.ownerId = member.id;

await tempVCData.save();
return { claimed: true };
} catch (error) {
console.error(error);
return { claimed: false, reason: `Error claiming ownership: ${error.message}` };
}
}

// Transfer Ownership
async function transferOwnership(currentOwner, newOwnerId, voiceChannelId, guildId) {
try {
const tempVCData = await TempVC.findOne({ guildId: guildId });

if (!tempVCData) {
return { transferred: false, reason: 'No temporary voice channels found for this guild.' };
}

// Check if the voice channel is managed by the bot
const managedChannel = tempVCData.createdTempChannels.find(c => c.tempChannelId === voiceChannelId);

if (!managedChannel) {
return { transferred: false, reason: 'This voice channel is not managed by the bot.' };
}

// Check if the member is the owner of the VC
if (managedChannel.ownerId !== currentOwner.id) {
return { transferred: false, reason: 'You are not the owner of this voice channel, so you cannot transfer it.' };
}

// Transfer ownership
managedChannel.ownerId = newOwnerId;

await tempVCData.save();
return { transferred: true };
} catch (error) {
console.error(error);
return { transferred: false, reason: `Error transferring ownership: ${error.message}` };
}
}

// Remove Limit
async function removeLimit(member) {
const voiceChannel = member.voice.channel;

if (!voiceChannel) {
return { removed: false, reason: 'You are not in a voice channel.' };
}

const tempVCData = await TempVC.findOne({ guildId: member.guild.id });

if (!tempVCData) {
return { removed: false, reason: 'No temporary voice channels found for this guild.' };
}

const managedChannel = tempVCData.createdTempChannels.find(c => c.tempChannelId === voiceChannel.id);

if (!managedChannel) {
return { removed: false, reason: 'This voice channel is not managed by the bot.' };
}

if (managedChannel.ownerId !== member.id) {
return { removed: false, reason: 'You are not the owner of this voice channel.' };
}

try {
await voiceChannel.setUserLimit(0);
return { removed: true };
} catch (error) {
console.error(error);
return { removed: false, reason: `Error removing user limit: ${error.message}` };
}
}

//Limit VC
async function promptUserLimitVC(interaction) {
// Create a text input component for the user limit
const limitInput = new TextInputBuilder()
.setCustomId('vcUserLimit')
.setLabel("Enter the maximum number of users:")
.setStyle(TextInputStyle.Short)
.setMinLength(1)
.setMaxLength(2)
.setPlaceholder('1-99')
.setRequired(true);

// Create an action row and add the text input component to it
const firstActionRow = new ActionRowBuilder().addComponents(limitInput);

// Create a modal and add the action row to it
const modal = new ModalBuilder()
.setCustomId('setUserLimitVC')
.setTitle('Set Voice Channel User Limit')
.addComponents(firstActionRow);

// Show the modal to the user
await interaction.showModal(modal);
}

client.on('interactionCreate', async interaction => {
//if(interaction.isButton || interaction.isSelectMenu) return;
  if (interaction.type === InteractionType.ModalSubmit && interaction.customId === 'setUserLimitVC') {
    const userLimitString = interaction.fields.getTextInputValue('vcUserLimit');
    const userLimit = parseInt(userLimitString, 10);

    // Validate user limit
    if (isNaN(userLimit) || userLimit < 1 || userLimit > 99) {
      return interaction.reply({ content: 'Please enter a valid number between 1 and 99.', ephemeral: true });
    }

    // Check if the user can set the limit
    const { canSet, reason } = await canSetLimit(interaction.member);

    if (!canSet) {
      return interaction.reply({ content: reason, ephemeral: true });
    }

    // Set the user limit on the voice channel
    try {
      await interaction.member.voice.channel.setUserLimit(userLimit);
      interaction.reply({ content: `User limit set to ${userLimit}.`, ephemeral: true });
    } catch (error) {
      console.error(error); // It's good practice to log the error
      interaction.reply({ content: `Error setting user limit: ${error.message}`, ephemeral: true });
    }
  }
}); 



async function canSetLimit(member) {
  const voiceChannel = member.voice.channel;
  
  if (!voiceChannel) {
    return { canSet: false, reason: 'You are not in a voice channel.' };
  }

  // Fetch the associated temp VC data for the guild
  const tempVCData = await TempVC.findOne({ guildId: member.guild.id });

  if (!tempVCData) {
    return { canSet: false, reason: 'No temporary voice channels found for this guild.' };
  }

  // Find the temp VC that the member is currently in, if managed by the bot
  const managedChannel = tempVCData.createdTempChannels.find(c => c.tempChannelId === voiceChannel.id);

  if (!managedChannel) {
    return { canSet: false, reason: 'This voice channel is not managed by the bot.' };
  }

  // Check if the member is the owner of the VC
  if (managedChannel.ownerId !== member.id) {
    return { canSet: false, reason: 'You are not the owner of this voice channel.' };
  }

  return { canSet: true };
} 



// Rename VC
async function promptRenameVC(interaction) {
    // Create a text input component for the new name
    const nameInput = new TextInputBuilder()
        .setCustomId('newVCName')
        .setLabel("What should be the new name?")
        .setStyle(TextInputStyle.Short)
        .setMinLength(1)
        .setMaxLength(100)
        .setPlaceholder('Enter the new name for your voice channel')
        .setRequired(true);

    // Create an action row and add the text input component to it
    const firstActionRow = new ActionRowBuilder().addComponents(nameInput);

    // Create a modal and add the action row to it
    const modal = new ModalBuilder()
        .setCustomId('renameVC')
        .setTitle('Rename Voice Channel')
        .addComponents(firstActionRow);

    // Show the modal to the user
    await interaction.showModal(modal, {
        client: interaction.client,
        interaction: interaction
    });
}

client.on('interactionCreate', async (interaction) => {
    if (interaction.isModalSubmit() && interaction.customId === 'renameVC') {
        const newName = interaction.fields.getTextInputValue('newVCName');
        const member = interaction.member;
        const voiceChannel = member.voice.channel;

        if (!voiceChannel) {
            return interaction.reply({ content: 'You need to be in a voice channel to use this command.', ephemeral: true });
        }

        try {
            // Fetch the guild data to check if the VC is managed by the bot
            const guildData = await TempVC.findOne({ guildId: member.guild.id });
            const tempChannelData = guildData?.createdTempChannels.find(c => c.tempChannelId === voiceChannel.id);

            if (!tempChannelData) {
                throw new Error('This command can only be used on voice channels managed by the bot.');
            }

            // Check if the member is the owner of the VC
            if (tempChannelData.ownerId !== member.id) {
                throw new Error('You must be the owner of the voice channel to rename it.');
            }

            // Everything checks out, let's rename the VC
            await voiceChannel.setName(newName); 
            interaction.reply({ content: `Voice channel renamed to: ${newName}`, ephemeral: true });
        } catch (error) {
            console.error(error);
            interaction.reply({ content: `Error: ${error.message}`, ephemeral: true });
        }
    }
});

// Function to handle unHide Command
async function vcUnhide(member) {
  // Fetch guild data
  const guildData = await TempVC.findOne({ guildId: member.guild.id });
  if (!guildData) {
    throw new Error('No configuration for temporary voice channels found.');
  }

  // Get the member's current voice channel ID
  const memberVoiceChannelId = member.voice.channelId;
  if (!memberVoiceChannelId) {
    throw new Error('You need to be in a voice channel to use this command.');
  }

  // Fetch the voice channel using the ID
  const voiceChannel = member.guild.channels.cache.get(memberVoiceChannelId);
  if (!voiceChannel) {
    throw new Error('Voice channel not found.');
  }

  // Check if the VC is a temporary one we manage and if the member is the owner
  const tempChannelData = guildData.createdTempChannels.find(c => c.tempChannelId === voiceChannel.id);
  if (!tempChannelData || tempChannelData.ownerId !== member.id) {
    throw new Error('You must be the owner of this temporary voice channel to unhide it.');
  }

  // Update permissions to make the channel visible again
  await voiceChannel.permissionOverwrites.delete(voiceChannel.guild.roles.everyone.id);

  return voiceChannel;
}


//function to handle hide command

async function vcHide(member) {
// Fetch guild data
const guildData = await TempVC.findOne({ guildId: member.guild.id });
if (!guildData) {
  throw new Error('No configuration for temporary voice channels found.');
}

// Get the member's current voice channel ID
const memberVoiceChannelId = member.voice.channelId;
if (!memberVoiceChannelId) {
  throw new Error('You need to be in a voice channel to use this command.');
}

// Fetch the voice channel using the ID
const voiceChannel = member.guild.channels.cache.get(memberVoiceChannelId);
if (!voiceChannel) {
  throw new Error('Voice channel not found.');
}

// Check if the VC is a temporary one we manage and if the member is the owner
const tempChannelData = guildData.createdTempChannels.find(c => c.tempChannelId === voiceChannel.id);
if (!tempChannelData || tempChannelData.ownerId !== member.id) {
  throw new Error('You must be the owner of this temporary voice channel to hide it.');
}

// Update permissions to hide the channel from everyone
await voiceChannel.permissionOverwrites.set([
  {
    id: voiceChannel.guild.roles.everyone,
    deny: [PermissionsBitField.Flags.ViewChannel],
  },
  ...voiceChannel.members.map(member => ({
    id: member.id,
    allow: [PermissionsBitField.Flags.ViewChannel],
  }))
]);

return voiceChannel;
}


//function to handle lock command
async function vcLock(member) {
  // Fetch guild data
  const guildData = await TempVC.findOne({ guildId: member.guild.id });
  if (!guildData) {
    throw new Error('No configuration for temporary voice channels found.');
  }

  // Get the member's current voice channel ID
  const memberVoiceChannelId = member.voice.channelId;
  if (!memberVoiceChannelId) {
    throw new Error('You need to be in a voice channel to use this command.');
  }

  // Fetch the voice channel using the ID
  const voiceChannel = member.guild.channels.cache.get(memberVoiceChannelId);
  if (!voiceChannel) {
    throw new Error('Voice channel not found.');
  }

  // Check if the VC is a temporary one we manage and if the member is the owner
  const tempChannelData = guildData.createdTempChannels.find(c => c.tempChannelId === voiceChannel.id);
  if (!tempChannelData || tempChannelData.ownerId !== member.id) {
    throw new Error('You must be the owner of this temporary voice channel to lock it.');
  }

  // Update permissions so only current channel members can connect
  const currentMembers = voiceChannel.members.map(member => member.id);
  // First deny everyone to connect
  await voiceChannel.permissionOverwrites.edit(voiceChannel.guild.roles.everyone, {
    Connect: false,
  });

  // Then, override permissions to allow current members to connect
  currentMembers.forEach(async memberId => {
    await voiceChannel.permissionOverwrites.edit(memberId, {
      Connect: true
    }).catch(console.error);
  });

  return voiceChannel;
}


//function to handle unlock commamd
async function vcUnlock(member) {
  // Fetch guild data
  const guildData = await TempVC.findOne({ guildId: member.guild.id });
  if (!guildData) {
    throw new Error('No configuration for temporary voice channels found.');
  }

  // Get the member's current voice channel ID
  const memberVoiceChannelId = member.voice.channelId;
  if (!memberVoiceChannelId) {
    throw new Error('You need to be in a voice channel to use this command.');
  }

  // Fetch the voice channel using the ID
  const voiceChannel = member.guild.channels.cache.get(memberVoiceChannelId);
  if (!voiceChannel) {
    throw new Error('Voice channel not found.');
  }

  // Check if the VC is a temporary one we manage
  const isTempVC = guildData.createdTempChannels.some(c => c.tempChannelId === voiceChannel.id);
  if (!isTempVC) {
    throw new Error('This command can only be used in a temporary voice channel created by the bot.');
  }

  const tempChannelData = guildData.createdTempChannels.find(c => c.tempChannelId === voiceChannel.id);
  if (!tempChannelData || tempChannelData.ownerId !== member.id) {
  throw new Error('You must be the owner of this temporary voice channel to unlock it.');
   }


  // Update permissions for everyone to join this VC
  await voiceChannel.permissionOverwrites.edit(voiceChannel.guild.roles.everyone, {
    Connect: true,
  }).catch(console.error);

  return voiceChannel;
}



//role created
client.on('roleCreate', async (role) => {
const loggingConfig = await Logging.findOne({ guildId: role.guild.id });
if (!loggingConfig || !loggingConfig.serverLogs) return;

const logChannel = role.guild.channels.cache.get(loggingConfig.serverLogs);
if (!logChannel) return;

const roleCreateEmbed = new EmbedBuilder()
.setTitle('Role Created')
.setColor(0x00FF00) // Green for creation
.setDescription(`**Role**: ${role.name}**ID**: ${role.id}`)
.setTimestamp();

logChannel.send({ embeds: [roleCreateEmbed] }).catch(console.error);
}); 

//role Delete
client.on('roleDelete', async (role) => {
const loggingConfig = await Logging.findOne({ guildId: role.guild.id });
if (!loggingConfig || !loggingConfig.serverLogs) return;

const logChannel = role.guild.channels.cache.get(loggingConfig.serverLogs);
if (!logChannel) return;

const roleDeleteEmbed = new EmbedBuilder()
.setTitle('Role Deleted')
.setColor(0xFF0000) // Red for deletion
.setDescription(`**Role**: ${role.name}**ID**: ${role.id}`)
.setTimestamp();

logChannel.send({ embeds: [roleDeleteEmbed] }).catch(console.error);
}); 

// Role updated
client.on('roleUpdate', async (oldRole, newRole) => {
const loggingConfig = await Logging.findOne({ guildId: newRole.guild.id });
if (!loggingConfig || !loggingConfig.serverLogs) return;

const logChannel = newRole.guild.channels.cache.get(loggingConfig.serverLogs);
if (!logChannel) return;

// Check for permission changes
const oldPermissions = oldRole.permissions.toArray();
const newPermissions = newRole.permissions.toArray();
const permissionChanges = {
added: newPermissions.filter(x => !oldPermissions.includes(x)),
removed: oldPermissions.filter(x => !newPermissions.includes(x))
};

// Build the description string
let description = `**Role**: ${newRole.name}**ID**: ${newRole.id}`;

if (permissionChanges.added.length || permissionChanges.removed.length) {
description += ' **Permissions Updated:**';
if (permissionChanges.added.length) {
description += `Added: ${permissionChanges.added.join(', ')}`;
}
if (permissionChanges.removed.length) {
description += `Removed: ${permissionChanges.removed.join(', ')}`;
}
}

const roleUpdateEmbed = new EmbedBuilder()
.setTitle('Role Updated')
.setColor(0xFFFF00) // Yellow for updates
.setDescription(description)
.setTimestamp();

logChannel.send({ embeds: [roleUpdateEmbed] }).catch(console.error);
}); 
//Unban Events
client.on('guildBanRemove', async (ban) => {
const loggingConfig = await Logging.findOne({ guildId: ban.guild.id });
if (!loggingConfig || !loggingConfig.memberLogs) return;

const logChannel = ban.guild.channels.cache.get(loggingConfig.memberLogs);
if (!logChannel) return;

const unbanEmbed = new EmbedBuilder()
.setTitle('Member Unanned')
.setColor(0xFF0000) // Red for bans
.setDescription(`**User**: ${ban.user.tag}
**ID**: ${ban.user.id}`)
.setThumbnail(ban.user.displayAvatarURL())
.setTimestamp();

logChannel.send({ embeds: [unbanEmbed] }).catch(console.error);
}); 


// Kick Events
client.on('guildMemberRemove', async (member) => {
const loggingConfig = await Logging.findOne({ guildId: member.guild.id });
if (!loggingConfig || !loggingConfig.memberLogs) return;

const logChannel = member.guild.channels.cache.get(loggingConfig.memberLogs);
if (!logChannel) return;

// Fetching entries from the Audit Log to check for kick
const auditLog = await member.guild.fetchAuditLogs({ type: 22, limit: 1 });
const kickLog = auditLog.entries.first(); 
const currentTime = new Date().getTime();
const timeDiff = currentTime - kickLog.createdTimestamp;

if (kickLog.target.id === member.id && kickLog.executor.id !== member.id && timeDiff < 5000) {
// This implies a kick
const kickEmbed = new EmbedBuilder()
.setTitle('Member Kicked')
.setColor(0xFFA500) // Orange color for kicks
.setDescription(`**User**: ${member.user.tag}**ID**: ${member.user.id}**By**: ${kickLog.executor.tag}`)
.setThumbnail(member.user.displayAvatarURL())
.setTimestamp();

logChannel.send({ embeds: [kickEmbed] }).catch(console.error);
} else {
  return;
// A regular leave, not a kick
// Handle regular leave if needed...
}
}); 

// Ban Events
client.on('guildBanAdd', async (ban) => {
const loggingConfig = await Logging.findOne({ guildId: ban.guild.id });
if (!loggingConfig || !loggingConfig.memberLogs) return;

const logChannel = ban.guild.channels.cache.get(loggingConfig.memberLogs);
if (!logChannel) return;

const banEmbed = new EmbedBuilder()
.setTitle('Member Banned')
.setColor(0xFF0000) // Red for bans
.setDescription(`**User**: ${ban.user.tag}**ID**: ${ban.user.id}`)
.setThumbnail(ban.user.displayAvatarURL())
.setTimestamp();

logChannel.send({ embeds: [banEmbed] }).catch(console.error);
}); 

// Memeber Events 
client.on('guildMemberUpdate', async (oldMember, newMember) => {
  const loggingConfig = await Logging.findOne({ guildId: newMember.guild.id });
  if (!loggingConfig || !loggingConfig.memberLogs) return;

  const logChannel = newMember.guild.channels.cache.get(loggingConfig.memberLogs);
  if (!logChannel) return;

  const changes = [];

  // Name change
  if (oldMember.user.username !== newMember.user.username) {
    changes.push(`**Username Change**: \`${oldMember.user.username}\` ➤ \`${newMember.user.username}\``);
  }

  // Nickname change
  if (oldMember.nickname !== newMember.nickname) {
    const oldNick = oldMember.nickname || '[None]';
    const newNick = newMember.nickname || '[None]';
    changes.push(`**Nickname Change**: \`${oldNick}\` ➤ \`${newNick}\``);
  }

  // Avatar change
  if (oldMember.user.displayAvatarURL() !== newMember.user.displayAvatarURL()) {
    changes.push(`**Avatar Change**: Avatar has been updated.`);
  }

  // Role updates
  const oldRoles = [...oldMember.roles.cache.keys()];
  const newRoles = [...newMember.roles.cache.keys()];
  const addedRoles = newRoles.filter(role => !oldRoles.includes(role));
  const removedRoles = oldRoles.filter(role => !newRoles.includes(role));

  if (addedRoles.length) {
    const addedRoleNames = addedRoles.map(roleId => newMember.guild.roles.cache.get(roleId)?.name).filter(name => name);
    changes.push(`**Roles Added**: ${addedRoleNames.join(', ')}`);
  }

  if (removedRoles.length) {
    const removedRoleNames = removedRoles.map(roleId => oldMember.guild.roles.cache.get(roleId)?.name).filter(name => name);
    changes.push(`**Roles Removed**: ${removedRoleNames.join(', ')}`);
  }

  // Timeout changes
  const oldTimeout = oldMember.communicationDisabledUntilTimestamp; 
  const newTimeout = newMember.communicationDisabledUntilTimestamp;
  if (newTimeout !== oldTimeout) {
    if (newTimeout && newTimeout > Date.now()) {
      const timeoutDuration = new Date(newTimeout) - new Date();
      const hours = Math.floor(timeoutDuration / 1000 / 60 / 60);
      const minutes = Math.round((timeoutDuration / 1000 / 60) % 60);
      changes.push(`**Timeout**: User has been timed out for ${hours > 0 ? `${hours} hours and ` : ''}${minutes} minutes.`);
    } else if (oldTimeout && newTimeout === null) {
      changes.push(`**Timeout Lifted**: User's timeout has been removed.`);
    }
  }

  // Send changes in an embed if there are any
  if (changes.length) {
    const updateEmbed = new EmbedBuilder()
      .setTitle('Member Update')
      .setDescription(changes.join('')) // Changes joined with newline for readability
      .setColor(0x3498DB) // Use whatever color you like or matches your bot's theme
      .setTimestamp()
      .setFooter({ text: `Member ID: ${newMember.id}`, iconURL: newMember.user.displayAvatarURL() });

    logChannel.send({ embeds: [updateEmbed] }).catch(console.error);
  }
}); 

// Guild Update Event - for Server Icon, Banner, and Name Changes
client.on('guildUpdate', async (oldGuild, newGuild) => {
const loggingConfig = await Logging.findOne({ guildId: newGuild.id });
if (!loggingConfig || !loggingConfig.serverLogs) return;

const logChannel = newGuild.channels.cache.get(loggingConfig.serverLogs);
if (!logChannel) return;

let updates = [];

// Check for server name change
if (oldGuild.name !== newGuild.name) {
updates.push(`**Name Change**: \`${oldGuild.name}\` ➤ \`${newGuild.name}\``);
}

// Check for server icon change
if (oldGuild.iconURL() !== newGuild.iconURL()) {
updates.push(`**Icon Change**: The server icon has been updated.`);
}

// Check for server banner change
if (oldGuild.bannerURL() !== newGuild.bannerURL()) {
updates.push(`**Banner Change**: The server banner has been updated.`);
}

// If there are updates, send them as a message
if (updates.length) {
const updateEmbed = new EmbedBuilder()
.setTitle('Server Updates')
.setColor(0xFFA500) // Orange color for updates
.setDescription(updates.join(''))
.setTimestamp()
.setFooter({ text: 'Server Update Information', iconURL: newGuild.iconURL() });

logChannel.send({ embeds: [updateEmbed] }).catch(console.error);
}
}); 

// Channel Update Event - Specifically for Permission Overwrites
client.on('channelUpdate', async (oldChannel, newChannel) => {
  const loggingConfig = await Logging.findOne({ guildId: newChannel.guild.id });
  if (!loggingConfig || !loggingConfig.serverLogs) return;

  const logChannel = newChannel.guild.channels.cache.get(loggingConfig.serverLogs);
  if (!logChannel) return;

  // Check for permission overwrites changes
  if (!oldChannel.permissionOverwrites.cache.equals(newChannel.permissionOverwrites.cache)) {
    // Identify what has been changed, added, or removed
    const changes = newChannel.permissionOverwrites.cache.difference(oldChannel.permissionOverwrites.cache);
    const addedPermissions = changes.filter(change => change.allow.bitfield !== '0' || change.deny.bitfield !== '0');
    
    // Formatting permissions for the message; you might want to define a helper function to translate permissions to human-readable form
    const formattedPermissions = addedPermissions.map(perm => 
      `**${perm.type === 'role' ? 'Role' : 'Member'}**: ${perm.type === 'role' ? newChannel.guild.roles.cache.get(perm.id).name : newChannel.guild.members.cache.get(perm.id).user.tag}` +
      `**Allowed**: ${perm.allow.toArray().join(', ') || 'None'}` +
      `**Denied**: ${perm.deny.toArray().join(', ') || 'None'}` ).join('');

    if (formattedPermissions) {
      const category = newChannel.parent ? newChannel.parent.name : 'No Category';
      const permissionsEmbed = new EmbedBuilder()
        .setTitle('Permission Overwrites Updated')
        .setColor(0xFFA500) // Orange color
        .addFields(
          { name: 'Channel', value: newChannel.name, inline: true },
          { name: 'Category', value: category, inline: true },
          { name: 'Changes', value: formattedPermissions, inline: false },
        )
        .setTimestamp()
        .setFooter({ text: 'Channel Permission Overwrite Update', iconURL: newChannel.guild.iconURL() }); 
      logChannel.send({ embeds: [permissionsEmbed] }).catch(console.error);
    }
  }
}); 

//channl name changes
// Channel Update Event for Name Change
client.on('channelUpdate', async (oldChannel, newChannel) => {
    const loggingConfig = await Logging.findOne({ guildId: newChannel.guild.id });
    if (!loggingConfig || !loggingConfig.serverLogs) return;

    const logChannel = newChannel.guild.channels.cache.get(loggingConfig.serverLogs);
    if (!logChannel) return;

    // Check if the channel name has been updated
    if (oldChannel.name !== newChannel.name) {
        const category = newChannel.parent ? newChannel.parent.name : 'No Category';
        const nameChangeEmbed = new EmbedBuilder()
            .setTitle('Channel Name Changed')
            .setColor(0xFFA500) // Orange color
            .addFields(
                { name: 'Old Name', value: oldChannel.name, inline: true },
                { name: 'New Name', value: newChannel.name, inline: true },
                { name: 'Category', value: category, inline: true },
            )
            .setTimestamp()
            .setFooter({ text: 'Channel Name Change', iconURL: newChannel.guild.iconURL() });

        logChannel.send({ embeds: [nameChangeEmbed] }).catch(console.error);
    }
}); 


//Channel Create & Delete
// Channel Create Event
client.on('channelCreate', async (channel) => {
  // First, check if the created channel is indeed a category
    if (channel.type !== ChannelType.GuildCategory) return;
  const loggingConfig = await Logging.findOne({ guildId: channel.guild.id });
  if (!loggingConfig || !loggingConfig.serverLogs) return;

  const logChannel = channel.guild.channels.cache.get(loggingConfig.serverLogs);
  if (!logChannel) return;

  const createEmbed = new EmbedBuilder()
    .setTitle('Category Created')
    .setColor(0x00FF00) // Green color for creation
    .addFields({ name: 'Category', value: channel.name, inline: true })
    .setTimestamp()
    .setFooter({ text: 'Category Creation', iconURL: channel.guild.iconURL() });

  logChannel.send({ embeds: [createEmbed] }).catch(console.error);
});


client.on('channelCreate', async (channel) => {
    const loggingConfig = await Logging.findOne({ guildId: channel.guild.id });
    if (!loggingConfig || !loggingConfig.serverLogs) return;

    const logChannel = channel.guild.channels.cache.get(loggingConfig.serverLogs);
    if (!logChannel) return;
    
    // Get the channel type name using the ChannelType enum
    const channelType = channel.type;
    let channelTypeName;
    switch (channelType) {
        case ChannelType.GuildText:
            channelTypeName = 'Text Channel';
            break;
        case ChannelType.GuildVoice:
            channelTypeName = 'Voice Channel';
            break;
        // Add cases for other channel types if you want
        default:
            channelTypeName = 'Other';
    }

    const category = channel.parent ? channel.parent.name : 'No Category';

    const createEmbed = new EmbedBuilder()
        .setTitle('Channel Created')
        .setColor(0x00FF00) // Green color
        .addFields(
            { name: 'Channel', value: channel.name, inline: true },
            { name: 'Type', value: channelTypeName, inline: true },
            { name: 'Category', value: category, inline: true },
        )
        .setTimestamp()
        .setFooter({ text: 'Channel Creation', iconURL: channel.guild.iconURL() });

    logChannel.send({ embeds: [createEmbed] }).catch(console.error);
});


// Channel Delete Event
client.on('channelDelete', async (channel) => {
  try {
    const loggingConfig = await Logging.findOne({ guildId: channel.guild.id });
    if (!loggingConfig || !loggingConfig.serverLogs) return;

    const logChannel = channel.guild.channels.cache.get(loggingConfig.serverLogs);
    if (!logChannel) return;

    const category = channel.parent ? channel.parent.name : 'No Category';

    const deleteEmbed = new EmbedBuilder()
      .setTitle('Channel Deleted')
      .setColor(0xFF0000) // Red color
      .addFields(
        { name: 'Channel', value: channel.name, inline: true },
        // Here you would convert channel.type to a string representing the type, as before
        { name: 'Category', value: category, inline: true },
      )
      .setTimestamp()
      .setFooter({ text: 'Channel Deletion', iconURL: channel.guild.iconURL() });

    logChannel.send({ embeds: [deleteEmbed] }).catch(console.error);
  } catch (error) {
    console.error('An error occurred while handling channelDelete:', error);
    // Handle the error appropriately
  }
});
//User Update Event
client.on('userUpdate', async (oldUser, newUser) => {
if (oldUser.avatar !== newUser.avatar || oldUser.username !== newUser.username) {
client.guilds.cache.forEach(async guild => {
try {
const member = await guild.members.fetch(newUser.id);

const logging = await Logging.findOne({ guildId: guild.id });
if (!logging || !logging.memberLogs) return;

const logsChannel = await client.channels.fetch(logging.memberLogs);
if (!logsChannel) return;

const oldAvatarURL = oldUser.avatarURL({ dynamic: true, size: 512 });
const newAvatarURL = newUser.avatarURL({ dynamic: true, size: 512 });

const embed = new EmbedBuilder()
.setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
.setTitle('User Update')
.setColor(0x3498db)
.setThumbnail(newAvatarURL)
.setTimestamp()
.addFields(
{ name: 'User', value: `${newUser.tag} (${newUser.id})`, inline: false },
);

if (oldUser.username !== newUser.username) {
embed.addFields(
{ name: 'Old Username', value: oldUser.username, inline: true },
{ name: 'New Username', value: newUser.username, inline: true }
);
}

if (oldUser.avatar !== newUser.avatar) {
embed.setImage(oldAvatarURL)
.addFields(
{ name: 'Avatar Change', value: `The User Just Changed Avatar The Thumbnail indicates New Avatar & Body image shows old avatar`, inline: false }
);
}

logsChannel.send({ embeds: [embed] });
} catch (error) {
if (error.code !== '10007') {
console.error(`Failed to fetch member: ${error}`);
}
}
});
}
});




// Emoji Create Event
client.on('emojiCreate', async (emoji) => {
const loggingConfig = await Logging.findOne({ guildId: emoji.guild.id });
if (!loggingConfig || !loggingConfig.serverLogs) return;

const logChannel = emoji.guild.channels.cache.get(loggingConfig.serverLogs);
if (!logChannel) return;

// Create the embed for emoji creation
const createEmbed = new EmbedBuilder()
.setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
.setTitle('Emoji Created')
.setColor(0x00FF00) // Green color
.setThumbnail(emoji.url)
.addFields(
{ name: 'Emoji', value: `${emoji}`, inline: true },
{ name: 'Name', value: emoji.name, inline: true },
)
.setTimestamp()
.setFooter({ text: 'Emoji Creation', iconURL: emoji.guild.iconURL() });

logChannel.send({ embeds: [createEmbed] }).catch(console.error);
});

// Emoji Delete Event
client.on('emojiDelete', async (emoji) => {
const loggingConfig = await Logging.findOne({ guildId: emoji.guild.id });
if (!loggingConfig || !loggingConfig.serverLogs) return;

const logChannel = emoji.guild.channels.cache.get(loggingConfig.serverLogs);
if (!logChannel) return;

// Create the embed for emoji deletion
const deleteEmbed = new EmbedBuilder()
.setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
.setTitle('Emoji Deleted')
.setColor(0xFF0000) // Red color
.setThumbnail(emoji.url)
.addFields(
{ name: 'Name', value: emoji.name, inline: true },
)
.setTimestamp()
.setFooter({ text: 'Emoji Deletion', iconURL: emoji.guild.iconURL() });

logChannel.send({ embeds: [deleteEmbed] }).catch(console.error);
});

// Emoji Update Event
client.on('emojiUpdate', async (oldEmoji, newEmoji) => {
if (oldEmoji.name === newEmoji.name) return; // Ignore updates that are not name changes

const loggingConfig = await Logging.findOne({ guildId: newEmoji.guild.id });
if (!loggingConfig || !loggingConfig.serverLogs) return;

const logChannel = newEmoji.guild.channels.cache.get(loggingConfig.serverLogs);
if (!logChannel) return;

// Create the embed for emoji name change 
const updateEmbed = new EmbedBuilder()
.setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
.setTitle('Emoji Name Changed')
.setColor(0xFFA500) // Orange color
.setThumbnail(newEmoji.url)
.addFields(
{ name: 'Old Name', value: oldEmoji.name, inline: true },
{ name: 'New Name', value: newEmoji.name, inline: true },
)
.setTimestamp()
.setFooter({ text: 'Emoji Name Change', iconURL: oldEmoji.guild.iconURL() });

logChannel.send({ embeds: [updateEmbed] }).catch(console.error);
}); 

//Leave Log
client.on('guildMemberRemove', async (member) => {
const loggingConfig = await Logging.findOne({ guildId: member.guild.id });
if (!loggingConfig || !loggingConfig.joinLeaveLogs) return;

const logChannel = member.guild.channels.cache.get(loggingConfig.joinLeaveLogs);
if (!logChannel) return;

// Calculate when the member joined by subtracting their joinedAt timestamp from the current time
const joinedAt = member.joinedAt || new Date(); // Fallback to the current date if joinedAt is not available
const timeInServerDays = Math.floor((Date.now() - joinedAt.getTime()) / (24 * 60 * 60 * 1000));

// Create the embed for guild member leave
const leaveEmbed = new EmbedBuilder()
.setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
.setTitle('Member Left')
.setColor(0xFF0000) // Red color
.setThumbnail(member.user.displayAvatarURL())
.addFields(
{ name: 'User', value: `${member.user.tag} (${member.id})`, inline: true },
{ name: 'Joined', value: `${joinedAt.toDateString()} (${timeInServerDays} day(s) in server)`, inline: true }
)
.setFooter({ text: 'User Left', iconURL: member.guild.iconURL() })
.setTimestamp();

// Send the embed to the log channel
logChannel.send({ embeds: [leaveEmbed] }).catch(console.error);
}); 


//Join Log
client.on('guildMemberAdd', async (member) => {
  const loggingConfig = await Logging.findOne({ guildId: member.guild.id });
  if (!loggingConfig || !loggingConfig.joinLeaveLogs) return;

  const logChannel = member.guild.channels.cache.get(loggingConfig.joinLeaveLogs);
  if (!logChannel) return;

  // Check account age
  const accountAge = Date.now() - member.user.createdAt.getTime();
  const accountAgeDays = Math.floor(accountAge / (24 * 60 * 60 * 1000)); // Convert to days
  const isNewAccount = accountAgeDays < 14;

  // Create the embed for guild member join
  const joinEmbed = new EmbedBuilder()
   .setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
    .setTitle('Member Joined')
    .setColor(0x00FF00) // Green color
    .setThumbnail(member.user.displayAvatarURL())
    .addFields(
      { name: 'User', value: `${member.user.tag} (${member.id})`, inline: true },
      { name: 'Account Age', value: `${accountAgeDays} day(s) old`, inline: true }
    )
    .setFooter({ text: 'User Joined', iconURL: member.guild.iconURL() })
    .setTimestamp();

  // Include a warning for new accounts
  if (isNewAccount) {
    joinEmbed.addFields({ name: '⚠️ New Account Detected', value: 'Take care of server safety measures.', inline: false });
  }

  // Send the embed to the log channel
  logChannel.send({ embeds: [joinEmbed] }).catch(console.error);
});
// VC Log
client.on('voiceStateUpdate', async (oldState, newState) => {
    // Check if someone joins a VC
    if (!oldState.channelId && newState.channelId) {
        sendVcLogEmbed(newState.member, newState.channel, 'joined');
    }
    // Check if someone leaves a VC
    else if (oldState.channelId && !newState.channelId) {
        sendVcLogEmbed(oldState.member, oldState.channel, 'left');
    }
    // Check if someone was moved to a different VC
    else if (oldState.channelId && newState.channelId && oldState.channelId !== newState.channelId) {
        sendVcLogEmbed(newState.member, newState.channel, 'moved', oldState.channel);
    }
});

async function sendVcLogEmbed(member, channel, action, oldChannel = null) {
    const loggingConfig = await Logging.findOne({ guildId: member.guild.id });
    if (!loggingConfig || !loggingConfig.vcLogs) return;

    const logChannel = member.guild.channels.cache.get(loggingConfig.vcLogs);
    if (!logChannel) return;

    // Set the title and color based on the action
    let title = '';
    let color = 0x000000;
    switch (action) {
        case 'joined':
            title = 'Voice Channel Join';
            color = 0x00FF00;
            break;
        case 'left':
            title = 'Voice Channel Leave';
            color = 0xFF0000;
            break;
        case 'moved':
            title = 'Voice Channel Move';
            color = 0x0000FF;
            break;
    }

    // Create the embed, add fields based on the action
    const embed = new EmbedBuilder()
    .setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
        .setTitle(title)
        .setColor(color)
        .addFields(
            { name: 'User', value: `${member.user.tag} (${member.id})`, inline: true },
            { name: 'Channel', value: action === 'moved' ? oldChannel.name + ' ➔ ' + channel.name : channel.name, inline: true }
        )
        .setTimestamp()
        .setFooter({ text: `User ${action} VC`, iconURL: member.user.displayAvatarURL() });

    // Send the embed to the log channel 
    logChannel.send({ embeds: [embed] }).catch(console.error);
} 

//BulkDelete Log
client.on('messageDeleteBulk', async (messages) => {
  console.log("Bulk Message Deleted");
  if (!messages.first().guild) return; // Skip if it's not a guild

  const loggingConfig = await Logging.findOne({ guildId: messages.first().guild.id });
  if (!loggingConfig || !loggingConfig.messageLogs) return;

  const logChannel = messages.first().guild.channels.cache.get(loggingConfig.messageLogs);
  if (!logChannel) return;

  // Let's map the messages to a string format
  const messageContent = messages.map(m => `${m.author.tag}: ${m.attachments.size > 0 ? m.attachments.map(a => a.url).join('') : ''} ${m.content}\n`).join('');

  const chunkedMessages = splitMessage(messageContent, {
    maxLength: 2000, // Discord message character limit, just to be safe
    char: '',
    prepend: '',
    append: ''
  });

  chunkedMessages.forEach((chunk, index) => {
    const embed = new EmbedBuilder()
    .setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
      .setTitle(`Bulk Message Delete (${index + 1}/${chunkedMessages.length})`)
      .setDescription(chunk)
      .setColor(0xFFA500) // Orange color for bulk deletion
      .setTimestamp()
      .setFooter({ text: `Bulk deletion in #${messages.first().channel.name}`, iconURL: messages.first().guild.iconURL() });

    logChannel.send({ embeds: [embed] }).catch(console.error);
  });
});

//Delete Message Log
client.on('messageDelete', async (message) => {
    // Skip bot messages and DMs
    if (message.author.bot || !message.guild) return;

    if (message.partial) await message.fetch(); // Fetch the partial message if needed

    const loggingConfig = await Logging.findOne({ guildId: message.guild.id });
    if (!loggingConfig || !loggingConfig.messageLogs) return;

    const logChannel = message.guild.channels.cache.get(loggingConfig.messageLogs);
    if (!logChannel) return;

    // Create the embed
    const embed = new EmbedBuilder()
      .setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
        .setTitle('Deleted Message')
        .setDescription(`A message by **${message.author.tag}** was deleted in ${message.channel}`)
        .setColor('#FF0000') // Red color for deletion
        .setTimestamp(new Date())
        .setFooter({ text: `Author ID: ${message.author.id}`, iconURL: message.author.displayAvatarURL()});

    // If the deleted message had content, add a field for it
    if (message.content) {
    embed.addFields(
        { name: 'Content', value: message.content.substring(0, 1024) } // Truncate if necessary
    );
    }

    // If the deleted message had attachments, add a field for it
    
// If the deleted message had attachments, add a field for it
if (message.attachments.size > 0) {
  const attachmentUrls = message.attachments.map(a => a.url).join(''); // Join URLs with new lines for readability
  embed.addFields(
    { name: 'Attachments', value: attachmentUrls.substring(0, 1024) } // Truncate if necessary
  );
} 

    // Send the embed to the log channel
    logChannel.send({ embeds: [embed] }).catch(console.error);
  
}); 
//Log Commands
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isCommand() && !interaction.commandName === "log") return;

  if (interaction.commandName === 'log') {
    const subCommand = interaction.options.getSubcommand();
    const channelInput = interaction.options.getString('channel_name');
    let channel = interaction.guild.channels.cache.get(channelInput); // Try to get by ID first

    if (!channel) {
    // If no channel by ID, try to find by name (case-insensitive)
    channel = interaction.guild.channels.cache.find(c => c.name.toLowerCase() === channelInput.toLowerCase());
    //channel = interaction.guild.channels.cache.find(c => c.name === channelInput); 
    }

    if (!channel) {
    await interaction.reply(`Couldn't find a channel with the name or ID "${channelInput}" in this server. If Name is not working correctly kindly use ID..`);
    return;
     }


    switch (subCommand) {
      case 'message':
        // Setting the message logging channel
        await Logging.findOneAndUpdate(
          { guildId: interaction.guildId }, 
          { messageLogs: channel.id },
          { upsert: true, new: true }
        );
        await interaction.reply(`The message logging channel has been set to ${channel}`);
        break;
      
      case 'vc':
        // Setting the VC logging channel
        await Logging.findOneAndUpdate(
          { guildId: interaction.guildId }, 
          { vcLogs: channel.id },
          { upsert: true, new: true }
        );
        await interaction.reply(`The VC logging channel has been set to ${channel}`);
        break;

      case 'server':
        // Setting the server logging channel
        await Logging.findOneAndUpdate( 
{ guildId: interaction.guildId }, 
          { serverLogs: channel.id },
          { upsert: true, new: true }
        );
        await interaction.reply(`The server logging channel has been set to ${channel}`);
        break;

      case 'join-leave':
        // Setting the join-leave logging channel
        await Logging.findOneAndUpdate(
          { guildId: interaction.guildId }, 
          { joinLeaveLogs: channel.id },
          { upsert: true, new: true }
        );
        await interaction.reply(`The join-leave logging channel has been set to ${channel}`);
        break;

	case 'member':
        // Setting the join-leave logging channel
        await Logging.findOneAndUpdate(
          { guildId: interaction.guildId },
          { memberLogs: channel.id },
          { upsert: true, new: true }
        );
        await interaction.reply(`The Member Log Channel.is set`);
        break;

      case 'remove':
        // Remove all logging data for the guild
        await Logging.deleteOne({ guildId: interaction.guildId });
        await interaction.reply('All logging data for this server has been removed.');
        break;
      
      default:
        await interaction.reply("Hmm, I don't recognize that logging command.");
        break;
    }
  }
});


// Fun Commands
client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand() || interaction.commandName !== 'fun') return;

  const command = interaction.options.getSubcommand();

  switch (command) {
    case 'waifu': {
      // Your 'waifu' subcommand logic here
      const apiUrl = 'https://api.waifu.pics/sfw/waifu';
      try {
        const response = await axios.get(apiUrl);
        const imageUrl = response.data.url;
        
        const embed = new EmbedBuilder()
          .setTitle('Cutie')
          .setImage(imageUrl)
          .setColor(0xFFFFFF);

        const buttons = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('smash')
              .setLabel('Smash')
              .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
              .setCustomId('pass')
              .setLabel('Pass')
              .setStyle(ButtonStyle.Danger)
          );

        await interaction.reply({ embeds: [embed], components: [buttons] });
      } catch (error) {
        console.error('Error fetching waifu:', error);
        await interaction.reply({ content: 'There was an error getting a waifu. Try again later.', ephemeral: true });
      }
      break;
    }
 case 'mywaifu':
        // Fetch the waifu data from the database
        const userWaifus = await Waifu.findOne({ userId: interaction.user.id });
        if (!userWaifus || userWaifus.smashedWaifus.length === 0) {
          await interaction.reply({ content: "You haven't smashed any cuties yet! Go find some cuties! 😊", ephemeral: true });
          break;
        }

        // Let the user know their waifus are being loaded
        await interaction.reply({ content: "Your cuties are getting ready...", ephemeral: true });

        // Send each waifu image in a separate embed to the channel
        for (let imageUrl of userWaifus.smashedWaifus) {
          const embed = new EmbedBuilder()
            .setTitle(`Your Cuties`)
            .setImage(imageUrl)
            .setColor(0xFFFFFF);
          await interaction.channel.send({ embeds: [embed] });
        }

        break;
      
    case 'meme':
      await interaction.deferReply(); // Deferring the reply because fetching the meme may take some time
      
      try {
        const response = await axios.get('https://meme-api.com/gimme');
        const meme = response.data;
        
        // We ensure that the meme is neither NSFW nor a spoiler for the safety and comfort of all users
        if (meme.nsfw || meme.spoiler) {
          await interaction.editReply('Oops! The meme fetched was not suitable for this channel. Try again!');
          return;
        }
        
        const memeEmbed = new EmbedBuilder()
         .setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
          .setTitle(meme.title)
          .setURL(meme.postLink)
          .setImage(meme.url)
          .setFooter({ text: `👍 ${meme.ups} | Author: ${meme.author} | Subreddit: ${meme.subreddit}` })
          .setColor(0x1A1A1A);
        
        await interaction.editReply({ embeds: [memeEmbed] });
      } catch (error) {
        console.error('Error fetching a meme:', error);
        await interaction.editReply('There was an error trying to fetch a meme. Please try again later.');
      }
      break;
     case 'tord':
        // Randomly choose to start with Truth or Dare
        const choices = ['Truth', 'Dare'];
        const chosen = choices[Math.floor(Math.random() * choices.length)];
        await interaction.reply(createTordEmbed(
          `Let's play Truth or Dare!`,
          `Click a button below to get your ${chosen.toLowerCase()}!`
        ));
        break;
        case 'nhie':
// Fetch the NHIE prompt from the API
try {
const response = await axios.get('https://api.truthordarebot.xyz/api/nhie');
const { question } = response.data;

const nhieEmbed = new EmbedBuilder()
.setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
.setTitle('Never Have I Ever...')
.setDescription(question)
.setColor(0x5865F2);

const nhieRow = new ActionRowBuilder()
.addComponents(
new ButtonBuilder()
.setCustomId('next_nhie')
.setLabel('Next NHIE')
.setStyle(ButtonStyle.Primary)
);

await interaction.reply({ embeds: [nhieEmbed], components: [nhieRow] });
} catch (error) {
console.error('Error fetching NHIE question:', error);
await interaction.reply({ content: 'There was an error trying to fetch a NHIE question. Please try again later.', ephemeral: true });
}
break;
 case 'wyr':
// Fetch the WYR prompt from the API
try {
const response = await axios.get('https://api.truthordarebot.xyz/api/wyr');
const { question } = response.data;

const wyrEmbed = new EmbedBuilder()
.setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
.setTitle('Would You Rather...')
.setDescription(question)
.setColor(0x5865F2);

const wyrRow = new ActionRowBuilder()
.addComponents(
new ButtonBuilder()
.setCustomId('next_wyr')
.setLabel('Next WYR')
.setStyle(ButtonStyle.Primary)
);

await interaction.reply({ embeds: [wyrEmbed], components: [wyrRow] });
} catch (error) {
console.error('Error fetching WYR question:', error);
await interaction.reply({ content: 'There was an error trying to fetch a WYR question. Please try again later.', ephemeral: true });
}
break;

case 'paranoia':
// Fetch the Paranoia question from the API
try {
const response = await axios.get('https://api.truthordarebot.xyz/api/paranoia');
const { question } = response.data;

const paranoiaEmbed = new EmbedBuilder()
.setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
.setTitle('Paranoia')
.setDescription(question)
.setColor(0x5865F2);

const paranoiaRow = new ActionRowBuilder()
.addComponents(
new ButtonBuilder()
.setCustomId('next_paranoia')
.setLabel('Next Paranoia')
.setStyle(ButtonStyle.Primary)
);

await interaction.reply({ embeds: [paranoiaEmbed], components: [paranoiaRow] });
} catch (error) {
console.error('Error fetching Paranoia question:', error);
await interaction.reply({ content: 'There was an error trying to fetch a Paranoia question. Please try again later.', ephemeral: true });
}
break;

     case 'rps':
                const userChoice = interaction.options.getString('choice').toLowerCase();
                const rpsChoices = ['rock', 'paper', 'scissors'];
                const botChoice = rpsChoices[Math.floor(Math.random() * rpsChoices.length)];
                let result;

                switch (userChoice) {
                    case 'rock':
                        result = botChoice === 'scissors' ? 'You win!' : botChoice === 'paper' ? 'You lose!' : "It's a tie!";
                        break;
                    case 'paper':
                        result = botChoice === 'rock' ? 'You win!' : botChoice === 'scissors' ? 'You lose!' : "It's a tie!";
                        break;
                    case 'scissors':
                        result = botChoice === 'paper' ? 'You win!' : botChoice === 'rock' ? 'You lose!' : "It's a tie!";
                        break;
                    default:
                        await interaction.reply('Please choose rock, paper, or scissors.');
                        return;
                }

                const resultEmbed = new EmbedBuilder()
                    .setTitle('Rock, Paper, Scissors')
                    .setDescription(`You chose **${userChoice}**. I chose **${botChoice}**.${result}`)
                    .setColor(0x5865F2);

                await interaction.reply({ embeds: [resultEmbed] });
                break;

    // other subcommands within 'fun' command can be added here
  }

});


//Stats Command
client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return; // If it's not a command, we do nothing

    if (interaction.commandName !== 'stats') return; // If it's not the 'stats' command, we stop right here
     const guild = interaction.guild;
            await guild.members.fetch();
    switch (interaction.options.getSubcommand()) {
        case 'serverinfo':
           // const guild = interaction.guild;
	 //   await guild.members.fetch();
            const owner = await guild.fetchOwner();
            const serverBanner = guild.bannerURL({ dynamic: true, size: 1024 });
            const serverIcon = guild.iconURL({ dynamic: true, size: 1024 });
            const adminRoles = guild.roles.cache.filter(role => role.permissions.has("Administrator")).map(role => role.name).join(', ');
            const roleCount = guild.roles.cache.size;
            const humanCount = guild.members.cache.filter(member => !member.user.bot).size;
            const botCount = guild.members.cache.filter(member => member.user.bot).size;
            const boostLevel = guild.premiumTier;
            const isVanity = guild.vanityURLCode != null;

            const embed = new EmbedBuilder()
            .setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
                .setTitle(`${guild.name} Server Information`)
                .setDescription(`Gettin' you the exclusive on ${guild.name}`)
                .setThumbnail(serverIcon)
                .setImage(serverBanner)
                .addFields(
                    { name: 'Owner', value: owner.user.tag },
                    { name: 'Created At', value: guild.createdAt.toDateString() },
                    { name: 'Administrator Roles', value: adminRoles.length > 0 ? adminRoles : 'None' },
                    { name: 'Total Role Count', value: roleCount.toString() },
                    { name: 'Member Count', value: humanCount.toLocaleString() },
                    { name: 'Bot Count', value: botCount.toString() }, 
                    { name: 'Boost Level', value: boostLevel.toString() },
                    { name: 'Vanity URL', value: isVanity ? 'Yes' : 'No' }
                )
                .setColor(0x00AE86)
                .setTimestamp()
                .setFooter({ text: 'Server Stats', iconURL: serverIcon });

            await interaction.reply({ embeds: [embed] });
            break;

	 case 'boost':
           // const guild = interaction.guild;
           // await guild.members.fetch(); // Fetch all members to ensure we have the latest boost data

      const boosters = guild.members.cache
        .filter(member => member.premiumSince)
        .sort((a, b) => b.premiumSinceTimestamp - a.premiumSinceTimestamp)
        .map(member => `${member.user.tag} since ${new Date(member.premiumSinceTimestamp).toDateString()}`);

      const embeds = [];
      const maxLength = 1024; // Max length for each field value
      let currentField = '';

      for (const booster of boosters) {
        if ((currentField + booster).length <= maxLength) {
          currentField += `${booster}`;
        } else {
          embeds.push(new EmbedBuilder()
             .setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
            .setTitle('Server Boosters')
            .setDescription(currentField)
            .setColor(0xF47FFF)
          );
          currentField = `${booster}`;
        }
      }

      if (currentField.length > 0) {
        embeds.push(new EmbedBuilder()
          .setTitle('Server Boosters')
          .setDescription(currentField)
          .setColor(0xF47FFF)
        );
      }

      if (embeds.length === 0) {
        embeds.push(new EmbedBuilder()
          .setTitle('Server Boosters')
          .setDescription('No boosters found.')
          .setColor(0xF47FFF)
        );
      }

      // Send the first embed immediately
      await interaction.reply({ embeds: [embeds[0]] });
      // Send remaining embeds as follow-up if they exist
      for (let i = 1; i < embeds.length; i++) { 
        await interaction.followUp({ embeds: [embeds[i]] });
      }
      break;


      case 'dump':
      // Get the role members
	const role = interaction.options.getRole('role');
      const membersWithRole = role.members;
      let memberDetails = [];

      // Iterate over the collection, and for each member, push their details into the array
      membersWithRole.forEach(member => {
        memberDetails.push({
          id: member.user.id,
          name: member.user.tag,
          discordJoinDate: member.user.createdAt,
          serverJoinDate: member.joinedAt
        });
      });

      // If the role has more than 10 members, only include the first 10 for the initial embed
      const membersToShow = memberDetails.slice(0, 10);
      const moreMembersExist = membersWithRole.size > 10;

      // Create the initial embed with up to 10 members
      const dembed = new EmbedBuilder()
        .setColor('Random')
        .setTitle(`Members with the role: ${role.name}`)
        .setDescription(membersToShow.map(member => `**ID | Name | Discord Join date | Server Join Date** \n ${member.id} | ${member.name} | ${member.discordJoinDate.toDateString()} | ${member.serverJoinDate.toDateString()}\n`).join(''))
        .setTimestamp();

      // Send the initial embed
      await interaction.reply({ embeds: [dembed] });

      if (moreMembersExist) {
        // If there are more than 10 members, send the details of the rest in a follow-up message
        const remainingMembers = memberDetails.slice(10);
        const additionalEmbeds = remainingMembers.map(member => {
          const embed = new EmbedBuilder()
            .setColor('Random')
            .setTitle(`Additional Member: ${member.name}`)
            .setDescription(`**ID | Name | Discord Join date | Server Join Date**  ${member.id} | ${member.name} | ${member.discordJoinDate.toDateString()} | ${member.serverJoinDate.toDateString()}`)
            .setTimestamp();

          return dembed;
        });

        // Send the additional embeds
        for (const additionalEmbed of additionalEmbeds) {
          await interaction.followUp({ embeds: [additionalEmbed] });
        }
      }
      break;


        // Add more subcommand cases as needed
        default:
            await interaction.reply({ content: 'Hmm, I can not pull up info for that command. 🤔 Try /stats?', ephemeral: true });
            break;
    }
});





//Remove AFK
client.on('messageCreate', async message => {
  // Ignore messages without guild or from bots
  if (!message.guild || message.author.bot) return;

  try {
    // Try to find an AFK status for the author
    const afkStatus = await AfkModel.findOne({ guildId: message.guild.id, userId: message.author.id });

    // If no AFK status, the user isn't AFK, so nothing else to do
    if (!afkStatus) return;

    // If there's a lot to say, better keep it sweet and simple
    let description = 'You had people looking for you in the digital void:\n';
    if (afkStatus.mentions && afkStatus.mentions.length > 0) {
      // Sort mentions by timestamp to show the latest first
      let sortedMentions = afkStatus.mentions.sort((a, b) => b.timestamp - a.timestamp);
      
      // Check if we need to slice the list due to Discord's limitations
      let slicedMentions = sortedMentions.slice(0, 25); // Max 25 fields allowed in an embed
      
      // Build the description
      slicedMentions.forEach((mention, index) => {
        // Let's keep each message short to fit more mentions and avoid hitting the 1024-character limit per field
        let mentionContentShort = mention.content.slice(0, 100) + (mention.content.length > 100 ? '...' : ''); // Shorten the content
        description += `${index + 1}. <@${mention.userId}>: "${mentionContentShort}" [Jump](https://discord.com/channels/${message.guild.id}/${message.channel.id}/${mention.messageId})\n`;
      });

      // If we had to slice the mentions, let the user know
      if (sortedMentions.length > 25) {
        description += `...and more. Check your mentions to catch up with everyone!`;
      }
    } else {
      description = "Seems like it was peaceful around here. No mentions while you were away.";
    }

    // Craft the embed
    const welcomeBackEmbed = new EmbedBuilder()
       .setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
      .setColor(0x00FF00) // A welcoming green
      .setTitle(`Welcome back, ${message.member.displayName}!`)
       .setTimestamp()
      .setDescription(description)
      .setFooter({ text: 'Remember to stretch, hydrate, and stay awesome!' });

    // Reply with the embed
    await message.reply({ embeds: [welcomeBackEmbed] });

    // Clear the AFK status and mentions
    await AfkModel.deleteOne({ _id: afkStatus._id });

    // Optional: Restore nickname if it was changed
if (afkStatus.nicknameChanged) {
if (message.member.manageable && message.guild.me.permissions.has(PermissionFlagsBits.ManageNicknames)) {
try {
const newNickname = message.member.displayName.replace('[AFK]', '').trim();
await message.member.setNickname(newNickname);
} catch (error) {
console.error('Error restoring nickname:', error);
}
}
}


  } catch (error) {
    console.error('An error occurred while handling a returning AFK user:', error);
    // Consider sending an error message or notification in production environments
  }
}); 


//Reply With AFK Reason
client.on('messageCreate', async message => {
  // Ignore messages from bots or without guild
  if (message.author.bot || !message.guild) return;

  // Check for mentions and exclude <@redacted> or <@redacted>
  const mentions = message.mentions.users.filter(user => !user.bot && !message.mentions.everyone);
  
  // Loop through the mentions to check AFK status
  for (const [userId, user] of mentions) {
    try {
      // Retrieve AFK status from the database
      const afkInfo = await AfkModel.findOne({ guildId: message.guildId, userId: user.id });

      // If the user is AFK, send a message
      if (afkInfo) {
        function timeSince(date) {
  const seconds = Math.floor((new Date() - date) / 1000);
  let interval = seconds / 31536000;

  if (interval > 1) {
    return Math.floor(interval) + " year(s) ago";
  }
  interval = seconds / 2592000;
  if (interval > 1) {
    return Math.floor(interval) + " month(s) ago";
  }
  interval = seconds / 86400;
  if (interval > 1) {
    return Math.floor(interval) + " day(s) ago";
  }
  interval = seconds / 3600;
  if (interval > 1) {
    return Math.floor(interval) + " hour(s) ago";
  }
  interval = seconds / 60;
  if (interval > 1) {
    return Math.floor(interval) + " minute(s) ago";
  }
  return Math.floor(seconds) + " second(s) ago";
} 
const timeAgo = timeSince(afkInfo.timestamp);
        message.channel.send(`${message.author.username}, ${user.tag} is AFK since ${timeAgo}, reason: ${afkInfo.reason}`);
       if (afkInfo) {

                   afkInfo.mentions.push({
                    userId: message.author.id,
                    timestamp: new Date(),
                    content: message.content,
                    messageId: message.id,
                      });
               await afkInfo.save();
                  }


      }
    } catch (error) {
      console.error('Error fetching AFK status:', error);
      // Handling error conditions is always a good idea
    }
  }
}); 



// AFK Interaction Create
client.on('interactionCreate', async interaction => {
if (!interaction.isChatInputCommand()) return;

// Correct the condition to match the 'afk' command correctly
if (interaction.commandName !== 'afk') return;
// Extract the reason or set a default one
const reason = interaction.options.getString('reason') || "I'm afk sis";
const afkStatus = {
guildId: interaction.guildId,
userId: interaction.user.id,
timestamp: new Date(),
reason: reason,
};

try {
  // Save the AFK status to the database
  await AfkModel.create(afkStatus); // Make sure AfkModel is imported at the top

  // Attempt to change the nickname if the bot has permission
  if (interaction.member.manageable && interaction.guild.me.permissions.has(PermissionFlagsBits.ManageNicknames)) {
    const originalNickname = interaction.member.displayName;
    const afkNickname = `[AFK] ${originalNickname}`;
    await interaction.member.setNickname(afkNickname.slice(0, 32)); // Ensure the nickname is within the 32 character limit
  }

  // Send confirmation message
  await interaction.reply({ content: `You are now AFK: ${reason}` });
} catch (error) {
  console.error('Error setting AFK status:', error);
  await interaction.reply({ content: 'Oops! Something went wrong while setting your AFK status.', ephemeral: true });
}
}); 


//Welcome Embed
client.on('guildMemberAdd', async member => {
//console.log("Someone Came");
  // Fetch welcome settings from the database
  const settings = await WelcomeMessage.findOne({ guildId: member.guild.id });
  if (!settings || !settings.channel || !settings.headerTitle || !settings.title || !settings.welcomeBody || !settings.footerText ) return; // If settings are not configured, do nothing
  if (!settings.channel || !client.channels.cache.get(settings.channel)?.permissionsFor(client.user).has(PermissionFlagsBits.SendMessages)) return;
  // Replace placeholders with dynamic values
  const headerTitle = settings.headerTitle
    .replace(/{user\.name}/g, member.user.username)
    .replace(/{user\.tag}/g, member.user.tag)
    .replace(/{server\.name}/g, member.guild.name);

  const welcomeTitle = settings.title
    .replace(/{user\.name}/g, member.user.username)
    .replace(/{user\.tag}/g, member.user.tag)
    .replace(/{server\.name}/g, member.guild.name); 

 const welcomeBody = settings.welcomeBody
    .replace(/{user\.name}/g, member.user.username)
    .replace(/{user\.tag}/g, member.user.tag)
    .replace(/{server\.name}/g, member.guild.name);

 const welcomefooter = settings.footerText
    .replace(/{user\.name}/g, member.user.username)
    .replace(/{user\.tag}/g, member.user.tag)
    .replace(/{server\.name}/g, member.guild.name);

  // Build the embed based on user-provided settings
  const welcomeEmbed = new EmbedBuilder()
    .setColor(settings.color || '#00FFFF') // Set your preferred color
    .setTimestamp()
    .setAuthor({ name: headerTitle, iconURL: member.user.displayAvatarURL() })
    .setTitle(welcomeTitle)
    .setDescription(welcomeBody)
    .setFooter({ text: welcomefooter || 'Thanks For Joining' , iconURL: member.guild.iconURL() });
  // If the user provided a thumbnail URL, add it to the embed
  if (settings.thumbnailUrl) {
    welcomeEmbed.setThumbnail(settings.thumbnailUrl);
  }
  
  // If the user provided an image URL, add it to the embed
  if (settings.bodyImageUrl) {
    welcomeEmbed.setImage(settings.bodyImageUrl);
  }

  // Send the embed to the welcome channel
  const welcomeChannel = member.guild.channels.cache.get(settings.channel);
  if (!welcomeChannel) return; // If the channel doesn't exist, do nothing

  welcomeChannel.send({ embeds: [welcomeEmbed] });
}); 





//..Welcome Setting..
client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand() || interaction.commandName !== 'welcome') return;

  const guildId = interaction.guildId;
  const settings = await WelcomeMessage.findOne({ guildId }) || new WelcomeMessage({ guildId });

  try {
    const subcommand = interaction.options.getSubcommand();

    switch (subcommand) {
      case 'channel':
        settings.channel = interaction.options.getChannel('channel').id;
        await interaction.reply(`Welcome channel set to <#${settings.channel}>.`);
        break;
      
      case 'header':
        settings.headerTitle = interaction.options.getString('header');
        await interaction.reply('Welcome message header updated.');
        break;

      case 'title':
        settings.title = interaction.options.getString('title');
        await interaction.reply('Welcome message title updated.');
        break;

      case 'body':
        settings.welcomeBody = interaction.options.getString('body');
        await interaction.reply('Welcome message body text updated.');
        break;

      case 'footer':
        settings.footerText = interaction.options.getString('footer');
        await interaction.reply('Welcome message footer updated.');
        break;

      case 'thumbnail':
        settings.thumbnailUrl = interaction.options.getString('thumbnail');
        await interaction.reply('Welcome message thumbnail updated.');
        break;

      case 'image':
        settings.bodyImageUrl = interaction.options.getString('image');
        await interaction.reply('Welcome message image updated.');
        break;

      case 'color':
        const color = interaction.options.getString('color');
        if (!/^#[0-9A-F]{6}$/i.test(color)) {
          await interaction.reply({ content: 'Please provide a valid hex color code. For example, #123ABC.', ephemeral: true });
        } else {
          settings.color = color; 
          await interaction.reply('Welcome message color updated.');
        }
        break;
     
     case 'remove':
         const guildId = interaction.guild.id;
         await WelcomeMessage.deleteOne({ guildId: guildId })
      .then(() => {
        interaction.reply('All settings for this guild have been removed from the database.');
      })
      .catch(error => {
        console.error('Error removing settings from the database:', error);
        interaction.reply('An error occurred while trying to remove the settings.');
       })
        break;

      default:
        await interaction.reply({ content: 'Not a valid subcommand.', ephemeral: true });
        break;
    }

    // Save the updated settings
    await settings.save();
  } catch (error) {
    console.error('Error while updating welcome settings:', error);
    await interaction.reply({ content: 'There was an error while updating the welcome settings.', ephemeral: true });
  }
});


//leave Embed
client.on('guildMemberRemove', async member => {
console.log("Someone Left");
  // Fetch leave settings from the database
  const settings = await LeaveMessage.findOne({ guildId: member.guild.id });
  if (!settings || !settings.channel || !settings.headerTitle || !settings.title || !settings.leaveBody || !settings.footerText ) return; // If settings are not configured, do nothing
  if (!settings.channel || !client.channels.cache.get(settings.channel)?.permissionsFor(client.user).has(PermissionFlagsBits.SendMessages)) return;
  // Replace placeholders with dynamic values
  const leaveheaderTitle = settings.headerTitle
    .replace(/{user\.name}/g, member.user.username)
    .replace(/{user\.tag}/g, member.user.tag)
    .replace(/{server\.name}/g, member.guild.name);

  const leaveTitle = settings.title
    .replace(/{user\.name}/g, member.user.username)
    .replace(/{user\.tag}/g, member.user.tag)
    .replace(/{server\.name}/g, member.guild.name); 

 const leaveBody = settings.leaveBody
    .replace(/{user\.name}/g, member.user.username)
    .replace(/{user\.tag}/g, member.user.tag)
    .replace(/{server\.name}/g, member.guild.name);

 const leavefooter = settings.footerText
    .replace(/{user\.name}/g, member.user.username)
    .replace(/{user\.tag}/g, member.user.tag)
    .replace(/{server\.name}/g, member.guild.name);

  // Build the embed based on user-provided settings
  const leaveEmbed = new EmbedBuilder()
    .setColor(settings.color || '#00FFFF') // Set your preferred color
    .setTimestamp()
    .setAuthor({ name: leaveheaderTitle, iconURL: member.user.displayAvatarURL() })
    .setTitle(leaveTitle)
    .setDescription(leaveBody)
    .setFooter({ text: leavefooter || 'Thanks For Joining' , iconURL: member.guild.iconURL() });
  // If the user provided a thumbnail URL, add it to the embed
  if (settings.thumbnailUrl) {
    leaveEmbed.setThumbnail(settings.thumbnailUrl);
  }
  
  // If the user provided an image URL, add it to the embed
  if (settings.bodyImageUrl) {
    leaveEmbed.setImage(settings.bodyImageUrl);
  }

  // Send the embed to the welcome channel
  const leaveChannel = member.guild.channels.cache.get(settings.channel);
  if (!leaveChannel) return; // If the channel doesn't exist, do nothing

  leaveChannel.send({ embeds: [leaveEmbed] });
}); 





//..Leave Setting..
client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand() || interaction.commandName !== 'leaveevent') return;

  const guildId = interaction.guildId;
  const settings = await LeaveMessage.findOne({ guildId }) || new LeaveMessage({ guildId });
  await interaction.deferReply();
  try {
    const subcommand = interaction.options.getSubcommand();

    switch (subcommand) {
      case 'channel':
        settings.channel = interaction.options.getChannel('channel').id;
        await interaction.followUp(`leave channel set to <#${settings.channel}>.`);
        break;
      
      case 'header':
        settings.headerTitle = interaction.options.getString('header');
        await interaction.followUp('leave message header updated.');
        break;

      case 'title':
        settings.title = interaction.options.getString('title');
        await interaction.followUp('leave message title updated.');
        break;

      case 'body':
        settings.leaveBody = interaction.options.getString('body');
        await interaction.followUp('leave message body text updated.');
        break;

      case 'footer':
        settings.footerText = interaction.options.getString('footer');
        await interaction.followUp('leave message footer updated.');
        break;

      case 'thumbnail':
        settings.thumbnailUrl = interaction.options.getString('thumbnail');
        await interaction.followUp('leave message thumbnail updated.');
        break;

      case 'image':
        settings.bodyImageUrl = interaction.options.getString('image');
        await interaction.followUp('leave message image updated.');
        break;

      case 'color':
        const color = interaction.options.getString('color');
        if (!/^#[0-9A-F]{6}$/i.test(color)) {
          await interaction.followUp({ content: 'Please provide a valid hex color code. For example, #123ABC.', ephemeral: true });
        } else {
          settings.color = color; 
          await interaction.followUp('leave message color updated.');
        }
        break;
     
     case 'remove':
         const guildId = interaction.guild.id;
         await LeaveMessage.deleteOne({ guildId: guildId })
      .then(() => {
        interaction.followUp('All settings for this guild have been removed from the database.');
      })
      .catch(error => {
        console.error('Error removing settings from the database:', error);
        interaction.followUp('An error occurred while trying to remove the settings.');
       })
        break;

      default:
        await interaction.followUp({ content: 'Not a valid subcommand.', ephemeral: true });
        break;
    }

    // Save the updated settings
    await settings.save();
  } catch (error) {
    console.error('Error while updating welcome settings:', error);
    await interaction.followUp({ content: 'There was an error while updating the welcome settings.', ephemeral: true });
  }
});

//boost Embed
client.on('guildMemberUpdate', async (oldMember, newMember) => {
  // Fetch boost settings from the database
//  console.log("Aage Badho");
  const startedBoosting = !oldMember.premiumSince && newMember.premiumSince;
  const stoppedBoosting = oldMember.premiumSince && !newMember.premiumSince; 
  if(startedBoosting){
  const settings = await BoostMessage.findOne({ guildId: member.guild.id });
  if (!settings || !settings.channel || !settings.headerTitle || !settings.title || !settings.boostBody || !settings.footerText ) return; // If settings are not configured, do nothing
  if (!settings.channel || !client.channels.cache.get(settings.channel)?.permissionsFor(client.user).has(PermissionFlagsBits.SendMessages)) return;
  if(settings.log) {
   if (!settings.log || !client.channels.cache.get(settings.channel)?.permissionsFor(client.user).has(PermissionFlagsBits.SendMessages)) return;
     }
   // Replace placeholders with dynamic values
  const boostheaderTitle = settings.headerTitle
    .replace(/{user\.name}/g, member.user.username)
    .replace(/{user\.tag}/g, member.user.tag)
    .replace(/{server\.name}/g, member.guild.name);

  const boostTitle = settings.title
    .replace(/{user\.name}/g, member.user.username)
    .replace(/{user\.tag}/g, member.user.tag)
    .replace(/{server\.name}/g, member.guild.name); 

 const boostBody = settings.boostBody
    .replace(/{user\.name}/g, member.user.username)
    .replace(/{user\.tag}/g, member.user.tag)
    .replace(/{server\.name}/g, member.guild.name);

 const boostfooter = settings.footerText
    .replace(/{user\.name}/g, member.user.username)
    .replace(/{user\.tag}/g, member.user.tag)
    .replace(/{server\.name}/g, member.guild.name);

  // Build the embed based on user-provided settings
  const boostEmbed = new EmbedBuilder()
    .setColor(settings.color || '#00FFFF') // Set your preferred color
    .setTimestamp()
    .setAuthor({ name: boostheaderTitle, iconURL: member.user.displayAvatarURL() })
    .setTitle(boostTitle)
    .setDescription(boostBody)
    .setFooter({ text: boostfooter || 'Thanks For Joining' , iconURL: member.guild.iconURL() });
  // If the user provided a thumbnail URL, add it to the embed
  if (settings.thumbnailUrl) {
    boostEmbed.setThumbnail(settings.thumbnailUrl);
  }
  
  // If the user provided an image URL, add it to the embed
  if (settings.bodyImageUrl) {
    boostEmbed.setImage(settings.bodyImageUrl);
  }

  // Send the embed to the welcome channel
  const boostChannel = member.guild.channels.cache.get(settings.channel);
  const boostlog = member.guild.channels.cache.get(settings.log);
  if (!boostChannel) return; // If the channel doesn't exist, do nothing
  boostChannel.send({ embeds: [boostEmbed] });
  if(!boostlog) return; 
  boostlog.send(`${member.user.name} started boosting this guild`);
  } else if(stoppedBoosting){
     const settings = await BoostMessage.findOne({ guildId: member.guild.id });
      if(settings.log) {     
      const boostlog = member.guild.channels.cache.get(setting.log);
      if(!boostlog) return;
      boostlog.send(`${member.user.name} stopped boosting this guild..`)
       }
  }
});





//..boost Setting..
client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand() || interaction.commandName !== 'boost') return;

  const guildId = interaction.guildId;
  const settings = await BoostMessage.findOne({ guildId }) || new BoostMessage({ guildId });

  try {
    const subcommand = interaction.options.getSubcommand();

    switch (subcommand) {
      case 'channel':
        settings.channel = interaction.options.getChannel('channel').id;
        await interaction.reply(`Boost channel set to <#${settings.channel}>.`);
        break;
      
      case 'header':
        settings.headerTitle = interaction.options.getString('header');
        await interaction.reply('Boost message header updated.');
        break;

      case 'title':
        settings.title = interaction.options.getString('title');
        await interaction.reply('Boost message title updated.');
        break;

      case 'body':
        settings.leaveBody = interaction.options.getString('body');
        await interaction.reply('Boost message body text updated.');
        break;

      case 'footer':
        settings.footerText = interaction.options.getString('footer');
        await interaction.reply('Boost message footer updated.');
        break;

      case 'thumbnail':
        settings.thumbnailUrl = interaction.options.getString('thumbnail');
        await interaction.reply('Boost message thumbnail updated.');
        break;

      case 'image':
        settings.bodyImageUrl = interaction.options.getString('image');
        await interaction.reply('Boost message image updated.');
        break;

      case 'color':
        const color = interaction.options.getString('color');
        if (!/^#[0-9A-F]{6}$/i.test(color)) {
          await interaction.reply({ content: 'Please provide a valid hex color code. For example, #123ABC.', ephemeral: true });
        } else {
          settings.color = color; 
          await interaction.reply('Boost message color updated.');
        }
        break;
     
     case 'remove':
         const guildId = interaction.guild.id;
         await BoostMessage.deleteOne({ guildId: guildId })
      .then(() => {
        interaction.reply('All settings for this guild have been removed from the database.');
      })
      .catch(error => {
        console.error('Error removing settings from the database:', error);
        interaction.reply('An error occurred while trying to remove the settings.');
       })
        break;
      case 'log':
           const log = interaction.options.getString('log');
            settings.log = log; 
          await interaction.reply('Boost log channel updated.');
          break;
      default:
        await interaction.reply({ content: 'Not a valid subcommand.', ephemeral: true });
        break;
    }

    // Save the updated settings
    await settings.save();
  } catch (error) {
    console.error('Error while updating welcome settings:', error);
    await interaction.reply({ content: 'There was an error while updating the welcome settings.', ephemeral: true });
  }
});



//Playlist Handlers
client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand() || interaction.commandName !== 'playlist') return;

  const subcommand = interaction.options.getSubcommand();
  if(subcommand === "view" || subcommand === "play") return;
  const name = interaction.options.getString('playlistname') || interaction.options.getString('name');
  const playlistName = interaction.options.getString('playlistname');
  const userId = interaction.user.id;
  await interaction.deferReply();
    
    
    const hasVoted = await checkVotesOnAnyList(userId);
    
    if(!hasVoted) {
        const voteEmbed = new EmbedBuilder()
.setColor(0x7289DA) // Set a color for the embed
.setTitle('This is a Vote Command!') // Set a title for the embed
.setDescription('Your support means a lot to us! Please vote is in any of the mentioned site to get access to this command >3 ')
.setThumbnail('https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048') // You can put your bot's avatar or any relevant image here
.addFields({ name: ' Top.gg Vote Link', value: '[vote here](https://top.gg/bot/1219339793633120357/vote)' })
       // Replace with your actual voting link
        .addFields({ name: ' BotList.me Vote Link', value: '[vote here](https://botlist.me/bots/1219339793633120357/vote)' })
.setTimestamp() // Optional: Adds a timestamp to the embed
.setFooter({ text: 'Thank you for your support!', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048' }); // Optional: Adds a footer

await interaction.followUp({ embeds: [voteEmbed] })
    .then(reply => {
        
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 100000);
    })
    .catch(console.error);

return;
        
        }
  try {
    if (subcommand === 'create') {
     // await interaction.deferReply();
      const newPlaylist = await Playlist.create({ userId, name, songs: [] });
      await interaction.followUp(`Playlist "${name}" created.`);
    } else if (subcommand === 'delete') {
      //await interaction.deferReply();
      await Playlist.deleteOne({ userId, name });
      await interaction.followUp(`Playlist "${name}" deleted.`);
    } else if (subcommand === 'add') {
     // await interaction.deferReply();
      // the playlist and remove the song with the matching title
  const playlist = await Playlist.findOne({ userId, name: playlistName });

  if (!playlist) {
    //await interaction.deferReply();
    await interaction.followUp(`Playlist "${playlistName}" not found.`);
    return;
  }
      const songQuery = interaction.options.getString('song');
      distube.search(songQuery).then(async results => {
        if (results.length === 0) {
          await interaction.followUp("Couldn't find the song.");
          return;
        }
      const song = results[0]; // Taking the first result
        await Playlist.findOneAndUpdate(
          { userId, name },
          { $push: { songs: { title: song.name, url: song.url, duration: song.duration } } }
        );
        await interaction.followUp(`Added "${song.name}" to "${name}".`);
      }).catch(error => {
        console.error('Error fetching song data:', error);
        interaction.followUp('Oops! Something went wrong adding the song.');
      });
    } else if (subcommand === 'remove') {
 //  await interaction.deferReply();
  // Get the playlist name and song title from the interaction
  const playlistName = interaction.options.getString('playlistname');
  //const songTitle = interaction.options.getString('song');

  // Find the playlist and remove the song with the matching title
  const playlist = await Playlist.findOne({ userId, name: playlistName });

  if (!playlist) {
    await interaction.followUp(`Playlist "${playlistName}" not found.`);
    return;
  }

  // Filter out the song to remove
 const songQuery = interaction.options.getString('song');
 const res = await distube.search(songQuery);
 const songTitle = res[0].name;
  const updatedSongs = playlist.songs.filter(song => song.title !== songTitle);
  if (playlist.songs.length === updatedSongs.length) {
    await interaction.followUp(`Song "${songTitle}" not found in "${playlistName}".`);
  } else {
    // Update the playlist in the database
    await Playlist.findOneAndUpdate({ userId, name: playlistName }, { $set: { songs: updatedSongs } });
    await interaction.followUp(`Removed "${songTitle}" from "${playlistName}".`);
  } 
} else if (subcommand === 'rename') {
  // Get the old and new playlist names from the interaction
  const oldName = interaction.options.getString('old');
  const newName = interaction.options.getString('new');

  // Find the playlist and update the name
  const playlist = await Playlist.findOne({ userId, name: oldName });

  if (!playlist) { 
await interaction.followUp(`Playlist "${oldName}" not found.`);
    return;
  }

  // Check if new name already exists
  const existingPlaylist = await Playlist.findOne({ userId, name: newName });
  
  if (existingPlaylist) {
    await interaction.followUp(`A playlist with the name "${newName}" already exists.`);
    return;
  }
await Playlist.findOneAndUpdate({ userId, name: oldName }, { $set: { name: newName } });
  await interaction.followUp(`Renamed playlist from "${oldName}" to "${newName}".`);
} else if (subcommand === 'list') {
  const itemsPerPage = 10;
  const userId = interaction.user.id; // The user's ID for filtering playlists
  let page = 0;

  // Fetch playlists from the database with pagination
  const fetchPlaylistsPage = async (page) => {
    return await Playlist.find({ userId }).skip(page * itemsPerPage).limit(itemsPerPage);
  };

  const totalPlaylists = await Playlist.countDocuments({ userId });
  const maxPage = Math.ceil(totalPlaylists / itemsPerPage) - 1;
  const playlistsPage = await fetchPlaylistsPage(page);

  // Generate message content
  const embed = new EmbedBuilder()
    .setColor(0x0099ff)
    .setTitle('Your Playlists')
    .setDescription(playlistsPage.map(p => `- ${p.name}\n`).join('') || 'No playlists found.');

  // Send the initial message with buttons
  await interaction.followUp({
    embeds: [embed],
    components: totalPlaylists > itemsPerPage ? [createButtonRow(page, maxPage)] : []
  });

  // If there's only one page, we don't need to set up a collector
  if (totalPlaylists <= itemsPerPage) return;

  // Set up a collector for button interactions
  const filter = (i) => i.user.id === userId;
  const collector = interaction.channel.createMessageComponentCollector({ filter, time: 120000 }); // Collector duration

  collector.on('collect', async (i) => { 
	if (i.customId === 'previous_btn') {
      page--;
    } else if (i.customId === 'next_btn') {
      page++;
    }

    const newPlaylistsPage = await fetchPlaylistsPage(page);
    const newEmbed = new EmbedBuilder()
      .setColor(0x0099ff)
      .setTitle('Your Playlists:')
      .setDescription(newPlaylistsPage.map(p => `- ${p.name}`).join('') || 'No playlists found.');

    await i.update({
      embeds: [newEmbed],
      components: [createButtonRow(page, maxPage)]
    });
  });

  collector.on('end', () => {
    interaction.followUp({ components: [] }); // Remove buttons after the collector ends
  });
}
  } catch (error) {
   //await interaction.deferReply();
    console.error('Error managing playlist:', error);
    await interaction.followUp('Oops! Something went wrong managing the playlist.');
  }
});


//PlayPlaylist

client.on('interactionCreate', async interaction => {
if (!interaction.isCommand() || interaction.commandName!== 'playlist') return;
if (interaction.options.getSubcommand() !== 'play') return;
await interaction.deferReply();
const userId = interaction.user.id;
    
    const hasVoted = await checkVotesOnAnyList(userId);
    
    if(!hasVoted) {
        const voteEmbed = new EmbedBuilder()
.setColor(0x7289DA) // Set a color for the embed
.setTitle('This is a Vote Command!') // Set a title for the embed
.setDescription('Your support means a lot to us! Please vote is in any of the mentioned site to get access to this command >3 ')
.setThumbnail('https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048') // You can put your bot's avatar or any relevant image here
.addFields({ name: ' Top.gg Vote Link', value: '[vote here](https://top.gg/bot/1219339793633120357/vote)' })
       // Replace with your actual voting link
        .addFields({ name: ' BotList.me Vote Link', value: '[vote here](https://botlist.me/bots/1219339793633120357/vote)' })
.setTimestamp() // Optional: Adds a timestamp to the embed
.setFooter({ text: 'Thank you for your support!', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048' }); // Optional: Adds a footer

await interaction.followUp({ embeds: [voteEmbed] })
    .then(reply => {
        
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 100000);
    })
    .catch(console.error);

return;
        
        }
const playlistName = interaction.options.getString('name');

//await interaction.deferReply();
// Fetch the playlist from MongoDB
const playlist = await Playlist.findOne({ userId, name: playlistName }).lean();

if (!playlist) {
await interaction.followUp(`Playlist "${playlistName}" not found.`);
return;
}

if (playlist.songs.length === 0) {
await interaction.followUp(`The playlist "${playlistName}" is empty.`);
return;
}

// Extract song URLs from the playlist
const songURLs = playlist.songs.map(song => song.url);

// Make sure the user is in a voice channel
const voiceChannel = interaction.member.voice.channel;
if (!voiceChannel) {
await interaction.followUp("You need to be in a voice channel to play music!");
return;
}

try {
//await interaction.deferReply();
// Create a custom playlist with DisTube
const customPlaylist = await distube.createCustomPlaylist(songURLs, {
member: interaction.member,
properties: { name: playlistName, source: "custom" },
parallel: true
});
const botQueue = distube.getQueue(interaction);
    if(!botQueue) {
// Play the playlist in the user's voice channel
await distube.play(voiceChannel, customPlaylist, { textChannel: interaction.channel });

await interaction.followUp({ content: `Now playing playlist "${playlistName}" 🎶`, ephemeral: true });
        } 
    if(botQueue) {
        const userVoiceChannelId = interaction.member.voice.channel?.id;
        const botVoiceChannelId = botQueue ? botQueue.voiceChannel.id : null;
        if (botQueue) {

    if (!userVoiceChannelId) {

        return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });

    }

    if (userVoiceChannelId !== botVoiceChannelId) {

        return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });

    }

     if (userVoiceChannelId === botVoiceChannelId) {
         await distube.play(voiceChannel, customPlaylist, { textChannel: interaction.channel });

await interaction.followUp({ content: `Now playing playlist "${playlistName}" 🎶`, ephemeral: true });
         
         }
        }}
        
} catch (error) {
console.error('Error playing the custom playlist:', error);
await interaction.followUp('Oops! Something went wrong while playing the music.');
}
}); 

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand() || interaction.commandName !== 'playlist') return;
  if (interaction.options.getSubcommand() !== 'view') return;
const userId = interaction.user.id;
  await interaction.deferReply();
    
    const hasVoted = await checkVotesOnAnyList(userId);
    
    if(!hasVoted) {
        const voteEmbed = new EmbedBuilder()
.setColor(0x7289DA) // Set a color for the embed
.setTitle('This is a Vote Command!') // Set a title for the embed
.setDescription('Your support means a lot to us! Please vote is in any of the mentioned site to get access to this command >3 ')
.setThumbnail('https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048') // You can put your bot's avatar or any relevant image here
.addFields({ name: ' Top.gg Vote Link', value: '[vote here](https://top.gg/bot/1219339793633120357/vote)' })
       // Replace with your actual voting link
        .addFields({ name: ' BotList.me Vote Link', value: '[vote here](https://botlist.me/bots/1219339793633120357/vote)' })
.setTimestamp() // Optional: Adds a timestamp to the embed
.setFooter({ text: 'Thank you for your support!', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048' }); // Optional: Adds a footer

await interaction.followUp({ embeds: [voteEmbed] })
    .then(reply => {
        
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 100000);
    })
    .catch(console.error);

return;
        
        }
//await interaction.deferReply();
  const playlistName = interaction.options.getString('name');
  
  const playlist = await Playlist.findOne({ userId, name: playlistName }).lean();

  if (!playlist) {
    await interaction.followUp(`Playlist "${playlistName}" not found.`);
    return;
  }

  const maxSongsPerPage = 10; // Adjust this number based on your preference
  let page = 0;

  const generateEmbed = (playlist, page) => {
    const startingIndex = page * maxSongsPerPage;
    const currentSongs = playlist.songs.slice(startingIndex, startingIndex + maxSongsPerPage);
    const embed = {
      title: `Playlist: ${playlistName}`,
      description: currentSongs.map((song, index) => `${startingIndex + index + 1}. ${song.title}\n`).join(''),
      footer: { text: `Page ${page + 1} of ${Math.ceil(playlist.songs.length / maxSongsPerPage)}` },
      color: 0x0099ff
    };
    return embed;
  };

  const generateButtons = (page, maxPages) => {
    return new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('previous')
        .setLabel('Previous')
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(page === 0),
      new ButtonBuilder()
        .setCustomId('next')
        .setLabel('Next')
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(page === maxPages - 1)
    );
  };

  await interaction.followUp({
    embeds: [generateEmbed(playlist, page)],
    components: [generateButtons(page, Math.ceil(playlist.songs.length / maxSongsPerPage))],
    ephemeral: true
  });

  const filter = i => ['previous', 'next'].includes(i.customId) && i.user.id === interaction.user.id;

  const collector = interaction.channel.createMessageComponentCollector({ filter, time: 120000 }); 
  collector.on('collect', async i => {
    if (i.customId === 'next') {
      page++;
    } else if (i.customId === 'previous') {
      page--;
    }

    await i.update({
      embeds: [generateEmbed(playlist, page)],
      components: [generateButtons(page, Math.ceil(playlist.songs.length / maxSongsPerPage))],
    });
  });
});


// Command handling
client.on('messageCreate', async message => {
    if (!message.guild || message.author.bot) return;
    
    // Check if the user is banned and if the message starts with the prefix

if (bannedUsers.includes(message.author.id)) {

if (message.content.startsWith('y!')) {

return message.channel.send(`<@${message.author.id}> Seems like you dont have permission to use this command please contact bot developer through moonlitcafe server`);

}

return;

}
//    if(!interaction.isCommand()) {
    if (!message.content.startsWith('a!')) return; // Prefix check

    const args = message.content.slice(2).trim().split(/ +/);
    const command = args.shift().toLowerCase();

   

    if(command === "vipplay" || command === "vp") {
        if(!message.member.voice.channel) { message.channel.send("<:vc:1230714679974957127> You need to be in a voice channel!")
                                           .then(msg => {

    setTimeout(() => {

        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message

        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message

    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)

});
                                           return;
                                           }
        // Check if the user is a VIP by comparing their ID

  if (!vipUserIds.includes(message.author.id)) {

    // Send a message if user is not a VIP

     message.channel.send("Oops! This command is a VIP exclusive. 😢 <:vc:1230714679974957127>")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
      }
	if (!args.length) {
     message.channel.send('Please provide the name of the song or the URL you want to play. <:music:1230710161056731167>')
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
        return;
  }


        distube.play(message.member.voice.channel, args.join(" "), { textChannel: message.channel, member: message.member });
        message.delete().catch(console.error);
    } else if (command === "play" || command === "p") {
    if (!message.member.voice.channel) { message.channel.send("You need to be in a voice channel!")
                                        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
                 return;                       }

    const permissions = message.member.voice.channel.permissionsFor(message.client.user);

if (!permissions.has('CONNECT')) {
     message.channel.send("I need permission to _join_ the voice channel. Please check my permissions and try again!")
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
    return;
}

if (!permissions.has('SPEAK')) {
     message.channel.send("I need permission to _speak_ in the voice channel. Can you check that for me?")
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
    return;
}

    if (!args.length) {
        return message.channel.send('<:music:1230710161056731167> Please provide the name of the song or the URL you want to play.')
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
        return;
        }

    const botQueue = distube.getQueue(message);
//    console.log("Bot queue:", botQueue);

    if (!botQueue) {
        const query = args.join(" ");
 //       console.log("Query:", query);

        if (query.includes("youtube.com/") || query.includes("youtu.be/")) {
             message.channel.send('We Dont Support Youtube Based URLs.. 😭')
            .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
            return;
        } else {
            distube.play(message.member.voice.channel, query, { textChannel: message.channel, member: message.member });
            message.delete().catch(console.error);
        }
    }

    const botVoiceChannelId = botQueue ? botQueue.voiceChannel.id : null;
 //   console.log("Bot voice channel ID:", botVoiceChannelId);

    const userVoiceChannelId = message.member.voice.channel?.id;
 //   console.log("User voice channel ID:", userVoiceChannelId);
  if (botQueue) {
    if (!userVoiceChannelId) {
         message.channel.send("You gotta join a voice channel to play this tune!")
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
        return;
    }

    if (userVoiceChannelId !== botVoiceChannelId) {
         message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
        return;
    }
     if (userVoiceChannelId === botVoiceChannelId) {
        const query = args.join(" ");
  //      console.log("Query:", query);

        if (query.includes("youtube.com/") || query.includes("youtu.be/")) {
             message.channel.send('We Dont Support Youtube Based URLs.. 😭')
            .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
            return;
        } else {
            distube.play(message.member.voice.channel, query, { textChannel: message.channel, member: message.member });
            message.delete().catch(console.error);
        }
    }   
} }
     else if(command === "pause" || command === "pa") {
        const queue = distube.getQueue(message);
  if (queue) {
    
  
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
     message.channel.send("You gotta join a voice channel to play this tune!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
  
  if (userVoiceChannelId !== botVoiceChannelId) {
     message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
}
    if (!queue) {
       message.channel.send('There is no music currently playing! <:rmv:1230713704127926344>')
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
        return;
    }

    if (queue.paused) {
       message.channel.send('The music is already paused! <:pause:1230583241300381828>')
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
        return;
    }

    queue.pause();

    const embed = new EmbedBuilder()
      .setTitle('<:pause:1230583241300381828> **Music Paused** ')
      .setDescription(`**[${queue.songs[0].name}](${queue.songs[0].url})** is now paused.`)
      .setThumbnail(queue.songs[0].thumbnail)
      .setColor(0xED4264) // A vibrant pinkish hue to grab attention
      .setFooter({ text: `Paused by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
      .setTimestamp();

    message.channel.send({ embeds: [embed] })
         .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 300000); // Change the duration to 30 seconds (30000 milliseconds)
});
         
    } else if(command === "resume" || command === "r" ) {
        	const queue = distube.getQueue(message);
  if (queue) {
  
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
     message.channel.send("You gotta join a voice channel to play this tune!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
  
  if (userVoiceChannelId !== botVoiceChannelId) {
     message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  } }
if (!queue) {
 message.channel.send('There is no music to resume, it’s quiet as a library here! <:rmv:1230713704127926344> ')
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
    return;
}

if (!queue.paused) {
 message.channel.send('The music is already playing, no need to hit resume! <:resume:1230583220873986180>')
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
    return;
}

queue.resume();

const embed = new EmbedBuilder()
.setTitle('<:resume:1230583220873986180> **Music Resumed**')
.setDescription(`**[${queue.songs[0].name}](${serverUrl})** is back on!`)
.setThumbnail(queue.songs[0].thumbnail)
.setColor(0x34eb37) // A refreshing green to symbolize 'go'
.setFooter({ text: `Resumed by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
.setTimestamp();

message.channel.send({ embeds: [embed] })
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 300000); // Change the duration to 30 seconds (30000 milliseconds)
});



    } else if(command === "stop" || command === "st" ) {
        const queue = distube.getQueue(message);
  if (queue) {
    
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
     message.channel.send("You gotta join a voice channel to play this tune!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
  
  if (userVoiceChannelId !== botVoiceChannelId) {
     message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
}
if (!queue) {
 message.channel.send('No music is playing right now to stop. <:pause:1230583241300381828>')
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
    return;
}

distube.stop(message);

const embed = new EmbedBuilder()
.setTitle('<:stop:1230584430846939198> **Music Stopped**')
.setDescription('The music has been stopped and the queue has been cleared. Hope you enjoyed the tunes!')
.setThumbnail(queue.songs[0].thumbnail)
.setColor(0xff0000) // A bold red to signify stopping
.setFooter({ text: `Stopped by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
.setTimestamp();

message.channel.send({ embeds: [embed] })
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
       
    } else if (command === "skip" || command === "s" ) {
    let queue = distube.getQueue(message);

  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
     message.channel.send("You gotta join a voice channel to play this tune!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
  
  if (userVoiceChannelId !== botVoiceChannelId) {
     message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
}
if (queue) {
  if (queue.songs.length === 1) {
    distube.stop(message);

    const embed = new EmbedBuilder()
    .setTitle('<:stop:1230584430846939198> **Stopped Playing**')
    .setDescription('It was the last song in the queue, so I’ve stopped the music. <:music:1230710161056731167>')
    .setColor(0xff0000) // Bold red to signify stop
    .setFooter({ text: `Action by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
    .setTimestamp();

    message.channel.send({ embeds: [embed] })
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 300000); // Change the duration to 30 seconds (30000 milliseconds)
});

  } else {
    const song = queue.songs[1]; // Get next song's info for the embed

    distube.skip(message);

    const embed = new EmbedBuilder()
    .setTitle('<:skip:1230583198686253140> **Song Skipped**')
    .setDescription(`Skipped to the next track! Now playing: **[${song.name}](${song.url})** <:vc:1230714679974957127>`)
    .setThumbnail(song.thumbnail)
    .setColor(0x1DB954) // Green to go forward
    .setFooter({ text: `Skipped by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
    .setTimestamp();

    message.channel.send({ embeds: [embed] })
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 300000); // Change the duration to 30 seconds (30000 milliseconds)
});
  }
} else {
  message.channel.send('There is no song in the queue to skip! <:pause:1230583241300381828>')
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
}
}
else if (command === 'flirt') {
  const target = message.mentions.users.first();
  if (!target) {
    message.reply('Please specify someone to flirt with! 😏');
    return;
  }

  axios.get('https://rizzapi.vercel.app/random')
    .then(response => {
      const data = response.data;
      if (!data.text) {
        message.reply(`Oops! I couldn't fetch a flirt line. Try again later?`);
        return;
      }

      const success = Math.random() < 0.5;
      const embed = new EmbedBuilder()
        .setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
        .setColor(success ? 0x57F287 : 0xED4245) // Green for success, red for fail
        .setTitle('💖 Flirt Time 💖')
        .setTimestamp()
        .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() });

      let replyContent = `${message.author} is flirting with ${target}!`;

      if (success) {
        embed.setDescription(data.text);
      } else {
        replyContent += ' ...but received a flying sandal for their effort!';
        embed.setDescription('Oops! Maybe better luck next time?');
      }

      message.reply({ content: replyContent, embeds: [embed] });
    })
    .catch(error => {
      console.error('Error fetching flirt line:', error);
      message.reply('Oops! Something went wrong trying to flirt.');
    });
}
else if(command === 'help') {
message.channel.send("Get all Help Documentation in: https://akari-2.gitbook.io/untitled/")
.then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
}

else if (command === 'lyrics') {
  const searchTerm = args.join(' ');
  if (!searchTerm) {
    message.reply("Please provide a search query.");
    return;
  }

  const searches = await GClient.songs.search(searchTerm);
  if (!searches || searches.length === 0) {
    message.reply("Couldn't find a song matching that description. 😢");
    return;
  }

  // Assuming the first search result is the correct song
  const firstSong = searches[0];
  const lyrics = await firstSong.lyrics();

  if (!lyrics) {
    message.reply("Couldn't find lyrics for that song. 😔");
    return;
  }

  // Discord's maximum characters per embed description is 4096
  if (lyrics.length <= 4096) {
    const lyricsEmbed = new EmbedBuilder()
      .setTitle(`Lyrics for ${firstSong.title}`)
      .setURL(firstSong.url)
      .setDescription(lyrics)
      .setColor(0x5865F2);
    message.reply({ embeds: [lyricsEmbed] });
  } else {
    // Split lyrics into chunks
    const splitLyrics = lyrics.match(/[\s\S]{1,4096}/g);
    const initialEmbed = new EmbedBuilder()
      .setTitle(`Lyrics for ${firstSong.title}`)
      .setURL(firstSong.url)
      .setDescription(splitLyrics[0])
      .setColor(0x5865F2);
    const initialReply = await message.reply({ embeds: [initialEmbed] });

    // Send remaining lyrics in follow-up embeds
    for (let i = 1; i < splitLyrics.length; i++) {
      const followUpEmbed = new EmbedBuilder()
        .setDescription(splitLyrics[i])
        .setColor(0x5865F2);
      await message.channel.send({ embeds: [followUpEmbed] });
    }
  }
}


else if (command === 'ping') {
  // HeartBeat: Bot latency
  const botLatencyStart = Date.now();

  const replyMessage = await message.channel.send({ content: 'Checking Vitals........' });
  const heartBeat = Date.now() - botLatencyStart;

  // SpO2: MongoDB latency
  const mongoLatencyStart = Date.now();

  await mongoose.connection.db.command({ ping: 1 });
  const spO2 = Date.now() - mongoLatencyStart;

  // Edit the initial reply with the latency data using the terms you provided
  await replyMessage.edit({
    content: `🏓 Pong!
 - HeartBeat: ${heartBeat}ms
 - SpO2: ${spO2}ms
 - API Latency: ${Math.round(client.ws.ping)}ms`
  });
}


   else if (command === 'eval' && message.author.id === '852908200776171520') {
// Replace 'YOUR_ADMIN_ID' with your Discord user ID
try {
const code = args.join(" "); // Joins the args array into a full string of code to evaluate
if (!code) return message.channel.send("I'm gonna need some code to work with...");

let evaled = eval(code);

if (typeof evaled !== "string")
  evaled = require("util").inspect(evaled);

message.channel.send(clean(evaled), { code:"xl" });
} catch (err) {
message.channel.send(`\`ERROR\` \`\`\`xl
${clean(err)}
\`\`\``);
}
}
    else if (command === 'clear') {

  // Get the queue for the current message's guild

  const queue = distube.getQueue(message);
  const botQueue = distube.getQueue(message);
  if (queue) { 
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
     message.channel.send("You gotta join a voice channel to play this tune!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
  
  if (userVoiceChannelId !== botVoiceChannelId) {
     message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
}
  // Check if there's a queue and if filters are applied

  if (queue && queue.filters.size) {

    try {

      queue.filters.clear();

      let embed = new EmbedBuilder()

        .setTitle('<:fc:1230712361632141433> **Filters Cleared**')

        .setDescription('All filters have been removed and the music is now playing in its original format!')

        .setColor(0xFFA07A) // A soft, coral color

        .setFooter({ text: `Filters cleared by ${message.author.tag}` })

        .setTimestamp();

      // Send the embed to the user

      message.channel.send({ embeds: [embed] })
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 300000); // Change the duration to 30 seconds (30000 milliseconds)
});

    } catch (error) {

      // Handle any errors

      console.error(error);

      message.channel.send("Oops, couldn't clear the filters, we hit a tech hiccup! 🛠️💔 <:pause:1230583241300381828>")
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});

    }

  } else {

    message.channel.send("There are no filters to be cleared! It's all natural here! 🌿<:music:1230710161056731167>")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;

  }

} 
// related song
 else if (command === 'related' || command === 'rs' || command === 'autonext' || command === 'next') {
// Get the queue for the current message's guild
  const queue = distube.getQueue(message);
  if (queue) { 
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
     message.channel.send("You gotta join a voice channel to play this tune!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
  
  if (userVoiceChannelId !== botVoiceChannelId) {
     message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
}
// Check if there's a queue and a song is playing
if (queue && queue.playing) {
try {
// Add a related song to the queue
await queue.addRelatedSong();
message.channel.send(" <:vc:1230714679974957127> A related song has been added to the queue! <:music:1230710161056731167> Let's keep the discovery going! 🔍")
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 300000); // Change the duration to 30 seconds (30000 milliseconds)
});
   
} catch (error) {
// Handle any errors
console.error(error);
message.channel.send("Oops, couldn't find a related song. Maybe this one's a rare gem! 💎<:music:1230710161056731167>");
}
} else {
message.channel.send("Hmm, nothing's playing right now. How about we start with a tune first? 🤔 <:music:1230710161056731167>")
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
}
} 
    else if (command === "jump" || command === "ju" || command === "skipto" ) {
    const queue = distube.getQueue(message);
  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
     message.channel.send("You gotta join a voice channel to play this tune!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
  
  if (userVoiceChannelId !== botVoiceChannelId) {
     message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
}
    if (!queue) {
         message.channel.send("<:vc:1230714679974957127> There's no music queue to jump through!")
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
        return;
    }

    const trackIndex = parseInt(args[0]) - 1; // Convert to a zero-based index
    if (isNaN(trackIndex) || trackIndex < 0 || trackIndex >= queue.songs.length) {
        let embed = new EmbedBuilder()
            .setTitle('**Jump Command Usage** <:vc:1230714679974957127>')
            .setDescription("To jump to a specific track in the queue, use: a!jump <track number> Example: jump 2 will skip to the second track in the queue.")
            .setColor(0xFFA500) // Orange color for an attention-grabbing message
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
            .setTimestamp();
        return message.channel.send({ embeds: [embed] })
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 300000); // Change the duration to 30 seconds (30000 milliseconds)
});
    }

try{    await queue.jump(trackIndex);
    let embed = new EmbedBuilder()
        .setTitle('<:skip:1230583198686253140> **Skipped to a New Track**')
        .setDescription(`Jumped to track number \`${trackIndex + 1}\`. Now playing: ${queue.songs[trackIndex].name}`)
        .setColor(0x32CD32) // Lime green for a successful action
        .setFooter({ text: `Jump command used by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
        .setTimestamp();
    message.channel.send({ embeds: [embed] })
    
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 300000); // Change the duration to 30 seconds (30000 milliseconds)
});
} catch (error) {
console.log(error);
}
}
else if (command === "move" || command === "m" ) {
  if (!message.member.voice.channel) {
     message.channel.send("You need to be in a voice channel to use the move command! <:vc:1230714679974957127>")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }

  const queue = distube.getQueue(message);
  if (queue) { 
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
     message.channel.send("You gotta join a voice channel to play this tune!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
  
  if (userVoiceChannelId !== botVoiceChannelId) {
     message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
} 
 if (!queue) {
     message.channel.send("There is no queue.")
     .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
     return;
  }

  // Args should have two values: the current song position and the new song position
  const currentPos = parseInt(args[0]) - 1; // User input is not zero-indexed
  const newPos = parseInt(args[1]) - 1; // User input is not zero-indexed

  if (isNaN(currentPos) || isNaN(newPos) || currentPos < 1 || newPos < 1 || currentPos >= queue.songs.length || newPos >= queue.songs.length) {
    return message.channel.send("Please provide valid song positions to move.");
  }

  // Move the song within the queue
  const [songToMove] = queue.songs.splice(currentPos, 1);
  queue.songs.splice(newPos, 0, songToMove);

  message.channel.send(`<:move:1230711012198580274> Moved **${songToMove.name}** from position ${currentPos + 1} to ${newPos + 1}.`)
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 300000); // Change the duration to 30 seconds (30000 milliseconds)
});
    
} 
else if (command === 'afk') {
  const reason = args.join(' ') || "I'm afk sis";
  const afkStatus = {
    guildId: message.guildId,
    userId: message.author.id,
    timestamp: new Date(),
    reason: reason,
  };

  try {
    // Save the AFK status to the database
    await AfkModel.create(afkStatus); // Make sure AfkModel is imported at the top

    // Attempt to change the nickname if the bot has permission and user's permissions are lower
    const member = message.guild.members.cache.get(message.author.id);
    if (member) {
      const botMember = message.guild.me;
      if (botMember && botMember.permissions.has('MANAGE_NICKNAMES')) {
        const originalNickname = member.displayName;
        const afkNickname = `[AFK] ${originalNickname}`;
        await member.setNickname(afkNickname.slice(0, 32));
      } else {
        console.log('Bot does not have permission to manage nicknames.');
      }
    }

    // Send confirmation message
    await message.reply(`I set your AFK: ${reason}`);
  } catch (error) {
    console.error('Error setting AFK status:', error);
    await message.reply('Oops! Something went wrong while setting your AFK status.');
  }
}

else if (command === "remove" || command === "rm" ) {
  if (!message.member.voice.channel) {
     message.channel.send("<:vc:1230714679974957127> You need to be in a voice channel to remove a song!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }

  const queue = distube.getQueue(message);
  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
     message.channel.send("You gotta join a voice channel to play this tune!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
  
  if (userVoiceChannelId !== botVoiceChannelId) {
     message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
}
  if (!queue) {
     message.channel.send("There is no queue. <:pause:1230583241300381828> ")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }

  // args should be the position of the song in the queue
  const songIndex = parseInt(args[0]);
  if (isNaN(songIndex) || songIndex < 1 || songIndex >= queue.songs.length) {
    return message.channel.send("Please provide a valid song number to remove. <:posi:1230705698543898635>");
  }

  // Remove the song from the queue (subtract 1 as the array is zero-indexed)
  const removedSong = queue.songs.splice(songIndex - 1, 1);
  message.channel.send(`Removed **${removedSong[0].name}** from the queue. <:rmv:1230713704127926344>`)
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 300000); // Change the duration to 30 seconds (30000 milliseconds)
});
    
} 
else if (command === "rewind") {
    const queue = distube.getQueue(message);
  if (queue) { 
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
     message.channel.send("You gotta join a voice channel to play this tune!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
  
  if (userVoiceChannelId !== botVoiceChannelId) {
     message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
} 
   if (!queue) {
         message.channel.send("There's no music currently playing.")
       .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
       return;
    }
    
    // Get the current playing time
    let currentTime = queue.currentTime;
    
    // Calculate the new time, ensuring it doesn't go below 0
    let rewindTime = Math.max(0, currentTime - 10);
    
    // Seek to the new time in the current song
    await distube.seek(message, rewindTime);
    
    message.channel.send("<:rwd:1230713724126625833> Rewinded the song by 10 seconds!")
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
    
} 

 
//repeat

else if (command === "repeat" || command === "loop" || command === "l" ) {
    const queue = distube.getQueue(message);
  if (queue) { 
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
     message.channel.send("You gotta join a voice channel to play this tune!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
  
  if (userVoiceChannelId !== botVoiceChannelId) {
     message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
}
    if (!queue) {
         message.channel.send("There is no music playing right now! <:music:1230710161056731167>")
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
        return;
    }
    
    let mode = queue.repeatMode;
    mode = (mode + 1) % 3; // This will toggle through the modes 0, 1, 2
    queue.setRepeatMode(mode);
    
    const modeMessages = ["Repeat is now turned off. <:looop:1230717577203027968>", "Repeating the current song. <:lp:1230717553660133466>", "Repeating all songs in the queue. <:looop:1230717577203027968>"];
    
    let embed = new EmbedBuilder();
    embed.setTitle('<:looop:1230717577203027968> **Repeat Mode Changed**')
        .setDescription(modeMessages[mode])
        .setColor(mode === 0 ? 0xFF0000 : mode === 1 ? 0xFFFF00 : 0x00FF00)
        .setFooter({ text: `Repeat mode changed by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
        .setTimestamp();
    
    message.channel.send({ embeds: [embed] })
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 300000); // Change the duration to 30 seconds (30000 milliseconds)
});
    
}
    else if (command === 'join' || command === 'j') {
  const voiceChannel = message.member.voice.channel;
const permissions = voiceChannel.permissionsFor(message.client.user);

if (!permissions.has('CONNECT')) {
     message.channel.send("I need permission to _join_ the voice channel. Please check my permissions and try again!")
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
    return;
}

if (!permissions.has('SPEAK')) {
     message.channel.send("I need permission to _speak_ in the voice channel. Can you check that for me?")
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
    return;
}

  if (voiceChannel) {
    try {
      // Use the .join(channel) method as provided by DisTube's documentation
      distube.voices.join(voiceChannel)
        .then(() => {
          message.channel.send(`<:vc:1230714679974957127> Successfully connected to the voice channel: ${voiceChannel.name}`)
          .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
       
        })
        .catch(err => {
          // Error handling, in case joining the channel fails
          console.error(err);
          message.channel.send("I couldn't join the voice channel due to an error.")
          .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
        });
    } catch (err) {
      // Catch any other errors and log them
      console.error(err);
      message.channel.send('Something went wrong when trying to join the voice channel. <:pause:1230583241300381828>')
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
    }
  } else {
    // If the user isn't in any voice channel
    message.channel.send('You need to be in a voice channel for me to join! <:vc:1230714679974957127>')
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
  }
}
    else if (command === "previous" || command === "prev" ) {                                                     try {                                                   // This will go to the previous song in the queue   
       const botQueue = distube.getQueue(message);
  if (botQueue) { 
  const botVoiceChannelId = botQueue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
     message.channel.send("You gotta join a voice channel to play this tune!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
  
const userId = message.author.id;
        const hasVoted = await checkVotesOnAnyList(userId);

        if (!hasVoted) {
            const voteEmbed = new EmbedBuilder()
                .setColor(0x7289DA)
                .setTitle('This is a Vote Command!')
                .setDescription('Your support means a lot to us! Please vote in any of the mentioned sites to get access to this command >3')
                .setThumbnail('https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048')
                .addFields(
                    { name: 'Top.gg Vote Link', value: '[vote here](https://top.gg/bot/1219339793633120357/vote)' },
                    { name: 'BotList.me Vote Link', value: '[vote here](https://botlist.me/bots/1219339793633120357/vote)' }
                )
                .setTimestamp()
                .setFooter({ text: 'Thank you for your support!', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048' });

            message.channel.send({ embeds: [voteEmbed] })
                .then(msg => {
                    setTimeout(() => { 
                        msg.delete().catch(e => console.error('Error deleting the bots message:', e));
                        message.delete().catch(e => console.error('Error deleting the users command message:', e));
                    }, 60000); // 60 seconds delay before deletion
                })
                .catch(console.error); 
            return;
        }

  if (userVoiceChannelId !== botVoiceChannelId) {
     message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
}  
      await distube.previous(message);

    message.channel.send("<:prev:1230711540815106089> Moved to the Previous Song!")
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
    

  } catch (error) {

    // Handle the error, such as when there's no previous track in the queue

    message.channel.send("Couldn't go to the previous track. Maybe it's the first one?")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      console.error(error);

  }                                                   } 
else if (command === 'leave') {
    const botQueue = distube.getQueue(message);
  if (botQueue) {
  
  const botVoiceChannelId = botQueue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
     message.channel.send("You gotta join a voice channel to play this tune!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
  
  if (userVoiceChannelId !== botVoiceChannelId) {
     message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
}
        distube.voices.get(message)?.leave()

        message.channel.send('<:stop:1230584430846939198> Left the voice channel! ')
.then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
    }
else if (command === "autoplay" || command === "ap") {
const queue = distube.getQueue(message);
  if (queue) { 
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
     message.channel.send("You gotta join a voice channel to play this tune!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
  
  if (userVoiceChannelId !== botVoiceChannelId) {
     message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
      return;
  }
}
if (!queue) {
 message.channel.send("There is no music playing right now! <:music:1230710161056731167>")
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
    return;
}
    
 

          const userId = message.author.id;
        const hasVoted = await checkVotesOnAnyList(userId);

        if (!hasVoted) {
            const voteEmbed = new EmbedBuilder()
                .setColor(0x7289DA)
                .setTitle('This is a Vote Command!')
                .setDescription('Your support means a lot to us! Please vote in any of the mentioned sites to get access to this command >3')
                .setThumbnail('https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048')
                .addFields(
                    { name: 'Top.gg Vote Link', value: '[vote here](https://top.gg/bot/1219339793633120357/vote)' },
                    { name: 'BotList.me Vote Link', value: '[vote here](https://botlist.me/bots/1219339793633120357/vote)' }
                )
                .setTimestamp()
                .setFooter({ text: 'Thank you for your support!', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048' });

            message.channel.send({ embeds: [voteEmbed] })
                .then(msg => {
                    setTimeout(() => { 
                        msg.delete().catch(e => console.error('Error deleting the bots message:', e));
                        message.delete().catch(e => console.error('Error deleting the users command message:', e));
                    }, 60000); // 60 seconds delay before deletion
                })
                .catch(console.error); 
            return;
        }

      
          
      

const autoplayStatus = queue.toggleAutoplay(); // Toggles and returns the new status

if(autoplayStatus) {
message.channel.send("<:autoplay:1230747793854042153> Autoplay is now enabled. Enjoy continuous music!")
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
    
} else {
message.channel.send("<:stop:1230584430846939198> Autoplay has been disabled. I'll only play what's in the queue now. ")
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
}
}
else if (command === "shuffle" || command === "sh" ) {
    const queue = distube.getQueue(message);
  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
     message.channel.send("You gotta join a voice channel to play this tune!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
  
  if (userVoiceChannelId !== botVoiceChannelId) {
     message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
}
    if (!queue) {
         message.channel.send("<:stop:1230584430846939198> There is no music playing right now!")
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
        return;
    }

    try {
        // Shuffle the queue
        queue.shuffle();
        let embed = new EmbedBuilder();
        embed.setTitle('<:shuffle:1230717309572747354> **Queue Shuffled**')
            .setDescription(`The queue has been shuffled!`)
            .setColor(0x1E90FF) // Dodger blue color for the shuffle action
            .setFooter({ text: `Shuffle requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
            .setTimestamp();

        message.channel.send({ embeds: [embed] })
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 200000); // Change the duration to 30 seconds (30000 milliseconds)
});
        
    } catch (error) {
        message.channel.send("There was an error shuffling the queue. 😢")
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
        console.error(error);
    }
}

	else if (command === "volume" || command === "v" ) {
         const botQueue = distube.getQueue(message);

if (!botQueue) {
return message.channel.send('No music is playing right now to stop.');
}
  if (botQueue) {
  const botVoiceChannelId = botQueue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
    return message.channel.send("You gotta join a voice channel to play this tune!");
  }
  
  if (userVoiceChannelId !== botVoiceChannelId) {
    return message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!");
  }
}
     const volume = parseInt(args[0]);
    if (isNaN(volume) || volume < 0 || volume > 100) {
        message.reply("Please enter a valid number between 0 and 100 for the volume.")
            .then(msg => {
                setTimeout(() => {
                    msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
                    message.delete().catch(e => console.error('Error deleting the users command message:', e)); // Deletes the user's original command message
                }, 5000);
            });
    } else {
        sessionVolume = volume;
        distube.setVolume(message, volume);
        message.reply(`Volume set to ${volume}% <:vc:1230714679974957127>`)
            .then(msg => {
                setTimeout(() => {
                    msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's confirmation message
                    message.delete().catch(e => console.error("Error deleting the user's command message:", e)); // Deletes the user's original command message
                }, 5000);
            });
    }
}


else if (command === 'seek'  || command === 'forward' ) {

  // Get the queue for the current message's guild

  const queue = distube.getQueue(message);
  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
     message.channel.send("You gotta join a voice channel to play this tune!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
  
  if (userVoiceChannelId !== botVoiceChannelId) {
     message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
}
  // Check if there's a song playing to seek to

  if (queue) {

    const currentTime = queue.currentTime; // Current time of the song in seconds

    const seekTime = currentTime + 10; // Default seek is 10 seconds ahead

    try {

      await distube.seek(message, seekTime);

      message.channel.send("Jumped ahead 10 seconds! Quick skip! <:fwd:1230713745060139119>");
message.delete().catch(console.error)
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
    } catch (error) {

      // Handle the error

      console.error(error);

      message.channel.send("Oops, couldn't skip ahead in the track. 🎼❌")
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});

    }

  } else {

    message.channel.send("Hey, there's no tune playing to scoot through!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});

  }

} 
else if (command === "filter" || command === "f" ) {
const queue = distube.getQueue(message);
  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = message.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel
  
  if (!userVoiceChannelId) {
    return message.channel.send("You gotta join a voice channel to play this tune!");
  }
  
  if (userVoiceChannelId !== botVoiceChannelId) {
     message.channel.send("Hey, we're not jamming in the same voice channel. Slide into mine!")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
      return;
  }
}
if (!queue) {
 message.channel.send("There is no music playing right now!")
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
    return;
}

const filter = args[0];

if (!filter || !filters.includes(filter)) {
 message.channel.send(`Please provide a valid filter! Available filters are: ${filters.join(', ')}`)
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
    return;
}

try {
let embed = new EmbedBuilder();

if (queue.filters.has(filter)) {
// If the filter is already applied, remove it
queue.filters.remove(filter);
embed.setTitle('<:fc:1230712361632141433> **Filter Removed**')
.setDescription(`The \`${filter}\` filter has been removed.`)
.setColor(0xFFA07A) // A soft, coral color
.setFooter({ text: `Filter removed by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
.setTimestamp();

} else {
// Apply the filter
queue.filters.add(filter);
embed.setTitle('<:fi:1230713676764418099> **Filter Applied**')
.setDescription(`The \`${filter}\` filter has been applied to the music.`)
.setColor(0x32CD32) // A fresh lime green for the added filter
.setFooter({ text: `Filter applied by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
.setTimestamp();
}

message.channel.send({ embeds: [embed] })
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 200000); // Change the duration to 30 seconds (30000 milliseconds)
});

} catch (error) {
message.channel.send("There was an error applying the filter. 😢")
    .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
console.error(error);
}
}

 else if ( command === "queue" || command === "q" ) {
	const queue = distube.getQueue(message);
	if(!queue || queue.songs.length === 0) {
		 message.channel.send('This Queue is Currently Empty. start this party by adding some with y!play command')
        .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
        return;
					}
	const queueEmbed = new EmbedBuilder()
		       .setTitle(`<:posi:1230705698543898635> **Current Queue**`)
            .setColor(0x1DB954) // A vibrant musical green
            .setThumbnail(queue.songs[0].thumbnail)
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
            .setTimestamp();
	let description = queue.songs.map((song, index) =>
    `${index + 1}. **[${song.name}](${serverUrl})** - \`${song.formattedDuration}\`
`
  ).join('');

  // Avoiding description that exceeds the 4096 character limit for Discord embed
  if (description.length > 2048) {
    description = description.slice(0, 2000) + '...';
    queueEmbed.addFields({ name: 'Note', value: 'The queue is too long to display all songs here.' });
  }
  queueEmbed.setDescription(description);

  message.channel.send({ embeds: [queueEmbed] })
     .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 300000); // Change the duration to 30 seconds (30000 milliseconds)
});

}

});


//      slash commands

client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;
    if (interaction.isAutocomplete()) {
		const command = interaction.client.commands.get(interaction.commandName);
}
	if (interaction.isCommand()) {
    const command = interaction.commandName;
    const options = interaction.options;
//    await interaction.deferReply();
  if (command === "play" || command === "p") {
    if (!interaction.member.voice.channel) return interaction.reply({ content: "You need to be in a voice channel!", ephemeral: true });
   // if (!args.length) return interaction.channel.send('<:music:1230710161056731167> Please provide the name of the song or the URL you want to play.');

    const botQueue = distube.getQueue(interaction);
//    console.log("Bot queue:", botQueue);

    if (!botQueue) {
        const query = interaction.options.getString('song');
 //       console.log("Query:", query);
         
  
        if (query.includes("youtube.com/") || query.includes("youtu.be/")) {
            return interaction.reply({ content: 'We Dont Support Youtube Based URLs.. 😭', ephemeral: true });
        } else {
            distube.play(interaction.member.voice.channel, query, { textChannel: interaction.channel, member: interaction.member });
            interaction.reply({ content: "<:music:1230710161056731167> Sucessfully Added to Queue", ephemeral: true });
        }
    }

    const botVoiceChannelId = botQueue ? botQueue.voiceChannel.id : null;
 //   console.log("Bot voice channel ID:", botVoiceChannelId);

    const userVoiceChannelId = interaction.member.voice.channel?.id;
 //   console.log("User voice channel ID:", userVoiceChannelId);
  if (botQueue) {
    if (!userVoiceChannelId) {
        return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
    }

    if (userVoiceChannelId !== botVoiceChannelId) {
        return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
    }
     if (userVoiceChannelId === botVoiceChannelId) {
        const query = interaction.options.getString('song');
  //      console.log("Query:", query);

        if (query.includes("youtube.com/") || query.includes("youtu.be/")) {
            return interaction.reply({ content: 'We Dont Support Youtube Based URLs.. 😭', ephemeral: true });
        } else {
            distube.play(interaction.member.voice.channel, query, { textChannel: interaction.channel, member: interaction.member });
             interaction.reply({ content: "<:music:1230710161056731167> Sucessfully Added to Queue", ephemeral: true });
	}
    }
} }
     else if(command === "pause" || command === "pa") {
        const queue = distube.getQueue(interaction);
  if (queue) {


  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

  if (!userVoiceChannelId) {
    return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
  }

  if (userVoiceChannelId !== botVoiceChannelId) {
    return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
  }
}
    if (!queue) {
      return interaction.reply({ content: 'There is no music currently playing! <:rmv:1230713704127926344>', ephemeral: true });
    }

    if (queue.paused) {
      return interaction.reply('The music is already paused! <:pause:1230583241300381828>')
           .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 30000);
    })
    .catch(console.error);
    }

    queue.pause();

    const embed = new EmbedBuilder()
      .setTitle('<:pause:1230583241300381828> **Music Paused** ')
      .setDescription(`**[${queue.songs[0].name}](${queue.songs[0].url})** is now paused.`)
      .setThumbnail(queue.songs[0].thumbnail)
      .setColor(0xED4264) // A vibrant pinkish hue to grab attention
      .setFooter({ text: `Paused by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
      .setTimestamp();

    interaction.reply({ embeds: [embed] })
            .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 100000);
    })
    .catch(console.error);
    } else if(command === "resume" || command === "r" ) {
                const queue = distube.getQueue(interaction);
  if (queue) {

  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

  if (!userVoiceChannelId) {
    return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
  }

  if (userVoiceChannelId !== botVoiceChannelId) {
    return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
  } }
if (!queue) {
return interaction.reply('There is no music to resume, it’s quiet as a library here! <:rmv:1230713704127926344> ')
       .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 30000);
    })
    .catch(console.error);
}

if (!queue.paused) {
return interaction.reply('The music is already playing, no need to hit resume! <:resume:1230583220873986180>')
       .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 30000);
    })
    .catch(console.error);
}

queue.resume();

const embed = new EmbedBuilder()
.setTitle('<:resume:1230583220873986180> **Music Resumed**')
.setDescription(`**[${queue.songs[0].name}](${queue.songs[0].url})** is back on!`)
.setThumbnail(queue.songs[0].thumbnail)
.setColor(0x34eb37) // A refreshing green to symbolize 'go'
.setFooter({ text: `Resumed by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
.setTimestamp();

interaction.reply({ embeds: [embed] })
           .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 30000);
    })
    .catch(console.error);



    } else if(command === "stop" || command === "st" ) {
        const queue = distube.getQueue(interaction);
  if (queue) {

  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

  if (!userVoiceChannelId) {
    return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
  }

  if (userVoiceChannelId !== botVoiceChannelId) {
    return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
  }
}
if (!queue) {
return interaction.reply({ content: 'No music is playing right now to stop. <:pause:1230583241300381828>', ephemeral: true });
}

distube.stop(interaction);

const embed = new EmbedBuilder()
.setTitle('<:stop:1230584430846939198> **Music Stopped**')
.setDescription('The music has been stopped and the queue has been cleared. Hope you enjoyed the tunes!')
.setThumbnail(queue.songs[0].thumbnail)
.setColor(0xff0000) // A bold red to signify stopping
.setFooter({ text: `Stopped by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
.setTimestamp();

interaction.reply({ embeds: [embed] })
           .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 100000);
    })
    .catch(console.error);
    } else if (command === "skip" || command === "s" ) {
    let queue = distube.getQueue(interaction);

  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

  if (!userVoiceChannelId) {
    return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
  }

  if (userVoiceChannelId !== botVoiceChannelId) {
    return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
  }
}
if (queue) {
  if (queue.songs.length === 1) {
    distube.stop(interaction);

    const embed = new EmbedBuilder()
    .setTitle('<:stop:1230584430846939198> **Stopped Playing**')
    .setDescription('It was the last song in the queue, so I’ve stopped the music. <:music:1230710161056731167>')
    .setColor(0xff0000) // Bold red to signify stop
    .setFooter({ text: `Action by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
    .setTimestamp();

    interaction.reply({ embeds: [embed] });

  } else {
    const song = queue.songs[1]; // Get next song's info for the embed

    distube.skip(interaction);

    const embed = new EmbedBuilder()
    .setTitle('<:skip:1230583198686253140> **Song Skipped**')
    .setDescription(`Skipped to the next track! Now playing: **[${song.name}](${song.url})** <:vc:1230714679974957127>`)
    .setThumbnail(song.thumbnail)
    .setColor(0x1DB954) // Green to go forward
    .setFooter({ text: `Skipped by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
    .setTimestamp();

    interaction.reply({ embeds: [embed] })
         .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 100000);
    })
    .catch(console.error);
  }
} else {
  interaction.reply({ content: 'There is no song in the queue to skip! <:pause:1230583241300381828>', ephemeral: true });
}
}
   else if (command === 'eval' && message.author.id === '852908200776171520') {
// Replace 'YOUR_ADMIN_ID' with your Discord user ID
try {
const code = args.join(" "); // Joins the args array into a full string of code to evaluate
if (!code) return interaction.channel.send("I'm gonna need some code to work with...");

let evaled = eval(code);

if (typeof evaled !== "string")
  evaled = require("util").inspect(evaled);

interaction.channel.send(clean(evaled), { code:"xl" });
} catch (err) {
interaction.channel.send(`\`ERROR\` \`\`\`xl
${clean(err)}
\`\`\``);
}
}
    else if (command === 'clear') {

  // Get the queue for the current message's guild

  const queue = distube.getQueue(interaction);
  const botQueue = distube.getQueue(interaction);
  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

  if (!userVoiceChannelId) {
    return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
  }

  if (userVoiceChannelId !== botVoiceChannelId) {
    return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
  }
}
  // Check if there's a queue and if filters are applied

  if (queue && queue.filters.size) {

    try {

      queue.filters.clear();

      let embed = new EmbedBuilder()

        .setTitle('<:fc:1230712361632141433> **Filters Cleared**')

        .setDescription('All filters have been removed and the music is now playing in its original format!')

        .setColor(0xFFA07A) // A soft, coral color

        .setFooter({ text: `Filters cleared by ${interaction.user.tag}` })

        .setTimestamp();

      // Send the embed to the user

      interaction.reply({ embeds: [embed] })
           .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 100000);
    })
    .catch(console.error);

    } catch (error) {

      // Handle any errors

      console.error(error);

      interaction.reply("Oops, couldn't clear the filters, we hit a tech hiccup! 🛠️💔 <:pause:1230583241300381828>")
           .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 100000);
    })
    .catch(console.error);

    }

  } else {

    interaction.reply("There are no filters to be cleared! It's all natural here! 🌿<:music:1230710161056731167>")
         .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 30000);
    })
    .catch(console.error);

  }

}

  else if (command=== 'lyrics') {
    const searchTerm = interaction.options.getString('query');
    await interaction.deferReply();

    const searches = await GClient.songs.search(searchTerm);
    if (!searches || searches.length === 0) {
      await interaction.editReply("Couldn't find a song matching that description. 😢");
      return;
    }

    // Assuming the first search result is the correct song
    const firstSong = searches[0];
    const lyrics = await firstSong.lyrics();

    if (!lyrics) {
      await interaction.editReply("Couldn't find lyrics for that song. 😔");
      return;
    }

    // Discord's maximum characters per embed description is 4096
    if (lyrics.length <= 4096) {
      const lyricsEmbed = new EmbedBuilder()
        .setTitle(`Lyrics for ${firstSong.title}`)
        .setURL(firstSong.url)
        .setDescription(lyrics)
        .setColor(0x5865F2);
      await interaction.editReply({ embeds: [lyricsEmbed] });
    } else {
      // Split lyrics into chunks
      const splitLyrics = lyrics.match(/[\s\S]{1,4096}/g);
      const initialEmbed = new EmbedBuilder()
        .setTitle(`Lyrics for ${firstSong.title}`)
        .setURL(firstSong.url)
        .setDescription(splitLyrics[0])
        .setColor(0x5865F2); 
      await interaction.editReply({ embeds: [initialEmbed] });

      // Send remaining lyrics in follow-up embeds
      for (let i = 1; i < splitLyrics.length; i++) {
        const followUpEmbed = new EmbedBuilder()
          .setDescription(splitLyrics[i])
          .setColor(0x5865F2);
        await interaction.followUp({ embeds: [followUpEmbed], ephemeral: false });
      }
    }
  }

  if (command === 'interact')
{

    // Retrieve options
    const queryType = interaction.options.getString('type');
    const targetUser = interaction.options.getUser('user');

    // Tenor API key and search
    const TENOR_API_KEY = 'AIzaSyAmeTElqe-g7a91joBKs3dn86-KZ4M8V3k';
    const searchString = `anime ${queryType}`;
    const tenorURL = `https://tenor.googleapis.com/v2/search?q=${encodeURIComponent(searchString)}&key=${TENOR_API_KEY}&client_key=my_test_app&limit=50`;

    try {
        // Make an API call to Tenor
        const response = await axios.get(tenorURL);
        const gifResults = response.data.results;

        // Choose a random GIF
        const randomIndex = Math.floor(Math.random() * gifResults.length);
        const gifURL = gifResults[randomIndex].media_formats.gif.url;

        // Create an embed with the GIF
        const embed = new EmbedBuilder()
            .setTitle(`@${interaction.user.tag} ${queryType}'s @${targetUser.tag}`)
            .setImage(gifURL)
            .setColor(0x00AE86) // Set a color for the embed
	    .setFooter({ text: 'Powered By Tenor', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'});
        // Send the embed to the channel 
        await interaction.reply({ embeds: [embed] });
    } catch (error) {
        console.error('Error fetching GIF from Tenor: ', error);
        // Reply with an error message
        await interaction.reply('Oops! Something went wrong while fetching your GIF.');
    }
}

else if (command === "about") {

    const owner = await client.users.fetch('852908200776171520');
  const ownero = await client.users.fetch('1061249806154088468');

    // Create a rich embed
    const aboutEmbed = new EmbedBuilder()
      .setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
      .setColor('Random') // or any color you like
      .setTitle(`${client.user.username} - About`)
      .setThumbnail(client.user.displayAvatarURL())
      .addFields(
        { name: 'Bot Owner', value: `${owner.tag}` },
        { name: 'Bot Owner', value: `${ownero.tag}` },
        { name: 'Discord.js Version', value: `v${version}`, inline: true }, // Ensure to import version from discord.js package
        // Add more fields as necessary
      )
      .setFooter({ text: 'Bot Info', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048' })
      .setTimestamp();

    // Send the embed to the channel
    await interaction.reply({ embeds: [aboutEmbed], ephemeral: true });
  }

 else if (command === "ping") {
    // HeartBeat: Bot latency
    const botLatencyStart = Date.now();
    
    await interaction.reply({ content: 'Measuring heartbeats and SpO2 levels...', ephemeral: true });
    const heartBeat = Date.now() - botLatencyStart;

    // SpO2: MongoDB latency
    const mongoLatencyStart = Date.now();
    
    await mongoose.connection.db.command({ ping: 1 });
    const spO2 = Date.now() - mongoLatencyStart;

    // Edit the initial reply with the latency data using the terms you provided
    await interaction.editReply({
      content: `🏓 Pong! - HeartBeat: ${heartBeat}ms \n - SpO2: ${spO2}ms \n - API Latency: ${Math.round(client.ws.ping)}ms`
    });
 }

  else if (command === 'help') {
    interaction.reply({ content: "Get The Help Panel and Documentation in: https://akari-2.gitbook.io/untitled/", ephemeral: true });

 }

  
 else if (command === 'flirt') {
    const target = interaction.options.getUser('target');
    if (!target) {
      return interaction.reply('Please specify someone to flirt with! 😏');
    }

    axios.get('https://rizzapi.vercel.app/random')
      .then(response => {
        const data = response.data;
        if (!data.text) {
          return interaction.reply(`Oops! I couldn't fetch a flirt line. Try again later?`);
        }

        const success = Math.random() < 0.5;
        const embed = new EmbedBuilder()
         .setAuthor({ name: 'Akari', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048'})
          .setColor(success ? 0x57F287 : 0xED4245) // Green for success, red for fail
          .setTitle('💖 Flirt Time 💖')
          .setTimestamp()
          .setFooter({ text: `Requested by ${interaction.user.tag}` });

        let replyContent = `${interaction.user} is flirting with ${target}!`;

        if (success) {
          embed.setDescription(data.text);
        } else {
          replyContent += ' ...but received a flying sandal for their effort!';
          embed.setDescription('Oops! Maybe better luck next time?');
        }

        interaction.reply({ content: replyContent, embeds: [embed] });
      })
      .catch(error => {
        console.error('Error fetching flirt line:', error);
        interaction.reply('Oops! Something went wrong trying to flirt.');
      });
  }   

else if (command=== 'whois')  {
  const member = interaction.options.getMember('user') || interaction.member;
  const user = member.user;
  const avatarUrl = user.displayAvatarURL({ dynamic: true, size: 1024 });

  // Key permissions to check
  const keyPermissions = [
    'Administrator',
    'ManageGuild',
    'BanMembers',
    'KickMembers',
    'ManageRoles',
    'ManageChannels'
  ];

  // Filter the member's permissions to only include the key permissions
  const userKeyPermissions = member.permissions.toArray()
                                                 .filter(permission => keyPermissions.includes(permission))
                                                 .map(permission => permission
                                                 .replace(/_/g, ' ')
                                                 .toLowerCase()
                                                 .replace(/(\w)/g, char => char.toUpperCase())); // Capitalize first letter

  const embed = new EmbedBuilder()
    .setColor(0x3498DB)
    .setAuthor({ name: user.tag, iconURL: avatarUrl })
    .setThumbnail(avatarUrl)
    .addFields(
      { name: 'Name', value: user.username, inline: true },
      { name: 'Discord Join Date', value: user.createdAt.toDateString(), inline: true },
      { name: 'Server Join Date', value: member.joinedAt.toDateString(), inline: true },
      { name: 'Roles', value: member.roles.cache.filter(r => r.id !== interaction.guild.roles.everyone.id).map(r => r).join(', ') || 'None' },
      { name: 'Key Permissions', value: userKeyPermissions.length ? userKeyPermissions.join(', ') : 'None' }
    )
    .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
    .setTimestamp(Date.now());

  await interaction.reply({ embeds: [embed] });
}




else if (command === 'avatar') {
    const user = interaction.options.getUser('user') || interaction.user;
    const avatarUrl = user.displayAvatarURL({ dynamic: true, size: 1024 });

    const embed = new EmbedBuilder()
      .setTitle(`${user.username}'s Avatar`)
      .setImage(avatarUrl)
      .setColor(0x1ABC9C);

    try {
      const fullUser = await interaction.client.users.fetch(user.id, { force: true });

      if (fullUser.banner) {
        const bannerUrl = fullUser.bannerURL({ size: 1024 });
        embed.addFields({ name: 'Banner', value: '[View Banner](' + bannerUrl + ')' });
      }
    } catch (error) {
      console.error('There was an error fetching the user:', error);
    }

    await interaction.reply({ embeds: [embed] });
  }



// related song
 else if (command === 'related' || command === 'rs' || command === 'autonext' || command === 'next') {
// Get the queue for the current message's guild
  const queue = distube.getQueue(interaction);
  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

  if (!userVoiceChannelId) {
    return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
  }

  if (userVoiceChannelId !== botVoiceChannelId) {
    return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
  }
}
// Check if there's a queue and a song is playing
if (queue && queue.playing) {
try {
// Add a related song to the queue
await queue.addRelatedSong();
interaction.reply(" <:vc:1230714679974957127> A related song has been added to the queue! <:music:1230710161056731167> Let's keep the discovery going! 🔍")
       .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 100000);
    })
    .catch(console.error);
} catch (error) {
// Handle any errors
console.error(error);
interaction.reply({ content: "Oops, couldn't find a related song. Maybe this one's a rare gem! 💎<:music:1230710161056731167>", ephemeral: true });
}
} else {
interaction.reply({ content: "Hmm, nothing's playing right now. How about we start with a tune first? 🤔 <:music:1230710161056731167>", ephemeral: true });
}
} 
    else if (command === "jump" || command === "ju" || command === "skipto" ) {
    const queue = distube.getQueue(interaction);
  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

  if (!userVoiceChannelId) {
    return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
  }

  if (userVoiceChannelId !== botVoiceChannelId) {
    return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
  }
}
    if (!queue) {
        return interaction.reply({ content: "<:vc:1230714679974957127> There's no music queue to jump through!", ephemeral: true });
    }

    const trackIndex = interaction.options.getInteger('song_number') - 1; // Convert to a zero-based index
    if (isNaN(trackIndex) || trackIndex < 0 || trackIndex >= queue.songs.length) {
        let embed = new EmbedBuilder()
            .setTitle('**Jump Command Usage** <:vc:1230714679974957127>')
            .setDescription("To jump to a specific track in the queue, use: a!jump <track number> Example: jump 2 will skip to the second track in the queue.")
            .setColor(0xFFA500) // Orange color for an attention-grabbing message
            .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setTimestamp();
        return interaction.reply({ embeds: [embed] })
           .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 30000);
    })
    .catch(console.error);
    }

try{    await queue.jump(trackIndex);
    let embed = new EmbedBuilder()
        .setTitle('<:skip:1230583198686253140> **Skipped to a New Track**')
        .setDescription(`Jumped to track number \`${trackIndex + 1}\`. Now playing: ${queue.songs[trackIndex].name}`)
        .setColor(0x32CD32) // Lime green for a successful action
        .setFooter({ text: `Jump command used by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
        .setTimestamp();
    interaction.reply({ embeds: [embed] })
       .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 100000);
    })
    .catch(console.error);
} catch (error) {
console.log(error);
}
}
else if (command === "move" || command === "m" ) {
  if (!interaction.member.voice.channel) {
    return interaction.reply({ content: "You need to be in a voice channel to use the move command! <:vc:1230714679974957127>", ephemeral: true });
  }

  const queue = distube.getQueue(interaction);
  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

  if (!userVoiceChannelId) {
    return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
  }

  if (userVoiceChannelId !== botVoiceChannelId) {
    return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
  }
}
 if (!queue) {
    return interaction.reply({ content: "There is no queue.", ephemeral: true });
  }

  // Args should have two values: the current song position and the new song position
  const currentPos = interaction.options.getInteger('from') - 1; // User input is not zero-indexed
  const newPos = interaction.options.getInteger('to') - 1; // User input is not zero-indexed

  if (isNaN(currentPos) || isNaN(newPos) || currentPos < 1 || newPos < 1 || currentPos >= queue.songs.length || newPos >= queue.songs.length) {
    return interaction.reply({ content: "Please provide valid song positions to move.", ephemeral: true });
  }

  // Move the song within the queue
  const [songToMove] = queue.songs.splice(currentPos, 1);
  queue.songs.splice(newPos, 0, songToMove);

  interaction.reply(`<:move:1230711012198580274> Moved **${songToMove.name}** from position ${currentPos + 1} to ${newPos + 1}.`)
       .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 100000);
    })
    .catch(console.error);
} 

else if (command === "remove" || command === "rm" ) {
  if (!interaction.member.voice.channel) {
    return interaction.reply({ content: "<:vc:1230714679974957127> You need to be in a voice channel to remove a song!", ephemeral: true });
  }

  const queue = distube.getQueue(interaction);
  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

  if (!userVoiceChannelId) {
    return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
  }

  if (userVoiceChannelId !== botVoiceChannelId) {
    return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
  }
}
  if (!queue) {
    return interaction.reply({ content: "There is no queue. <:pause:1230583241300381828> ", ephemeral: true });
  }

  // args should be the position of the song in the queue
  const songIndex = interaction.options.getInteger('song_number');
  if (isNaN(songIndex) || songIndex < 1 || songIndex >= queue.songs.length) {
    return interaction.reply({ content: "Please provide a valid song number to remove. <:posi:1230705698543898635>", ephemeral: true });
  }

  // Remove the song from the queue (subtract 1 as the array is zero-indexed)
  const removedSong = queue.songs.splice(songIndex - 1, 1);
  interaction.reply(`Removed **${removedSong[0].name}** from the queue. <:rmv:1230713704127926344>`)
       .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 30000);
    })
    .catch(console.error);
} 
else if (command === "rewind") {
    const queue = distube.getQueue(interaction);
  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

  if (!userVoiceChannelId) {
    return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
  }

  if (userVoiceChannelId !== botVoiceChannelId) {
    return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
  }
}
   if (!queue) {
        return interaction.reply({ content: "There's no music currently playing.", ephemeral: true });
    }

    // Get the current playing time
    let currentTime = queue.currentTime;

    // Calculate the new time, ensuring it doesn't go below 0
    let rewindTime = Math.max(0, currentTime - 10);

    // Seek to the new time in the current song
    await distube.seek(interaction, rewindTime);

    interaction.reply("<:rwd:1230713724126625833> Rewinded the song by 10 seconds!")
       .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 30000);
    })
    .catch(console.error);
} 

 
//repeat

else if (command === "repeat" || command === "loop" || command === "l" ) {
    const queue = distube.getQueue(interaction);
  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

  if (!userVoiceChannelId) {
    return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
  }

  if (userVoiceChannelId !== botVoiceChannelId) {
    return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
  }
}
    if (!queue) {
        return interaction.reply({ content: "There is no music playing right now! <:music:1230710161056731167>", ephemeral: true });
    }

    let mode = queue.repeatMode;
    mode = (mode + 1) % 3; // This will toggle through the modes 0, 1, 2
    queue.setRepeatMode(mode);

    const modeMessages = ["Repeat is now turned off. <:looop:1230717577203027968>", "Repeating the current song. <:lp:1230717553660133466>", "Repeating all songs in the queue. <:looop:1230717577203027968>"];

    let embed = new EmbedBuilder();
    embed.setTitle('<:looop:1230717577203027968> **Repeat Mode Changed**')
        .setDescription(modeMessages[mode])
        .setColor(mode === 0 ? 0xFF0000 : mode === 1 ? 0xFFFF00 : 0x00FF00)
        .setFooter({ text: `Repeat mode changed by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
        .setTimestamp();

    interaction.reply({ embeds: [embed] })
       .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 30000);
    })
    .catch(console.error);
}
    else if (command === 'join' || command === 'j') {
  const voiceChannel = interaction.member.voice.channel;
  if (voiceChannel) {
    try {
      // Use the .join(channel) method as provided by DisTube's documentation
      distube.voices.join(voiceChannel)
        .then(() => {
          interaction.reply(`<:vc:1230714679974957127> Successfully connected to the voice channel: ${voiceChannel.name}`)
             .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 30000);
    })
    .catch(console.error);
        })
        .catch(err => {
          // Error handling, in case joining the channel fails
          console.error(err);
          interaction.channel.send({ content: "I couldn't join the voice channel due to an error.", ephemeral: true });
        });
    } catch (err) {
      // Catch any other errors and log them
      console.error(err);
      interaction.reply({ content: 'Something went wrong when trying to join the voice channel. <:pause:1230583241300381828>', ephemeral: true });
    }
  } else {
    // If the user isn't in any voice channel
    interaction.reply({ content: 'You need to be in a voice channel for me to join! <:vc:1230714679974957127>', ephemeral: true });
  }
}
    else if (command === "previous" || command === "prev" ) {     
        
        try {                                                   // This will go to the previous song in the queue
       const botQueue = distube.getQueue(interaction);
  if (botQueue) {
  const botVoiceChannelId = botQueue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

  if (!userVoiceChannelId) {
    return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
  }

  if (userVoiceChannelId !== botVoiceChannelId) {
    return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
  }
}
const userId = interaction.user.id;
  
    
    const hasVoted = await checkVotesOnAnyList(userId);
    
    if(!hasVoted) {
        const voteEmbed = new EmbedBuilder()
.setColor(0x7289DA) // Set a color for the embed
.setTitle('This is a Vote Command!') // Set a title for the embed
.setDescription('Your support means a lot to us! Please vote is in any of the mentioned site to get access to this command >3 ')
.setThumbnail('https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048') // You can put your bot's avatar or any relevant image here
.addFields({ name: ' Top.gg Vote Link', value: '[vote here](https://top.gg/bot/1219339793633120357/vote)' })
       // Replace with your actual voting link
        .addFields({ name: ' BotList.me Vote Link', value: '[vote here](https://botlist.me/bots/1219339793633120357/vote)' })
.setTimestamp() // Optional: Adds a timestamp to the embed
.setFooter({ text: 'Thank you for your support!', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048' }); // Optional: Adds a footer

await interaction.reply({ embeds: [voteEmbed] })
    .then(reply => {
        
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 100000);
    })
    .catch(console.error);

return;
        
        }
      await distube.previous(interaction);

    interaction.reply("<:prev:1230711540815106089> Moved to the Previous Song!")
           .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 30000);
    })
    .catch(console.error);

  } catch (error) {

    // Handle the error, such as when there's no previous track in the queue

    interaction.reply({ content: "Couldn't go to the previous track. Maybe it's the first one?", ephemeral: true });                       console.error(error);

  }                                                   } 
else if (command === 'leave') {
    const botQueue = distube.getQueue(interaction);
  if (botQueue) {

  const botVoiceChannelId = botQueue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

  if (!userVoiceChannelId) {
    return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
  }

  if (userVoiceChannelId !== botVoiceChannelId) {
    return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
  }
}
        distube.voices.get(interaction)?.leave()

        interaction.reply('<:stop:1230584430846939198> Left the voice channel! ')
       .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 30000);
    })
    .catch(console.error);

    }
else if (command === "autoplay" || command === "ap") {
const queue = distube.getQueue(interaction);
  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

  if (!userVoiceChannelId) {
    return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
  }

  if (userVoiceChannelId !== botVoiceChannelId) {
    return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
  }
}
if (!queue) {
return interaction.reply({ content: "There is no music playing right now! <:music:1230710161056731167>", ephemeral: true });
}
    const userId = interaction.user.id;
 
    
    const hasVoted = await checkVotesOnAnyList(userId);
    
    if(!hasVoted) {
        const voteEmbed = new EmbedBuilder()
.setColor(0x7289DA) // Set a color for the embed
.setTitle('This is a Vote Command!') // Set a title for the embed
.setDescription('Your support means a lot to us! Please vote is in any of the mentioned site to get access to this command >3 ')
.setThumbnail('https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048') // You can put your bot's avatar or any relevant image here
.addFields({ name: ' Top.gg Vote Link', value: '[vote here](https://top.gg/bot/1219339793633120357/vote)' })
       // Replace with your actual voting link
        .addFields({ name: ' BotList.me Vote Link', value: '[vote here](https://botlist.me/bots/1219339793633120357/vote)' })
.setTimestamp() // Optional: Adds a timestamp to the embed
.setFooter({ text: 'Thank you for your support!', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048' }); // Optional: Adds a footer

await interaction.reply({ embeds: [voteEmbed] })
    .then(reply => {
        
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 100000);
    })
    .catch(console.error);

return;
        
        }

const autoplayStatus = queue.toggleAutoplay(); // Toggles and returns the new status

if(autoplayStatus) {
interaction.reply("<:autoplay:1230747793854042153> Autoplay is now enabled. Enjoy continuous music!")
       .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 30000);
    })
    .catch(console.error);
} else {
interaction.reply("<:stop:1230584430846939198> Autoplay has been disabled. I'll only play what's in the queue now. ")
       .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 30000);
    })
    .catch(console.error);
}
}
else if (command === "shuffle" || command === "sh" ) {
    const queue = distube.getQueue(interaction);
  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

  if (!userVoiceChannelId) {
    return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
  }

  if (userVoiceChannelId !== botVoiceChannelId) {
    return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
  }
}
    if (!queue) {
        return interaction.reply({ content: "<:stop:1230584430846939198> There is no music playing right now!", ephemeral: true });
    }

    try {
        // Shuffle the queue
        queue.shuffle();
        let embed = new EmbedBuilder();
        embed.setTitle('<:shuffle:1230717309572747354> **Queue Shuffled**')
            .setDescription(`The queue has been shuffled!`)
            .setColor(0x1E90FF) // Dodger blue color for the shuffle action
            .setFooter({ text: `Shuffle requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
            .setTimestamp();

        interaction.reply({ embeds: [embed] })
           .then(reply => {
        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 30000);
    })
    .catch(console.error);
    } catch (error) {
        interaction.reply({ content: "There was an error shuffling the queue. 😢", ephemeral: true });
        console.error(error);
    }
}

        else if (command === "volume" || command === "v") {
    const botQueue = distube.getQueue(interaction);

    if (!botQueue) {
        return interaction.reply({ content: 'No music is playing right now to adjust volume.', ephemeral: true });
    }

    const botVoiceChannelId = botQueue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
    const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

    if (!userVoiceChannelId) {
        return interaction.reply({ content: "You gotta join a voice channel to adjust the volume!", ephemeral: true });
    }

    if (userVoiceChannelId !== botVoiceChannelId) {
        return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
    }

    const volume = interaction.options.getInteger('volume_level');

    if (isNaN(volume) || volume < 0 || volume > 100) {
        interaction.reply("Please enter a valid number between 0 and 100 for the volume.")
            .then(reply => {
                setTimeout(() => {
                    reply.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
                    interaction.deleteReply().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
                }, 30000); // 5 minutes (300000 milliseconds)
            });
    } else {
        sessionVolume = volume;
        distube.setVolume(interaction, volume);
        interaction.reply(`Volume set to ${volume}% <:vc:1230714679974957127>`)
            .then(reply => {
                setTimeout(() => {
                    reply.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's confirmation message
                }, 300000); // 5 minutes (300000 milliseconds)
            });
    }
}



else if (command === 'seek'  || command === 'forward' ) {

  // Get the queue for the current message's guild

  const queue = distube.getQueue(interaction);
  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

  if (!userVoiceChannelId) {
    return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
  }

  if (userVoiceChannelId !== botVoiceChannelId) {
    return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
  }
}
  // Check if there's a song playing to seek to

  if (queue) {

    const currentTime = queue.currentTime; // Current time of the song in seconds

    const seekTime = currentTime + 10; // Default seek is 10 seconds ahead

    try {

      await distube.seek(interaction, seekTime);

      interaction.reply("Jumped ahead 10 seconds! Quick skip! <:fwd:1230713745060139119>")
           .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 30000);

    })

    .catch(console.error);

    } catch (error) {

      // Handle the error

      console.error(error);

      interaction.reply({ content: "Oops, couldn't skip ahead in the track. 🎼❌", ephemeral: true });

    }

  } else {

    interaction.reply({ content: "Hey, there's no tune playing to scoot through!", ephemeral: true });

  }

} 
else if (command === "filter" || command === "f" ) {
const queue = distube.getQueue(interaction);
  if (queue) {
  const botVoiceChannelId = queue.voiceChannel.id;  // DisTube's way to get the bot's voice channel ID
  const userVoiceChannelId = interaction.member.voice.channel?.id;  // Optional chaining in case the member isn't in a voice channel

  if (!userVoiceChannelId) {
    return interaction.reply({ content: "You gotta join a voice channel to play this tune!", ephemeral: true });
  }

  if (userVoiceChannelId !== botVoiceChannelId) {
    return interaction.reply({ content: "Hey, we're not jamming in the same voice channel. Slide into mine!", ephemeral: true });
  }
}
if (!queue) {
return interaction.reply({ content: "There is no music playing right now!", ephemeral: true });
}

const filter = interaction.options.getString('filter_name');

if (!filter || !filters.includes(filter)) {
return interaction.reply({ content: `Please provide a valid filter! Available filters are: ${filters.join(', ')}`, ephemeral: true });
}

try {
let embed = new EmbedBuilder();

if (queue.filters.has(filter)) {
// If the filter is already applied, remove it
queue.filters.remove(filter);
embed.setTitle('<:fc:1230712361632141433> **Filter Removed**')
.setDescription(`The \`${filter}\` filter has been removed.`)
.setColor(0xFFA07A) // A soft, coral color
.setFooter({ text: `Filter removed by ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
.setTimestamp();

} else {
// Apply the filter
queue.filters.add(filter);
embed.setTitle('<:fi:1230713676764418099> **Filter Applied**')
.setDescription(`The \`${filter}\` filter has been applied to the music.`)
.setColor(0x32CD32) // A fresh lime green for the added filter
.setFooter({ text: `Filter applied by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
.setTimestamp();
}

interaction.reply({ embeds: [embed] })
       .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 30000);

    })

    .catch(console.error);

} catch (error) {
interaction.reply({ content: "There was an error applying the filter. 😢", ephemeral: true });
console.error(error);
}
}
else if (command === 'smp') {
const userId = interaction.user.id;
    
    const hasVoted = await checkVotesOnAnyList(userId);
    
    if(!hasVoted) {
        const voteEmbed = new EmbedBuilder()
.setColor(0x7289DA) // Set a color for the embed
.setTitle('This is a Vote Command!') // Set a title for the embed
.setDescription('Your support means a lot to us! Please vote akari in any of the mentioned site to get access to this command >3. After voting Akari re-run this command and it will do rest job.')
.setThumbnail('https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048') // You can put your bot's avatar or any relevant image here
.addFields({ name: ' Top.gg Vote Link', value: '[vote here](https://top.gg/bot/1219339793633120357/vote)' })
       // Replace with your actual voting link
        .addFields({ name: ' BotList.me Vote Link', value: '[vote here](https://botlist.me/bots/1219339793633120357/vote)' })
.setTimestamp() // Optional: Adds a timestamp to the embed
.setFooter({ text: 'Thank you for your support!', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048' }); // Optional: Adds a footer

await interaction.reply({ embeds: [voteEmbed] })
    .then(reply => {
        
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 100000);
    })
    .catch(console.error);

return;
        
        }
await interaction.deferReply();
if (!isAuthorized(interaction)) {
    await interaction.editReply({ content: 'Sorry, you need Administrator or Manage Guild permissions to use this command.', ephemeral: true });
    return;
}

const { guild } = interaction;
const guildId = guild.id;
const existingSetting = await MusicSetting.findOne({ guildId: guildId });
  if (existingSetting && existingSetting.channelId) {
    const existingChannel = interaction.guild.channels.cache.get(existingSetting.channelId);
    if (existingChannel) {
      // The channel already exists, so send a message or handle it how you see best
      return interaction.editReply('The music channel already exists!');
    }
  }

try {
    // Create the text channel
    const newChannel = await guild.channels.create({
        name: 'Akari Music',
        type: ChannelType.GuildText
    });

    // Send initial embeds for Queue and Now Playing
    const queueEmbed = new EmbedBuilder()
        .setColor(0x0099ff)
        .setTitle('Queue')
        .setDescription('Hurray! Channel Setup Completed No Music Played in this guild by akari till now.. Will be Updated');

    const nowPlayingEmbed = new EmbedBuilder()
        .setColor(0x0099ff)
        .setTitle('Now Playing')
        .setDescription('Channel Setup Completed. No Music Played till now once it played the embed will be Updated >3 ');

    const queueMessage = await newChannel.send({ embeds: [queueEmbed] });
    const nowPlayingMessage = await newChannel.send({ embeds: [nowPlayingEmbed] });

    // Save to MusicSetting in MongoDB
    const musicSetting = await MusicSetting.findOneAndUpdate(
        { guildId: guildId },
        {
            channelId: newChannel.id,
            queueMessageId: queueMessage.id,
            nowPlayingMessageId: nowPlayingMessage.id
        },
        { upsert: true, new: true, setDefaultsOnInsert: true }
    );


    await interaction.editReply({ content: `Music Player channel created: ${newChannel.name}`, ephemeral: true });

} catch (error) {
    console.error('Error during the setup process:', error);
    await interaction.editReply({ content: 'An error occurred while setting up the music player.', ephemeral: true });
} 
}

// RMP command

else if (command === 'rmp') {
const userId = interaction.user.id;
  
    
    const hasVoted = await checkVotesOnAnyList(userId);
    
    if(!hasVoted) {
        const voteEmbed = new EmbedBuilder()
.setColor(0x7289DA) // Set a color for the embed
.setTitle('This is a Vote Command!') // Set a title for the embed
.setDescription('Your support means a lot to us! Please vote is in any of the mentioned site to get access to this command >3 ')
.setThumbnail('https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048') // You can put your bot's avatar or any relevant image here
.addFields({ name: ' Top.gg Vote Link', value: '[vote here](https://top.gg/bot/1219339793633120357/vote)' })
       // Replace with your actual voting link
        .addFields({ name: ' BotList.me Vote Link', value: '[vote here](https://botlist.me/bots/1219339793633120357/vote)' })
.setTimestamp() // Optional: Adds a timestamp to the embed
.setFooter({ text: 'Thank you for your support!', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048' }); // Optional: Adds a footer

await interaction.reply({ embeds: [voteEmbed] })
    .then(reply => {
        
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 100000);
    })
    .catch(console.error);

return;
        
        }
await interaction.deferReply();
if (!isAuthorized(interaction)) {
await interaction.editReply({ content: 'Sorry, you need Administrator or Manage Guild permissions to use this command.', ephemeral: true });
return;
}

const guildId = interaction.guild.id;

try {
    // Find and delete the MusicSetting document for the guild
    const deletionResult = await MusicSetting.findOneAndDelete({ guildId });

    if (deletionResult) {
        await interaction.editReply({ content: 'Music Player settings removed.', ephemeral: true });
    } else {
        // If no document was found and deleted
        await interaction.editReply({ content: 'No Music Player settings found.', ephemeral: true });
    }
} catch (error) {
    console.error('Error removing Music Player settings:', error);
    await interaction.editReply({ content: 'An error occurred while removing the Music Player settings.', ephemeral: true });
} 
}

 else if ( command === "queue" || command === "q" ) {
        const queue = distube.getQueue(interaction);
        if(!queue || queue.songs.length === 0) {
                return interaction.reply('This Queue is Currently Empty. start this party by adding some with /play or a!play or just type music name if music channel is in your guild.');
                                        }
        const queueEmbed = new EmbedBuilder()
                       .setTitle(`<:posi:1230705698543898635> **Current Queue**`)
            .setColor(0x1DB954) // A vibrant musical green
            .setThumbnail(queue.songs[0].thumbnail)
            .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setTimestamp();
        let description = queue.songs.map((song, index) =>
    `${index + 1}. **[${song.name}](${serverUrl})** - \`${song.formattedDuration}\`
`
  ).join('');

  // Avoiding description that exceeds the 4096 character limit for Discord embed
  if (description.length > 2048) {
    description = description.slice(0, 2000) + '...';
    queueEmbed.addFields({ name: 'Note', value: 'The queue is too long to display all songs here.' });
  }
  queueEmbed.setDescription(description);

  interaction.reply({ embeds: [queueEmbed] })
       .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 300000);

    })

    .catch(console.error);


}
}
});

client.on('messageCreate', async (message) => {
  if (message.author.bot) return; // Skip bot messages, obviously

  // Read the server settings JSON file
  //const serverSettings = JSON.parse(fs.readFileSync(serverSettingsPath, 'utf8'));
  //const settings = serverSettings[message.guild.id];
  const settings = await MusicSetting.findOne({ guildId: message.guild.id });
  // If there's no channel set for this guild, or the message isn't in the right channel, peace out early!
  if (!settings || message.channel.id !== settings.channelId) return;

  // At this point, it's clear we're in the right place. Let the DJ spin that record!
  // Use the message content directly as input for the play command.
  if (!message.member.voice.channel) return message.channel.send("You need to be in a voice channel!");
   // if (!args.length) return interaction.channel.send('<:music:1230710161056731167> Please provide the name of the song or the URL you want to play.');

    const botQueue = distube.getQueue(message);
//    console.log("Bot queue:", botQueue);

    if (!botQueue) {
        const query = message.content;
        if (query.includes("youtube.com/") || query.includes("youtu.be/")) {
            message.channel.send("Opsie! Youtube link is not supported..")
                  .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
return;
        } else {
            distube.play(message.member.voice.channel, query, { textChannel: message.channel, member: message.member });
        }
    }

    const botVoiceChannelId = botQueue ? botQueue.voiceChannel.id : null;
 //   console.log("Bot voice channel ID:", botVoiceChannelId);

    const userVoiceChannelId = message.member.voice.channel?.id;
 //   console.log("User voice channel ID:", userVoiceChannelId);
  if (botQueue) {
    if (!userVoiceChannelId) {
         message.channel.send("Opsie You are not cinnected to voice channel")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
return;
    }

    if (userVoiceChannelId !== botVoiceChannelId) {
         message.channel.send("Opsie! We are not in same voice channel")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
return;
         
    }
     if (userVoiceChannelId === botVoiceChannelId) {
        const query = message.content;

        if (query.includes("youtube.com/") || query.includes("youtu.be/")) {
            message.channel.send("Opsie! Youtube Link is not supported")
      .then(msg => {
    setTimeout(() => {
        msg.delete().catch(e => console.error('Error deleting the message:', e)); // Deletes the bot's reply message
        message.delete().catch(e => console.error('Error deleting the user\'s command message:', e)); // Deletes the user's original command message
    }, 30000); // Change the duration to 30 seconds (30000 milliseconds)
});
return;
        } else {
            distube.play(message.member.voice.channel, query, { textChannel: message.channel, member: message.member });
        }
    }
}
  // Optional: Delete the user's message after the bot has processed it
  message.delete().catch(console.error);
});

// Button Intetaction
client.on('interactionCreate', async interaction => {
  // First, check if the interaction is a button
  if (!interaction.isButton()) return;

  const queue = distube.getQueue(interaction.guildId);
  if (!queue) {
  if(interaction.customId === 'volume_down' || interaction.customId === 'previous' || interaction.customId === 'pause_resume' || interaction.customId === 'stop' || interaction.customId === 'forward' || interaction.customId === 'rewind' || interaction.customId === 'skip' || interaction.customId === 'shuffle' || interaction.customId === 'loop' || interaction.customId === 'volume_up' || interaction.customId === 'autoplay') {
    await interaction.reply({ content: "There's no music playing right now!", ephemeral: true });
    return;
   }
  }

  const member = interaction.guild.members.cache.get(interaction.user.id);
  // Ensure the member is in the same voice channel as the bot
if (['volume_down', 'previous', 'pause_resume', 'stop', 'forward', 'rewind', 'skip', 'shuffle', 'loop', 'volume_up', 'autoplay'].includes(interaction.customId)) {
    if (!member.voice.channel || member.voice.channel !== queue.voiceChannel) {
    await interaction.reply({ content: "You need to be in the same voice channel as the bot to use these controls!", ephemeral: true });
    return;
  }
}
const displayName = interaction.member.displayName;
  // Now handle the different button presses
  switch (interaction.customId) {
    case 'volume_down':
      queue.setVolume(Math.max(queue.volume - 10, 0)); // Decrease volume by 10%
      await interaction.reply({ content: `As per ${displayName} request, Volume decreased to ${queue.volume}%`, ephemeral: false })
           .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 10000);

    })

    .catch(console.error);
      break;

    case 'previous':
      // Distube doesn't have a default method for previous song,
const userId = interaction.user.id;
  
    
    const hasVoted = await checkVotesOnAnyList(userId);
    
    if(!hasVoted) {
        const voteEmbed = new EmbedBuilder()
.setColor(0x7289DA) // Set a color for the embed
.setTitle('This is a Vote Command!') // Set a title for the embed
.setDescription('Your support means a lot to us! Please vote akari in any of the mentioned site to get access to this command >3 ')
.setThumbnail('https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048') // You can put your bot's avatar or any relevant image here
.addFields({ name: ' Top.gg Vote Link', value: '[vote here](https://top.gg/bot/1219339793633120357/vote)' })
       // Replace with your actual voting link
        .addFields({ name: ' BotList.me Vote Link', value: '[vote here](https://botlist.me/bots/1219339793633120357/vote)' })
.setTimestamp() // Optional: Adds a timestamp to the embed
.setFooter({ text: 'Thank you for your support!', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048' }); // Optional: Adds a footer

await interaction.reply({ embeds: [voteEmbed] })
    .then(reply => {
        
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 100000);
    })
    .catch(console.error);

return;
        
        }
     if (queue.previousSongs.length > 0) { distube.previous(interaction);
      await interaction.reply({ content: `As per ${displayName} request, Moved to Previous Track`, ephemeral: false })
                .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 10000);

    })

    .catch(console.error);                           
          } else {

    // Handle the error, such as when there's no previous track in the queue

    interaction.reply({ content: "Couldn't go to the previous track. Maybe it's the first one?", ephemeral: true });                       

  }      
      break;

    case 'pause_resume':
      if (queue.paused) {
        queue.resume();
        await interaction.reply({ content: `As per ${displayName} request, Resumed the music!`, ephemeral: false })
           .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 10000);

    })

    .catch(console.error);
      } else {
        queue.pause();
        await interaction.reply({ content: `As per ${displayName} request, Paused the music!`, ephemeral: false })
           .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 10000);

    })

    .catch(console.error);
      }
      break;

    case 'stop':
      queue.stop();
      await interaction.reply({ content: `As per ${displayName} request, Stopped the music!`, ephemeral: false })
           .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 10000);

    })

    .catch(console.error);
      break;

    case 'forward':
      // Similar to previous, you would need a custom implementation for jumping forward in the queue
     // Get the current playing time
    let currentTime = queue.currentTime;

    // Calculate the new time
    let rewindTime = Math.max(0, currentTime + 30);

    // Seek to the new time in the current song
      await distube.seek(interaction, rewindTime);
      await interaction.reply({ content: `As per ${displayName} request, Forwarded 30 Sec! Quick Skip!!`, ephemeral: false })
           .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 10000);

    })

    .catch(console.error);
      break;

    case 'rewind':
     // Get the current playing time
    let cTime = queue.currentTime;

    // Calculate the new time
    let rTime = Math.max(0, cTime - 30);

    // Seek to the new time in the current song
      await distube.seek(interaction, rTime);
      await interaction.reply({ content: `As per ${displayName} request, Quick Back! 30 sec Ago! `, ephemeral: false })
           .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 10000);

    })

    .catch(console.error);
      break;

    case 'skip':
     if (queue) {
     if (queue.songs.length === 1) {
    interaction.reply({ content: 'No Up Next Track', ephemeral: true });
     }
     else {
       queue.skip();
      await interaction.reply({ content: `As per ${displayName} request, Skipped the song!`, ephemeral: false })
          .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 10000);

    })

    .catch(console.error);
      }
    }
     break;

    case 'shuffle':
      queue.shuffle();
      await interaction.reply({ content: `As per ${displayName} request, Shuffled the queue!`, ephemeral: false })
           .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 10000);

    })

    .catch(console.error);
      break;

   case 'loop':
    let mode = queue.repeatMode;
    mode = (mode + 1) % 3;
    queue.setRepeatMode(mode);
    if(mode === 0){
      await interaction.reply({ content: `As per ${displayName} request, Loop Disabled`, ephemeral: false })
         .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 10000);

    })

    .catch(console.error);
      }
   else if(mode === 1) {
     await interaction.reply({ content: `As per ${displayName} request, Repeating This Song`, ephemeral: false })
        .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 10000);

    })

    .catch(console.error);
       }
   else if(mode === 2) {
      await interaction.reply({ content: `As per ${displayName} request, Repeating The Queue`, ephemeral: false })
        .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 10000);

    })

    .catch(console.error);
     }
   else{
    await interaction.reply({ content: 'Something went wrong', ephemeral: true });
     }
    break;

    case 'volume_up':
      queue.setVolume(Math.min(queue.volume + 10, 100)); // Increase volume by 10%
      await interaction.reply({ content: `As per ${displayName} request, Volume increased to ${queue.volume}%`, ephemeral: false })
           .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 10000);

    })

    .catch(console.error);
      break;

   case 'autoplay':
          const userIds = interaction.user.id;
  
    
    const hasVoteds = await checkVotesOnAnyList(userIds);
    
    if(!hasVoteds) {
        const voteEmbed = new EmbedBuilder()
.setColor(0x7289DA) // Set a color for the embed
.setTitle('This is a Vote Command!') // Set a title for the embed
.setDescription('Your support means a lot to us! Please vote is in any of the mentioned site to get access to this command >3 ')
.setThumbnail('https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048') // You can put your bot's avatar or any relevant image here
.addFields({ name: ' Top.gg Vote Link', value: '[vote here](https://top.gg/bot/1219339793633120357/vote)' })
       // Replace with your actual voting link
        .addFields({ name: ' BotList.me Vote Link', value: '[vote here](https://botlist.me/bots/1219339793633120357/vote)' })
.setTimestamp() // Optional: Adds a timestamp to the embed
.setFooter({ text: 'Thank you for your support!', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp?size=2048' }); // Optional: Adds a footer

await interaction.reply({ embeds: [voteEmbed] })
    .then(reply => {
        
        setTimeout(() => {
            reply.delete().catch(console.error);
        }, 100000);
    })
    .catch(console.error);

return;
        
        }
     const autoplayStatus = queue.toggleAutoplay();
     if(autoplayStatus) {
      await interaction.reply({ content: `As per ${displayName} request, Enabled Autoplay`, ephemeral: false })
          .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 10000);

    })

    .catch(console.error);
     } else {
	await interaction.reply({ content: `As per ${displayName} request, Disabled Autoplay`, ephemeral: false })
          .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 10000);

    })

    .catch(console.error);
            }
    break;

    case 'smash':
        // Smash button logic
        const imageUrl = interaction.message.embeds[0].image.url;
        await Waifu.findOneAndUpdate(
          { userId: interaction.user.id },
          { $push: { smashedWaifus: { $each: [imageUrl], $slice: -5 } } },
          { upsert: true, new: true }
        );
        await interaction.reply({ content: 'Waifu smashed! heart', ephemeral: true });
        break;

      case 'pass':
        // Pass button logic
        try {
          const apiUrl = 'https://api.waifu.pics/sfw/waifu';
          const newResponse = await axios.get(apiUrl);
          const newImageUrl = newResponse.data.url;
          const newEmbed = new EmbedBuilder()
            .setTitle('New Random Waifu')
            .setImage(newImageUrl)
            .setColor(0xFFFFFF);
          await interaction.update({ embeds: [newEmbed] });
        } catch (error) {
          console.error('Error fetching a new waifu:', error);
          await interaction.reply({ content: `Couldn't get a new waifu image. Please try again later.`, ephemeral: true });
        }
        break;
  case 'truth_button':
  case 'dare_button':
    const apiUrl = interaction.customId === 'truth_button'
    ? 'https://api.truthordarebot.xyz/v1/truth'
    : 'https://api.truthordarebot.xyz/api/dare';

    try {
      const response = await axios.get(apiUrl);
      const { question } = response.data;

      const embed = new EmbedBuilder()
      .setTitle(interaction.customId === 'truth_button' ? 'Truth' : 'Dare')
      .setDescription(question)
      .setColor(interaction.customId === 'truth_button' ? 0x57F287 : 0xED4245);
     const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('truth_button')
        .setLabel('Truth')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('dare_button')
        .setLabel('Dare')
        .setStyle(ButtonStyle.Danger)
    );


      await interaction.reply({ embeds: [embed], components: [row] });
    } catch (error) {
      console.error('Error fetching question:', error);
      await interaction.reply({ content: 'There was an error trying to fetch a question. Please try again later.', ephemeral: true });
    }
    break;
case 'next_nhie':
// Fetch and send the next NHIE prompt from the API
try {
const response = await axios.get('https://api.truthordarebot.xyz/api/nhie');
const { question } = response.data;

const nextNhieEmbed = new EmbedBuilder()
.setTitle('Never Have I Ever...')
.setDescription(question)
.setColor(0x5865F2);

const nhieRow = new ActionRowBuilder()
.addComponents(
new ButtonBuilder()
.setCustomId('next_nhie')
.setLabel('Next NHIE')
.setStyle(ButtonStyle.Primary)
);

await interaction.reply({ embeds: [nextNhieEmbed], components: [nhieRow] });
} catch (error) {
console.error('Error fetching next NHIE question:', error);
await interaction.reply({ content: 'There was an error trying to fetch the next NHIE question. Please try again later.', ephemeral: true });
}
break;

case 'next_wyr':
// Fetch and send the next WYR prompt from the API
try {
const response = await axios.get('https://api.truthordarebot.xyz/api/wyr');
const { question } = response.data;

const nextWyrEmbed = new EmbedBuilder()
.setTitle('Would You Rather...')
.setDescription(question)
.setColor(0x5865F2);
const wyrRow = new ActionRowBuilder()
.addComponents(
new ButtonBuilder()
.setCustomId('next_wyr')
.setLabel('Next WYR')
.setStyle(ButtonStyle.Primary)
);


await interaction.reply({ embeds: [nextWyrEmbed], components: [wyrRow] });
} catch (error) {
console.error('Error fetching the next WYR question:', error);
await interaction.reply({ content: 'There was an error trying to fetch the next WYR question. Please try again later.', ephemeral: true });
}
break; 

case 'next_paranoia':
// Fetch and send the next Paranoia question from the API
try {
const response = await axios.get('https://api.truthordarebot.xyz/api/paranoia');
const { question } = response.data;

const nextParanoiaEmbed = new EmbedBuilder()
.setTitle('Paranoia')
.setDescription(question)
.setColor(0x5865F2);
const paranoiaRow = new ActionRowBuilder()
.addComponents(
new ButtonBuilder()
.setCustomId('next_paranoia')
.setLabel('Next Paranoia')
.setStyle(ButtonStyle.Primary)
);
await interaction.reply({ embeds: [nextParanoiaEmbed], components: [paranoiaRow] });
} catch (error) {
console.error('Error fetching the next Paranoia question:', error); 
await interaction.reply({ content: 'There was an error trying to fetch the next Paranoia question. Please try again later.', ephemeral: true });
}
break;

case 'unlockthevc':
  try {
    const tempChannel = await vcUnlock(interaction.member);
    interaction.reply({ content: `Your Voice Channel Unlocked`, ephemeral: true });
  } catch (error) {
    interaction.reply({ content: error.message, ephemeral: true });
  }
 break;

 case 'lockthevc':
  try { 
 
    const tempChannel = await vcLock(interaction.member);
    interaction.reply({ content: `Locked the voice channel: ${tempChannel.name}`, ephemeral: true });
  } catch (error) {
    interaction.reply({ content: error.message, ephemeral: true });
  }
break;

  case 'hidethevc':
	try {
  const tempChannel = await vcHide(interaction.member);
  interaction.reply({ content: `The voice channel ${tempChannel.name} is now hidden.`, ephemeral: true });
	} catch (error) {
  interaction.reply({ content: error.message, ephemeral: true });
	}
	break;

   case 'unhidethevc':
     try {
    const tempChannel = await vcUnhide(interaction.member);
    interaction.reply({ content: `The voice channel ${tempChannel.name} is no longer hidden.`, ephemeral: true });
      } catch (error) {
    interaction.reply({ content: error.message, ephemeral: true });
       }
     break;
     
     case 'limitthevc':
   try {

        await promptUserLimitVC(interaction);

      } catch (error) {

        interaction.reply("something went wrong");
         console.log(error);
     }
    break;
    
    case 'renamethevc':
   try {
      
        await promptRenameVC(interaction);

      } catch (error) {

	interaction.reply("something went wrong");
         console.log(error);
     }
    break;
    
    case 'bitratethevc':
         try {

        await promptChangeBitrateModal(interaction);

         } catch (error) {

        interaction.reply("something went wrong");
         console.log(error);
     	}
        break;
        
        case 'removelimitthevc':
     const { removed, reason } = await removeLimit(interaction.member);

     if (!removed) {
      return interaction.reply({ content: reason, ephemeral: true });
        }

     return interaction.reply({ content: 'The user limit has been removed from the voice channel.', ephemeral: true });
     break;


    default:
      console.log('Unknown interaction customId: ', interaction.customId);
  }
}); 
client.on(Events.InteractionCreate, async interaction => {
    if(!interaction.isSelectMenu()) return;
    if(interaction.isCommand()) return;
     const queue = distube.getQueue(interaction.guildId);
    const member = interaction.guild.members.cache.get(interaction.user.id);
    
  if (!member.voice.channel || member.voice.channel !== queue.voiceChannel) {
    await interaction.reply({ content: "You need to be in the same voice channel as the bot to use these controls!", ephemeral: true });
    return;
  }
    const displayName = interaction.member.displayName;
    if (interaction.isSelectMenu() && interaction.customId === 'song-selector') {
        const selectedValue = interaction.values[0]; // They can only pick one, so grab the first value
        const trackIndex = parseInt(selectedValue, 10); // Convert back to a number
        const queue = distube.getQueue(interaction.guildId); // Access the queue for the guild

        if (!queue) {
            await interaction.reply({ content: 'No music playing right now, no vibes to mess with.', ephemeral: true });
            return;
        }

        // Check if the selected track index is within the bounds of the queue
        if (trackIndex < 0 || trackIndex >= queue.songs.length) {
            await interaction.reply({ content: 'Whoops, that track is out of the queue’s bounds. Try another one?', ephemeral: true });
            return;
        }

        try {
            // Jump to the selected song
            await queue.jump(trackIndex);
            updateEmbed(queue, interaction.guildId);
            await interaction.reply({ content: `Skipped to: **${queue.songs[trackIndex].name}**`, ephemeral: true });
        } catch (error) {
            console.error(error);
            await interaction.reply({ content: 'Whoops, had a hiccup while skipping. Might wanna try that again?', ephemeral: true });
        }
    }

if (interaction.customId === 'select-track') {           
const guildId = interaction.guildId;
const voiceChannel = interaction.member.voice.channel;
const selectedValue = interaction.values[0];

await interaction.deferUpdate();
if (!voiceChannel) {
            await interaction.followUp({ content: "Looks like you're not in a voice channel. Mind hopping into one?", ephemeral: true });
            return;                                                }                                                  if (selectedValue === 'none') {
// Nothing to do here
return;
}

// Extract the index from the selected value               
const trackIndex = parseInt(selectedValue.replace('track_', ''));                                                     
const queue = distube.getQueue(interaction.guildId);       
// If the queue is missing or the index is out of bounds, let the user know
if (!queue || isNaN(trackIndex) || trackIndex < 0) {       
await interaction.followUp({ content: "Weird, I can't seem to hit the right note with that track.", ephemeral: true });
return;
}                                                          
// No need to search again, just use the search result stored in a cache or somewhere accessible
if (!searchResultsCache || searchResultsCache.length <= trackIndex) {
await interaction.followUp({ content: "Struck a wrong chord, that track's location is a mystery.", ephemeral: true });
return;                                                    }
                                                           // Get the selected track from the cache
const selectedTrack = searchResultsCache[guildId]?.[trackIndex];

// Add the song to the front of the queue and skip the current song                                                   
await distube.play(voiceChannel, selectedTrack.url, {
                member: interaction.member,                                
                textChannel: interaction.channel,
		position: 1,
                skip: true // This option might not exist; you'd likely need to implement skip logic after playback starts
            });
// Let the user know that their selection is now playing
await interaction.followUp({ content: `Cool choice! Now playing: **${selectedTrack.name}**. Enjoy!`, ephemeral: true });                                                         delete searchResultsCache[guildId]; 
}
if (interaction.customId === 'select-filter') {
    const selectedFilter = interaction.values[0]; // The value of the selected option
    // Apply the filter in DisTube using the selectedFilter value
    // Make sure you handle this part using your DisTube implementation
  if(selectedFilter === 'clear'){

      queue.filters.clear();

}else{
    queue.filters.add(selectedFilter);
   }
     await interaction.reply({
      content: selectedFilter === 'clear' ? `Filters cleared! as requested by ${displayName}` : `Filter set to: ${selectedFilter} as requested by ${displayName}`,
     ephemeral: false
    })
     .then(reply => {

        // Set a timeout to delete the reply after 5 minutes (300000 milliseconds)

        setTimeout(() => {

            reply.delete().catch(console.error);

        }, 10000);

    })

    .catch(console.error);
  }

});
// Embed
async function updateEmbed(queue, guildId) {
   const settings = await MusicSetting.findOne({ guildId });
   if (!settings || !settings.channelId || !settings.nowPlayingMessageId) return;
   const channel = client.channels.cache.get(settings.channelId);
  const embedMessage = await channel.messages.fetch(settings.queueMessageId);

  let description = '';
  const thumbnailUrl = 'https://i.ibb.co/N2hXdhW/fd2505ae6a2ce068866cb085e488fcef-ezgif-com-crop-1.gif'; // Replace with your imgbb thumbnail URL

  if (!queue || !queue.songs.length) {
    description = 'Looks like Akari is not singing.. Just type the song name or send url of supported platform to get started..';
  } else {
    description = queue.songs.map((song, index) => {
      const songDuration = song.formattedDuration;
      return index === 0
        ? `**Now Playing:** ${song.name} (${songDuration}) \n`
        : `**In Queue:** ${index}. ${song.name} (${songDuration}) \n`;
    }).join('');
  }

  // Check if description exceeds the Discord message character limit
  if (description.length > 4096) {
    description = 'The queue is too long to display fully here. You will be able to see the full list once some songs have finished playing.';
  }

  const queueEmbed = new EmbedBuilder()
    .setColor(0xFFA6C1)
    .setTitle('<a:np:1230724153389219943> __**Akari Music Queue**__')
    .setDescription(description)
    .setThumbnail(thumbnailUrl) // Static thumbnail
    .setFooter({ text: 'Powered By The Mavericks', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp' })
    .setTimestamp();
   const buttons = new ActionRowBuilder()                      .addComponents(                                              new ButtonBuilder()                                          .setCustomId('volume_down')
        .setEmoji('<:vd:1234054010517065748>')                     .setStyle(ButtonStyle.Secondary),                       new ButtonBuilder()                                           .setCustomId('rewind')                                     .setEmoji('<:rwd:1234054168348594186>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()                                          .setCustomId('previous')
        .setEmoji('<:previous:1234054215752613948>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('pause_resume')                               .setEmoji('<:pp:1234054192461643816>')
        .setStyle(ButtonStyle.Secondary),                        new ButtonBuilder()                                          .setCustomId('stop')
        .setEmoji('<:emoji_11:1234054266633850963>')
        .setStyle(ButtonStyle.Secondary)
);                                                            const buttons1 = new ActionRowBuilder()
   .addComponents(                                               new ButtonBuilder()
        .setCustomId('forward')                                    .setEmoji('<:fwd:1234054144654839898>')                    .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()                                          .setCustomId('skip')
          .setEmoji('<:skip:1230583198686253140>')                 .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('shuffle')
        .setEmoji('<:shuffle:1230717309572747354>')
        .setStyle(ButtonStyle.Secondary),                        new ButtonBuilder()
        .setCustomId('autoplay')
        .setEmoji('<:autoplay:1230747793854042153>')
        .setStyle(ButtonStyle.Secondary),                        new ButtonBuilder()
        .setCustomId('volume_up')                                  
        .setEmoji('<:vu:1234054092620435456>')                     
       .setStyle(ButtonStyle.Secondary)                      
 );                                                                                                                         
const buttons2 = new ActionRowBuilder()               
     .addComponents(
        new ButtonBuilder()
        .setCustomId('loop')                                         
        .setEmoji('<:lp:1230717553660133466>')                   
        .setStyle(ButtonStyle.Secondary)
   );
  // If a song is playing, set its thumbnail as the embed image
  if (queue && queue.playing && queue.songs.length > 0 && queue.songs[0].thumbnail) {
    queueEmbed.setImage(queue.songs[0].thumbnail);
  } else {
   queueEmbed.setImage("https://i.ibb.co/1TqMbFX/animesher-com-gif-k-on-hh-98193.gif");
}
 
  //select menu
   const songsToShow = queue.songs.length ? queue.songs.slice(0, 25) : [];
   const songOptions = songsToShow.map((song, index) => ({
    label: song.name.substring(0, 100), 
    description: song.uploader.name ? song.uploader.name.substring(0, 100) : 'No description', 
    value: index.toString(), 
}));

const songSelectMenu = new SelectMenuBuilder()
  .setCustomId('song-selector')
  .setPlaceholder('Select a track from Queue to Skip')
  .addOptions(songOptions);

const row = new ActionRowBuilder().addComponents(songSelectMenu);

if (!queue || !queue.songs.length) {
	try {
    await embedMessage.edit({ embeds: [queueEmbed] });
  } catch (error) {
    console.error(error);                                    }
}

  // Try to update our stored message ID with the new embed
  try {
    await embedMessage.edit({ embeds: [queueEmbed] });
  } catch (error) {
    console.error(error);
  }
} 

//Function to Update Now playing as per Current Status
async function npEmbed(queue, guildId) {
   const settings = await MusicSetting.findOne({ guildId });
   if (!settings || !settings.channelId || !settings.nowPlayingMessageId) return;
   const channel = client.channels.cache.get(settings.channelId);
   const nowPlayingEmbedMessage = await channel.messages.fetch(settings.nowPlayingMessageId);
  const thumbnailUrl = 'https://i.ibb.co/WzS2n74/e537d65cb8b81e46f1dcb1f36ccaeec9.jpg';
  if (!queue || !queue.songs.length) {
    description = 'Nothing is Playing in This Guild at this Time just type the song name in this channel to start playing music';
  } else {
    let autoplayStatus = queue.autoplay ? 'on' : 'off';
    let loopStatus;
switch (queue.loopMode) {
    case 0: loopStatus = 'off'; break;
    case 1: loopStatus = 'This Song'; break;
    case 2: loopStatus = 'Queue'; break;
    default: loopStatus = 'off'; // just a default case to be safe
}
    description = queue.songs.map((song, index) => {
      const songDuration = song.formattedDuration;
      return index === 0
        ? `**Now Playing:** ${song.name} (${songDuration}) \n **Artist:** ${song.uploader.name} **Volume:** ${queue.volume} \n **Autoplay**: ${autoplayStatus} **Loop:** ${loopStatus}`
        : `**Artist:** ${song.uploader.name}`;
    }).join('');
  }

  // Check if description exceeds the Discord message character limit
  if (description.length > 4096) {
    description = 'The queue is too long to display fully here. You will be able to see the full list once some songs have finished playing.';
  }

  const npEmbed = new EmbedBuilder()
    .setColor(0xFFA6C1)
    .setTitle('<a:np:1230724153389219943> __**Akari Now Playing:**__')
    .setDescription(description)
    .setThumbnail(thumbnailUrl) // Static thumbnail
    .setFooter({ text: 'Powered By The Mavericks', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp' })
    .setTimestamp();
   const buttons = new ActionRowBuilder()                      .addComponents(                                              new ButtonBuilder()                                          .setCustomId('volume_down')
        .setEmoji('<:vd:1234054010517065748>')                     .setStyle(ButtonStyle.Secondary),                       new ButtonBuilder()                                           .setCustomId('rewind')                                     .setEmoji('<:rwd:1234054168348594186>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()                                          .setCustomId('previous')
        .setEmoji('<:previous:1234054215752613948>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('pause_resume')                               .setEmoji('<:pp:1234054192461643816>')
        .setStyle(ButtonStyle.Secondary),                        new ButtonBuilder()                                          .setCustomId('stop')
        .setEmoji('<:emoji_11:1234054266633850963>')
        .setStyle(ButtonStyle.Secondary)
);                                                            const buttons1 = new ActionRowBuilder()
   .addComponents(                                               new ButtonBuilder()
        .setCustomId('forward')                                    .setEmoji('<:fwd:1234054144654839898>')                    .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()                                          .setCustomId('skip')
          .setEmoji('<:skip:1230583198686253140>')                 .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('shuffle')
        .setEmoji('<:shuffle:1230717309572747354>')
        .setStyle(ButtonStyle.Secondary),                        new ButtonBuilder()
        .setCustomId('autoplay')
        .setEmoji('<:autoplay:1230747793854042153>')
        .setStyle(ButtonStyle.Secondary),                        new ButtonBuilder()
        .setCustomId('volume_up')                                  
        .setEmoji('<:vu:1234054092620435456>')                     
       .setStyle(ButtonStyle.Secondary)                      
 );                                                                                                                         
const buttons2 = new ActionRowBuilder()               
     .addComponents(
        new ButtonBuilder()
        .setCustomId('loop')                                         
        .setEmoji('<:lp:1230717553660133466>')                   
        .setStyle(ButtonStyle.Secondary)
   );
  // If a song is playing, set its thumbnail as the embed image
  if (queue && queue.playing && queue.songs.length > 0 && queue.songs[0].thumbnail) {
    npEmbed.setImage(queue.songs[0].thumbnail);
  } else {
   npEmbed.setImage("https://i.ibb.co/W0WYZf3/animesher-com-girl-blue-hair-1052426.gif");
}
 
  //select menu
   const songsToShow = queue.songs.length ? queue.songs.slice(0, 25) : [];
   const songOptions = songsToShow.map((song, index) => ({
    label: song.name.substring(0, 100), 
    description: song.uploader.name ? song.uploader.name.substring(0, 100) : 'No description', 
    value: index.toString(), 
}));

const songSelectMenu = new SelectMenuBuilder()
  .setCustomId('song-selector')
  .setPlaceholder('Select a track from Queue to Skip')
  .addOptions(songOptions);

const row = new ActionRowBuilder().addComponents(songSelectMenu);

if (!queue || !queue.songs.length) {
	try {
    await nowPlayingEmbedMessage.edit({ embeds: [npEmbed], components: [] });
  } catch (error) {
    console.error(error);                                    }
}

  // Try to update our stored message ID with the new embed
  try {
    await nowPlayingEmbedMessage.edit({ embeds: [npEmbed], components: [row, buttons, buttons1, buttons2 ] });
  } catch (error) {
    console.error(error);
  }
}


// Event for playing songs

    distube.on('playSong', async (queue, song) => {             queue.setVolume(sessionVolume);                           let embed = new EmbedBuilder()
        .setTitle("<a:np:1230724153389219943> **Now Playing** ")                       .setDescription(`**[${song.name}](${serverUrl})**`)        
   //.setThumbnail('https://i.ibb.co/vD9FJfZ/493cc0c404664932121af022f88c509c.gif?size=256') 
    .setThumbnail(song.thumbnail) // Thumbnail of the song                                        
    .setImage(song.thumbnail)                             .setColor(0x1DB954) // Spotify green color           
    .addFields(                     
    { name: "<:dur:1230578297818189854> Duration", value: `\`${song.formattedDuration}\``, inline: true },         
    { name: "<:mic:1230578249889742918> Artist", value: `\`${song.uploader.name}\``, inline: true },       
    { name: "<:volume:1230577215717244998> Volume", value: `\`${queue.volume}%\``, inline: true },
       { name: "<:lke:1230578403963437177> Likes", value: `\`${song.likes || 'N/A'}\``, inline: true },

            { name: "<:shr:1230578375920193558> Shares", value: `\`${song.shares || 'N/A'}\``, inline: true }, 

            { name: "<:vie:1230578345201111070> Views", value: `\`${song.views || 'N/A'}\``, inline: true }
    )        
    .setImage(song.thumbnail)
    // Large image of the song thumbnail    
    .setFooter({ text: `Requested by ${song.user.tag}`, iconURL: song.user.displayAvatarURL() })                .setTimestamp();                                                                                        // Set default volume to 75 when a new song starts
   const buttons = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('volume_down')
        .setEmoji('<:vd:1234054010517065748>')
        .setStyle(ButtonStyle.Secondary),
     new ButtonBuilder()
        .setCustomId('rewind')
        .setEmoji('<:rwd:1234054168348594186>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('previous')
        .setEmoji('<:previous:1234054215752613948>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('pause_resume')
        .setEmoji('<:pp:1234054192461643816>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('stop')
        .setEmoji('<:emoji_11:1234054266633850963>')
        .setStyle(ButtonStyle.Secondary)
);
   const buttons1 = new ActionRowBuilder()
   .addComponents(
      new ButtonBuilder()
        .setCustomId('forward')
        .setEmoji('<:fwd:1234054144654839898>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('skip')
          .setEmoji('<:skip:1230583198686253140>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('shuffle')
        .setEmoji('<:shuffle:1230717309572747354>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('autoplay')
        .setEmoji('<:autoplay:1230747793854042153>')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('volume_up')
        .setEmoji('<:vu:1234054092620435456>')
        .setStyle(ButtonStyle.Secondary)
    );


   const buttons2 = new ActionRowBuilder()
   .addComponents(
        new ButtonBuilder()
        .setCustomId('loop')
          .setEmoji('<:lp:1230717553660133466>')
        .setStyle(ButtonStyle.Secondary)
   );

	const searchResults = await distube.search(song.name);
    const trackOptions = searchResults.slice(0, 5).map((result, index) => ({
label: result.name.length > 100 ? result.name.substring(0, 97) + '...' : result.name, // Truncate if too long
description: result.formattedDuration,
value: `track_${index}`
}));
                                                           // Ensure the user has a None option in case they don't want any of the tracks
trackOptions.unshift({ label: 'None', description: 'Keep the current track playing', value: 'none' });                
// Create the select menu for track selection
const trackMenu = new SelectMenuBuilder()
.setCustomId('select-track')                               .setPlaceholder('Not the right track? Pick a different track')
.addOptions(trackOptions);                                 searchResultsCache[queue.textChannel.guildId] = searchResults.slice(0, 5);
// Create a message action row to hold the select menu
const trackMenuRow = new ActionRowBuilder().addComponents(trackMenu);   

const filterMenu = new SelectMenuBuilder()
  .setCustomId('select-filter')
  .setPlaceholder('Choose a filter')
  .addOptions(filterOptions);

const filterrow = new ActionRowBuilder().addComponents(filterMenu);

    updateEmbed(queue, queue.textChannel.guildId);
   npEmbed(queue, queue.textChannel.guildId);
    queue.textChannel.send({ embeds: [embed], components: [trackMenuRow, filterrow, buttons, buttons1, buttons2] }).then(playMsg => {
        const filter = (_, user) => user.id === song.user.id;
        const collector = queue.textChannel.createMessageComponentCollector({ filter, time: song.duration * 1000 });                                                                                                            collector.on('end', () => playMsg.delete().catch(e => console.error('Error deleting the message:', e)));
    });                                               });





// if single song added to Queue
distube.on('addSong', async (queue, song) => {
if (queue.songs.length > 1) { // The song added isn't playing right now, it's been queued
  const embed = new EmbedBuilder()
    .setTitle(`<:deezer:1230719391415406652> **Song Added to Queue**`)
    .setDescription(`**[${song.name}](${serverUrl})** has been added to the queue!`)
    .setThumbnail(song.thumbnail)
    .setColor(0x1DB954) // Lovely green color
    .addFields(
      { name: '<:dur:1230578297818189854> Duration', value: song.formattedDuration, inline: true },
      { name: '<:mic:1230578249889742918> Artist', value: song.uploader.name, inline: true },
      { name: '<:posi:1230705698543898635> Position in Queue', value: `\`${queue.songs.indexOf(song) + 1}\``, inline: true }
    )
    .setFooter({ text: `Added by ${song.user.tag}`, iconURL: song.user.displayAvatarURL({ dynamic: true }) })
    .setTimestamp();
  updateEmbed(queue, queue.textChannel.guildId);
const np = await queue.textChannel.send({ embeds: [embed] });
setTimeout(() => np.delete().catch(e => console.error('error deleting the message: ', e)), 30000);
}
});

// if Playlist Added To Queue


distube.on('addList', async  (queue, playlist) => {
  const embed = new EmbedBuilder()
    .setTitle(`<:Playlist:1230707473317363755> **Playlist Added to Queue**`)
    .setDescription(`**[${playlist.name}](${serverUrl})** with \`${playlist.songs.length}\` songs has been added!`)
    .setThumbnail(playlist.thumbnail)
    .setColor(0x1DB954) // Lovely green color, again
    .addFields({
      name: "<:total:1230707408486141972> Total Songs in Queue",
      value: `\`${queue.songs.length}\``,
      inline: true
    })
    .setFooter({ text: `Added by ${playlist.user.tag}`, iconURL: playlist.user.displayAvatarURL({ dynamic: true }) })
    .setTimestamp();
 updateEmbed(queue, queue.textChannel.guildId);
 const q = await  queue.textChannel.send({ embeds: [embed] });
setTimeout(() => q.delete().catch(e => console.error('error deleting the message: ', e)), 30000);
});

// For individual song end
distube.on('finishSong', async (queue, song) => {
//console.log(`The song ${song.name} just ended. Preparing to send the embed.`); // Added for debugging

const songEndEmbed = new EmbedBuilder()
.setTitle('<:deezer:1230719391415406652> **Song Ended**')
.setDescription(`<:stop:1230584430846939198> **${song.name}** has finished playing.`)
.setThumbnail(song.thumbnail)
//.setThumbnail('')
.setColor(0x1DB954) // A comforting green color
.setFooter({ text: 'A Product of Mavericks ' })
.setTimestamp();
const endMsg = await queue.textChannel.send({ embeds: [songEndEmbed] });
setTimeout(() => endMsg.delete().catch(e => console.error('Error deleting the message:', e)), 30000); // Deletes the message after 30 seconds
}); 

// For when the queue ends
distube.on('finish', async queue => {
const finishQueueEmbed = new EmbedBuilder()
.setTitle('**Queue Concluded** <:str:1230721299446370345>')
.setDescription('The queue has ended. Thanks for listening!')
.setColor(0x1DB954) // A comforting green color
.setFooter({ text: 'Hope this session was fire like you 🔥. ' })
.setTimestamp();

const finishMsg = await queue.textChannel.send({ embeds: [finishQueueEmbed] });
setTimeout(() => finishMsg.delete().catch(e => console.error('Error deleting the message:', e)), 120000); // Deletes the message after 2 minutes
}); 

// Listen to the 'empty' event                        
distube.on("empty", queue => {                          // Create an embed with your message content 
const embed = new EmbedBuilder()
    .setColor('#ff6699') // A soft, whimsical pink hue   
        .setTitle('<:deezer:1230719391415406652> Echoes in the Silence <:music:1230710161056731167>')
    .setDescription("opsie! I am alone in this Voice Channel 🥲, Require Radio Feature? Contact our Dev. 🤭")
    .setThumbnail('https://i.ibb.co/TktH1M2/yumi.gif') // Image of a lonely mic on an empty stage  
        .setTimestamp()                                       .setFooter({ text: 'Powered by Mavericks', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp' });                                                     
queue.textChannel.send({ embeds: [embed] }).then(sentEmbed => {
    setTimeout(() => sentEmbed.delete(), 10000);
  });
}); 

// Listen to the 'disconnect' event
distube.on("disconnect", (queue) => {
  const embed = new EmbedBuilder()
    .setColor("#ff6699")
    .setTitle('<:deezer:1230719391415406652> Player Disconnected... <:cnc:1230719414324822026>')
    .setDescription("<:stop:1230584430846939198> NVM, I have been disconnected from your voice channel! <:vc:1230714679974957127>")
    .setTimestamp()
    .setFooter({ text: 'Powered By The Mavericks', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp' });
  // Send the embed in the text channel associated with the voice channel
  queue.textChannel.send({ embeds: [embed] }).then(sentEmbed => {
    // Make the message self-destruct after 10 seconds
    setTimeout(() => sentEmbed.delete().catch(console.error), 10000);
  }).catch(console.error);
}); 

// no result
distube.on('searchNoResult', (message, query) => {
  // Prepare the auto-vanishing embed                          
   const noResultsEmbed = new EmbedBuilder()
    .setColor(0x2f3136) // A stealthy, dark grey tone
    .setTitle('<:cnc:1230719414324822026> No Result found!!')
    .setDescription(`No echoes found for: \`${query}\` Maybe try a different melody?`)
    .setThumbnail('https://i.ibb.co/CzCz3vK/d7819e54814a1338677572362d2a7fec.jpg') // A music-themed placeholder
    .setTimestamp()
    .setFooter({ text: 'Sorry fot the inconvinence caused..', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp' });

  // Send the embed and make it disappear after 30 seconds        
queue.textChannel.send({ embeds: [noResultsEmbed] }).then(sentMessage => {
    setTimeout(() => {
      sentMessage.delete().catch(console.error);                    }, 30000); // 30000 milliseconds = 30 seconds
  }).catch(console.error);
});

// init queue
distube.on('initQueue', (queue) => {                            // Roll out the welcome mat with a snazzy embed
const queueInitEmbed = new EmbedBuilder()
.setColor(0x7289da) // Discord's blurple for a bit of brand flair                                                               
.setTitle('<:play:1230568571810222212> Starting Beats')
.setDescription(`Hold On!! Setting Up My Voice Before i began to Sing!!`)
.setThumbnail('https://i.ibb.co/4NSYv3x/48fc6d5f556a58c26057b544b9e7ab45.jpg') // a placeholder image that symbolizes fresh beginnings or music                                                 
.setTimestamp()
.setFooter({ text: 'Powered By The Mavericks', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp' });

// Find the text channel based on the queue and send the embed
const textChannel = queue.textChannel;
textChannel.send({ embeds: [queueInitEmbed] }).then(sentMessage => {
setTimeout(() => {
sentMessage.delete().catch(console.error);
}, 30000); // wave goodbye after 30 seconds
}).catch(console.error);
});

//delete queue
distube.on('deleteQueue', (queue) => {
// Craft an elegant embed that bows out with the queue
const queueDeleteEmbed = new EmbedBuilder()
.setColor(0x1e2124) // A deep, reflective gray
.setTitle('<:stop:1230584430846939198> Queue Cleared')
.setDescription('The queue has been cleared and the music has come to a rest. Until next time! Cya!')
.setThumbnail('https://i.ibb.co/CzCz3vK/d7819e54814a1338677572362d2a7fec.jpg') // Perhaps a dimming lightbulb or a closed curtain image
.setTimestamp()
.setFooter({ text: 'Powered By The Mavericks', iconURL: 'https://cdn.discordapp.com/avatars/1219339793633120357/e41ebf5cfe47ec05989544612a9a2f35.webp' });

// Send the embed in the guild's text channel specified by the queue                                                            
const textChannel = queue.textChannel;
textChannel.send({ embeds: [queueDeleteEmbed] }).then(sentMessage => {
setTimeout(() => {
// Sweep the embed away after giving enough time for a final adieu
sentMessage.delete().catch(console.error);
}, 30000); // 30000 milliseconds = 30 seconds
}).catch(console.error);
updateEmbed(queue, queue.textChannel.guildId);
npEmbed(queue, queue.textChannel.guildId);
});


// Handle errors gracefully
distube.on('error', (channel, error) => {
    console.error(error);
    channel.send("An error occurred while processing your request.");
});
// Log in your bot with its token
client.login('MTIxOTMzOTc5MzYzMzEyMDM1Nw.GPyk74.ngFtXxdx6p7wtXYgLX-Vl8lxk0oooQ0X6Qxx0k');
// Now, let's add the global process event listeners
process.on('uncaughtException', (err) => {
  console.error('Unhandled Exception:', err);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at Promise:', promise, 'Reason:', reason);
});
