const mongoose = require('mongoose');
const { Schema } = mongoose;

const loggingSchema = new Schema({
  guildId: {
    type: String,
    required: true,
    unique: true
  },
  messageLogs: String,
  vcLogs: String,
  serverLogs: String,
  memberLogs: String,
  joinLeaveLogs: String
});

module.exports = mongoose.model('Logging', loggingSchema); 
