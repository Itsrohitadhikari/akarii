const mongoose = require('mongoose');

const starboardSchema = new mongoose.Schema({
  guildId: {
    type: String,
    required: true,
    unique: true,
  },
  channelId: {
    type: String,
    required: true,
  },
  limit: {
    type: Number,
    required: true,
  },
  emoji: {
    type: String,
    required: true,
  }
});

const Starboard = mongoose.model('Starboard', starboardSchema);

module.exports = Starboard; 
